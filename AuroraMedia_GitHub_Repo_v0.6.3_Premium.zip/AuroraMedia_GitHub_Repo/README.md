# Aurora Media Android V0.6.3

Includes the V0.6.2 FTP player and automatic featured carousel, plus an **Upcoming in Theatres** tab showing Indian theatrical release information from TMDb. This is informational; upcoming titles cannot be played unless present in your FTP media library.

On first install, FTP defaults are prefilled for a specific private server, including its username and password. They remain editable in the FTP Settings screen, and any already saved values take priority. Password updates are stored encrypted using Android Keystore, but the initial defaults are embedded in the source APK and are **extractable**. Keep this GitHub repository private, treat the password as exposed to anyone who receives source/APK, and rotate it if you ever publish or share the project.

The FTP upload/offloader has been disabled as requested. For GitHub Actions, upload this versioned ZIP at the repo root and use the workflow in `.github/workflows/build-apk.yml`.

A structural/static preflight is included, but a complete Android APK compilation must be run on GitHub Actions unless the Android SDK is installed locally.

# Aurora Media for Android — V0.5.0 Phone Storage Offloading

Standalone Android FTP video player and phone-to-FTP file offloader; separate from the Fire TV edition.

## New: Move phone folder to FTP to reclaim local storage

Open the cloud-upload icon in the media library, then:

1. Select one phone folder using Android's system folder picker. The application stores the SAF read/write permission.
2. Choose an FTP destination, e.g. `/usb1_1/PhoneArchive` (separate from the movie library at `/usb1_1/movies`). FTP credentials are reused from your saved Aurora Media connection.
3. Explicitly enable **Delete each local original after verification**.
4. Confirm **Move now & free space**. Test with a small nonessential folder first.
5. Optionally enable daily automatic moves on Wi-Fi only, after validating manual results.

**Transfer safety:** Preserve relative subfolders; upload to a temporary `.aurora-*.part` file; verify size and SHA-256 digest by reading the FTP copy back; rename into the final remote filename; verify the local file again; only then delete the original through Android's folder permission. Existing remote filenames are never silently overwritten. If a same-name remote file already has the exact same SHA-256 content, the original may be safely removed; otherwise it is skipped. If a copy can't be verified, is interrupted, or FTP is unreachable, its local original remains. Empty local folders are retained. The app does **not** delete any remote files.

**Important caveats:** FTP is unencrypted, so operate on trusted home Wi-Fi or a private VPN. Remote verification doubles network reading and can be slow for very large movies. A successful hash comparison does not replace independent long-term backups, especially on consumer USB storage. An Android/FTP server may refuse folder access, listing, temporary file renaming, file deletion, or background foreground-service permissions. Scheduled runs are best-effort, not exact-time; only Wi-Fi is used. Android's picker restricts certain roots/folders. This feature does not provide two-way sync.

**First run caution:** The versionCode is 5, so the update can install over V0.4 only if the APK signatures match. A temporary GitHub debug signing key may change between runs. Uninstalling the older app deletes its saved FTP settings.

## GitHub ZIP workflow

Upload `AuroraMedia_GitHub_Repo_v0.5.zip` to the root of `Flames-glitch/Arura-Media` (do not unpack on your phone). Ensure `.github/workflows/build-apk.yml` uses the supplied **no-secrets test build workflow**; source ZIPs don't automatically replace the workflow in GitHub's repo root. GitHub Actions will extract `AuroraMedia_GitHub_Repo` from the ZIP, compile Android debug APK, and publish an artifact.

**Verification status:** Source syntax/structure, ZIP integrity, and manifest XML were checked locally. Full Gradle compilation and on-device FTP move/deletion safety require GitHub Actions and a test Android device.

---

# Aurora Media — Standalone Android FTP Movie Library

Aurora Media is **a completely independent Android application**; it does not share code, package names or build outputs with AuroraTV IPTV. FTP only; no SFTP dependency or support.

## What V0.1 includes

- Android app with dark Material 3 screens and one-time FTP connection setup.
- Plain FTP, passive mode, binary transfer; choose server, port, user, password and media path.
- FTP folder recursion and filename-based movie/TV episode recognition.
- Optional **TMDb API Read Access Token** for poster/backdrop/synopsis matching. Empty token = filename-only library. Cached metadata and scanning results remain visible if FTP is temporarily unreachable.
- Movie poster grid, Movies / TV Shows / Continue Watching filters, title search, details screen.
- Native LibVLC playback (not an external VLC intent) for supported files over FTP.
- Player controls: play/pause, ±10s seeking, scrub bar, resume, audio/subtitle track selection, aspect ratio, speed, volume up to a requested 125%, audio/subtitle delay ±250 ms adjustments, orientation auto/landscape/portrait/locked, external subtitle import, equalizer presets when supported by the bundled LibVLC ABI.
- Locally cached library; Android Keystore encryption for saved FTP password and TMDb token.
- GitHub Actions debug APK build.

## Build a debug APK using GitHub (no local SDK required)

1. Create a **new** repository for Aurora Media (do not upload into the AuroraTV repository).
2. Upload **the contents of this folder** to the repository root (including `.github/`).
3. Go to **Actions → Build Aurora Media APK → Run workflow**. Alternatively push to `main` or `master`.
4. Open the successful run and download the **AuroraMedia-debug-APK** artifact.
5. Install its `app-debug.apk` on Android (Android may require you to permit installing downloaded APKs).

The workflow provisions JDK 17, Android SDK 35, Gradle 8.9 and builds `:app:assembleDebug`. This archive intentionally does not include an unverified
## V0.6.3 premium player and trailers refresh (build code 10)

- Keeps the existing FTP streaming library, metadata posters, rotating featured banner,
  Continue Watching, Resume / Start from Beginning, and next-video suggestions.
- Adds a **Coming to Theatres** preview rail to Home and a TMDb-powered **Watch Trailer**
  action on Upcoming film details. If TMDb provides a supported YouTube video key,
  Android opens the corresponding YouTube URL. Otherwise **Search YouTube** opens
  a prefilled search results page, not an unverified video link. Playback remains FTP-only.
- The phone player opens in landscape with a compact transparent dark-gradient overlay,
  icon buttons (seek back 10, pause/play, seek forward 10, combined audio/subtitles),
  a progress slider, a top-row PiP icon and an overflow settings icon. No Cast button.
- Left vertical swipe adjusts brightness, right vertical swipe adjusts system music volume,
  horizontal swipe seeks, and a tap reveals/hides controls. Controls auto-hide after five seconds.
- The `Audio & Subtitles` modal exposes actual LibVLC tracks, external subtitle loading,
  track delays; playback speed and display orientation live under the overflow menu.
- Keeps the legacy offload worker disabled and cancels queued offload jobs at startup.

**Security:** The first-run FTP defaults and TMDb API key are embedded in source and
are recoverable from an APK; keep the repository private and avoid redistributing builds.
FTP is not an encrypted transport. Saved changes take precedence over first-run defaults.

**Build validation:** `python3 tools/verify_project.py` runs source checks; `kotlinc`
can compile `TrailerSelection.kt` and `tools/trailer_test.kt` without Android dependencies.
The full Android build and `:app:testDebugUnitTest` require GitHub Actions/Android SDK 35.
