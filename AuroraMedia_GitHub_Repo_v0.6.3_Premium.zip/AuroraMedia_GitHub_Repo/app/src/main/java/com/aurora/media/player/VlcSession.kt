package com.aurora.media.player

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.SurfaceView
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aurora.media.data.FtpSettings
import com.aurora.media.data.MediaEntry
import com.aurora.media.ftp.FtpScanner
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/** Local LibVLC playback. FTP URLs are never sent to TMDb or any online search endpoint. */
class VlcSession(
    context: Context,
    private val entry: MediaEntry,
    private val settings: FtpSettings,
    private val onProgress: (Long, Long) -> Unit,
    private val onFinished: () -> Unit = {}
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val vlc = LibVLC(context.applicationContext, arrayListOf("--network-caching=1800", "--no-video-title-show"))
    private val player = MediaPlayer(vlc)
    var isPlaying by mutableStateOf(false)
        private set
    var positionMs by mutableStateOf(0L)
        private set
    var durationMs by mutableStateOf(0L)
        private set
    var isBuffering by mutableStateOf(false)
        private set
    var error by mutableStateOf("")
        private set
    var aspect by mutableStateOf("Fit")
        private set
    var volume by mutableStateOf(100)
        private set
    var audioDelayMs by mutableStateOf(0L)
        private set
    var subtitleDelayMs by mutableStateOf(0L)
        private set
    var speed by mutableStateOf(1f)
        private set

    private var started = false
    private var restored = false
    private var completed = false
    private var closed = false
    private var lastAdvancedAt = android.os.SystemClock.elapsedRealtime()
    private var lastObservedPosition = -1L
    private var bufferingCheck = 0

    fun attach(surface: SurfaceView) {
        if (started) return
        started = true
        player.vlcVout.setVideoView(surface)
        player.vlcVout.attachViews()
        // Reset any stale zoom/crop settings before the first frame.
        // scale=0 uses LibVLC auto-fit (letterboxes instead of cropping).
        player.aspectRatio = null
        player.scale = 0f
        player.setEventListener { event ->
            // libVLC callbacks can arrive on non-UI threads.
            main.post {
                if (closed) return@post
                when (event.type) {
                    MediaPlayer.Event.Playing -> { isPlaying = true; isBuffering = false; lastAdvancedAt = android.os.SystemClock.elapsedRealtime() }
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> { isPlaying = false; isBuffering = false; bufferingCheck++ }
                    MediaPlayer.Event.Buffering -> {
                        // LibVLC emits Buffering events even while playback proceeds normally.
                        // Never display a spinner unless the clock actually stalls.
                        if (isPlaying) {
                            val check = ++bufferingCheck
                            main.postDelayed({
                                if (!closed && isPlaying && check == bufferingCheck &&
                                    android.os.SystemClock.elapsedRealtime() - lastAdvancedAt > 3000L) {
                                    isBuffering = true
                                }
                            }, 2800L)
                        } else { isBuffering = false; bufferingCheck++ }
                    }
                    MediaPlayer.Event.TimeChanged, MediaPlayer.Event.LengthChanged, MediaPlayer.Event.PositionChanged -> {
                        positionMs = player.time.coerceAtLeast(0L)
                        durationMs = player.length.coerceAtLeast(0L)
                        if (kotlin.math.abs(positionMs - lastObservedPosition) >= 250L) {
                            lastObservedPosition = positionMs
                            lastAdvancedAt = android.os.SystemClock.elapsedRealtime()
                            isBuffering = false
                            bufferingCheck++
                        }
                        if (!restored && entry.lastPositionMs > 5_000L && durationMs > entry.lastPositionMs + 10_000L) {
                            restored = true
                            player.time = entry.lastPositionMs
                        }
                        if (durationMs > 0 && positionMs >= 0) onProgress(positionMs, durationMs)
                    }
                    MediaPlayer.Event.EndReached -> {
                        isPlaying = false; isBuffering = false; completed = true; positionMs = 0L
                        onProgress(0L, durationMs)
                        onFinished()
                    }
                    MediaPlayer.Event.EncounteredError -> {
                        error = "Cannot play this FTP file. Verify the server, video format and network connection."
                        isBuffering = false
                    }
                }
            }
        }
        try {
            val media = Media(vlc, Uri.parse(FtpScanner.mediaUrl(settings, entry.path)))
            media.setHWDecoderEnabled(true, false)
            player.media = media
            media.release()
            player.play()
        } catch (exception: Exception) {
            error = "Playback failed: ${exception.message ?: "Unknown error"}"
            isBuffering = false
        }
    }

    /** Match LibVLC native video output to the Compose surface bounds (actual pixels). */
    private var videoWindowWidth: Int = 0
    private var videoWindowHeight: Int = 0

    fun updateVideoWindow(width: Int, height: Int) {
        if (closed || width <= 0 || height <= 0) return
        videoWindowWidth = width
        videoWindowHeight = height
        runCatching { player.vlcVout.setWindowSize(width, height) }
        if (aspect == "Fill") player.aspectRatio = "${width}:${height}"
    }

    fun togglePause() { if (player.isPlaying) player.pause() else player.play() }
    fun pauseIfPlaying() {
        if (!closed && player.isPlaying) player.pause()
    }
    fun stopPlayback() {
        if (closed) return
        runCatching { player.stop() }
        isPlaying = false
        isBuffering = false
    }
    fun skip(offsetMs: Long) { seek((player.time + offsetMs).coerceIn(0L, player.length.coerceAtLeast(0L))) }
    fun seek(ms: Long) { if (player.isSeekable) player.time = ms.coerceAtLeast(0L) }

    fun changeAspect(mode: String) {
        aspect = mode
        // Fit MUST preserve the original source aspect ratio and show every pixel.
        // The old Fill implementation used scale=1 (native-pixel zoom), so it could
        // make even a "Fit" experience appear cropped after mode transitions.
        player.scale = 0f
        player.aspectRatio = when (mode) {
            "16:9" -> "16:9"
            "4:3" -> "4:3"
            "21:9" -> "21:9"
            "Fill" -> if (videoWindowWidth > 0 && videoWindowHeight > 0)
                "${videoWindowWidth}:${videoWindowHeight}" else null
            else -> null
        }
    }

    fun setVolumePercent(percent: Int) {
        volume = percent.coerceIn(0, 125)
        player.volume = volume
    }

    fun updateSpeed(value: Float) {
        speed = value.coerceIn(0.5f, 2f)
        player.rate = speed
    }

    fun shiftAudio(milliseconds: Long) {
        audioDelayMs = (audioDelayMs + milliseconds).coerceIn(-10_000, 10_000)
        player.setAudioDelay(audioDelayMs * 1000L) // microseconds
    }

    fun shiftSubtitles(milliseconds: Long) {
        subtitleDelayMs = (subtitleDelayMs + milliseconds).coerceIn(-10_000, 10_000)
        player.setSpuDelay(subtitleDelayMs * 1000L) // microseconds
    }

    fun audioTracks(): List<Pair<Int, String>> = runCatching {
        player.audioTracks?.map { it.id to it.name }.orEmpty()
    }.getOrDefault(emptyList())

    fun subtitleTracks(): List<Pair<Int, String>> = runCatching {
        player.spuTracks?.map { it.id to it.name }.orEmpty()
    }.getOrDefault(emptyList())

    fun selectAudio(id: Int) { player.audioTrack = id }
    fun selectSubtitle(id: Int) { player.spuTrack = id }

    fun loadExternalSubtitle(uri: Uri): Boolean = runCatching {
        // The system picker supplies a content:// URI; LibVLC expects a readable
        // local file path, so copy it into this app's private cache first.
        val suffix = when (appContext.contentResolver.getType(uri)) {
            "text/vtt" -> ".vtt"
            else -> ".srt"
        }
        val subtitlesDir = File(appContext.cacheDir, "subtitles").apply { mkdirs() }
        val file = File(subtitlesDir, "imported-${System.currentTimeMillis()}$suffix")
        val input = appContext.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Cannot access subtitle file")
        input.use { source -> file.outputStream().use { source.copyTo(it) } }
        if (file.length() == 0L || file.length() > 10L * 1024 * 1024) {
            file.delete()
            throw IllegalArgumentException("Subtitle file is empty or too large")
        }
        // 0 is libVLC's subtitle slave type (libvlc_media_slave_type_subtitle).
        player.addSlave(0, Uri.fromFile(file), true)
        true
    }.getOrDefault(false)

    /** MediaPlayer.Equalizer ABI varies by LibVLC version; use reflection for optional presets. */
    fun equalizerPreset(index: Int): Boolean = runCatching {
        val equalizerClass = Class.forName("org.videolan.libvlc.MediaPlayer\$Equalizer")
        val method = equalizerClass.getMethod("createFromPreset", Int::class.javaPrimitiveType)
        val equalizer = method.invoke(null, index)
        val apply = player.javaClass.methods.firstOrNull { it.name == "setEqualizer" && it.parameterTypes.size == 1 }
            ?: error("Equalizer unavailable")
        apply.invoke(player, equalizer)
        true
    }.getOrDefault(false)

    fun close() {
        if (closed) return
        closed = true
        if (durationMs > 0L) onProgress(if (completed) 0L else positionMs, durationMs)
        player.setEventListener(null)
        runCatching { player.stop() }
        runCatching { player.vlcVout.detachViews() }
        player.release()
        vlc.release()
    }
}
