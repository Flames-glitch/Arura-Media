package com.aurora.media.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aurora.media.data.FtpSettings
import com.aurora.media.data.MediaEntry
import com.aurora.media.player.PlayerScreen
import com.aurora.media.offload.OffloadScreen
import java.util.Locale

private val auroraColors = darkColorScheme(
    primary = Color(0xFF73AEFF),
    secondary = Color(0xFFC5D7F8),
    background = Color(0xFF080D18),
    surface = Color(0xFF101827),
    surfaceVariant = Color(0xFF202C40),
    onBackground = Color(0xFFF4F7FF),
    onSurface = Color(0xFFF4F7FF)
)
private val nightGradient = Brush.verticalGradient(
    listOf(Color(0xFF07101F), Color(0xFF0B1321), Color(0xFF080D18))
)

@Composable
fun AuroraApp(viewModel: AuroraViewModel) {
    val state = viewModel.state
    MaterialTheme(colorScheme = auroraColors) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (val screen = state.screen) {
                Screen.Setup -> SetupScreen(
                    initial = state.settings, busy = state.busy, message = state.message,
                    canExit = state.settings.ready,
                    onBack = { viewModel.navigate(Screen.Library) },
                    onConnect = viewModel::saveSetup
                )
                Screen.Offload -> {
                    BackHandler { viewModel.navigate(Screen.Library) }
                    OffloadScreen(onBack = { viewModel.navigate(Screen.Library) }, ftpReady = state.settings.ready)
                }
                Screen.Library -> LibraryScreen(
                    entries = state.entries, message = state.message,
                    loading = state.isScanning, onRescan = viewModel::refresh,
                    onSettings = { viewModel.navigate(Screen.Setup) },
                    onOffload = { viewModel.navigate(Screen.Offload) },
                    onSelect = viewModel::select
                )
                is Screen.Details -> {
                    BackHandler { viewModel.navigate(Screen.Library) }
                    val entry = state.entries.firstOrNull { it.id == screen.id }
                    if (entry == null) LaunchedEffect(screen.id) { viewModel.navigate(Screen.Library) }
                    else DetailsScreen(entry, recommendations = viewModel.recommendationsFor(entry.id),
                        onBack = { viewModel.navigate(Screen.Library) },
                        onPlay = { fromBeginning -> viewModel.play(entry.id, fromBeginning) },
                        onSelect = viewModel::select)
                }
                is Screen.Player -> {
                    BackHandler { viewModel.exitPlayer() }
                    val entry = state.entries.firstOrNull { it.id == screen.id }
                    if (entry == null) LaunchedEffect(screen.id) { viewModel.navigate(Screen.Library) }
                    else PlayerScreen(entry = entry, settings = state.settings,
                        fromBeginning = screen.fromBeginning,
                        suggestions = viewModel.recommendationsFor(entry.id, 6),
                        onPlayNext = { nextId -> viewModel.play(nextId, fromBeginning = true) },
                        onBack = viewModel::exitPlayer,
                        onLibrary = { viewModel.navigate(Screen.Library) },
                        onPositionChange = { time, duration -> viewModel.updateProgress(entry.id, time, duration) })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SetupScreen(
    initial: FtpSettings, busy: Boolean, message: String, canExit: Boolean,
    onBack: () -> Unit, onConnect: (FtpSettings) -> Unit
) {
    var host by remember(initial) { mutableStateOf(initial.host) }
    var port by remember(initial) { mutableStateOf(initial.port.toString()) }
    var username by remember(initial) { mutableStateOf(initial.username) }
    var password by remember(initial) { mutableStateOf(initial.password) }
    var directory by remember(initial) { mutableStateOf(initial.directory) }
    var token by remember(initial) { mutableStateOf(initial.tmdbToken) }

    Scaffold(topBar = {
        TopAppBar(title = { Text(if (canExit) "FTP Settings" else "Connect your media library") },
            navigationIcon = { if (canExit) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } })
    }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().imePadding()
                .verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            Icon(Icons.Default.VideoLibrary, null, modifier = Modifier.size(55.dp), tint = MaterialTheme.colorScheme.primary)
            Text("One-time FTP configuration", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Enter your FTP server details. They are saved on this device, and the app reconnects automatically.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(host, { host = it }, label = { Text("FTP server IP or hostname") },
                placeholder = { Text("192.168.1.254") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, label = { Text("FTP port") },
                modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(username, { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(password, { password = it }, label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(directory, { directory = it }, label = { Text("Media folder") },
                placeholder = { Text("/Movies") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            HorizontalDivider()
            Text("Movie posters and information", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(token, { token = it }, label = { Text("TMDb API key or Read Access Token (optional)") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("For automatic posters, add your TMDb v3 API key or API Read Access Token from themoviedb.org. Without it, videos remain browsable by filename. This product uses the TMDb API but is not endorsed or certified by TMDb.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
            Button(onClick = {
                onConnect(FtpSettings(host.trim(), port.toIntOrNull() ?: 21, username.trim(), password, directory.trim(), token.trim()))
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Icon(Icons.Default.Cable, null)
                Spacer(Modifier.width(8.dp))
                Text(if (canExit) "Save and reconnect" else "Connect and build library")
            }
            Text("FTP is unencrypted. Use only on a trusted local network or through a private VPN.",
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryScreen(
    entries: List<MediaEntry>, message: String, loading: Boolean,
    onRescan: () -> Unit, onSettings: () -> Unit, onOffload: () -> Unit, onSelect: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    val types = listOf("All", "Movies", "TV Shows", "Continue")
    val filtered = remember(entries, query, category) {
        entries.filter { item ->
            (category == "All" || (category == "Movies" && !item.isEpisode) ||
                (category == "TV Shows" && item.isEpisode) ||
                (category == "Continue" && item.lastPositionMs > 5_000)) &&
                (query.isBlank() || item.displayTitle.contains(query, ignoreCase = true))
        }.sortedWith(compareBy<MediaEntry> { it.displayTitle.lowercase(Locale.ROOT) }
            .thenBy { it.episodeCode.orEmpty() })
    }
    val featured = remember(entries) { entries.firstOrNull { it.backdrop != null && !it.isEpisode }
        ?: entries.firstOrNull { it.poster != null } ?: entries.firstOrNull() }
    val recent = remember(entries) { entries.filter { it.lastPositionMs > 5_000 && it.durationMs > it.lastPositionMs + 10_000 } }
    val curated = remember(entries) { entries.filter { it.poster != null }.take(12) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayCircleFilled, null, tint = Color(0xFF73AEFF))
                    Spacer(Modifier.width(8.dp))
                    Text("AURORA", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("  MEDIA", color = Color(0xFFAFC0DA), letterSpacing = 1.sp)
                }
            }, actions = {
                IconButton(onClick = onRescan, enabled = !loading) { Icon(Icons.Default.Refresh, "Scan FTP") }
                IconButton(onClick = onOffload) { Icon(Icons.Default.CloudUpload, "Move phone files to FTP") }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "FTP and TMDb") }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D18)))
        }, bottomBar = {
            NavigationBar(containerColor = Color(0xFF101827), tonalElevation = 0.dp) {
                types.forEach { item ->
                    NavigationBarItem(selected = category == item, onClick = { category = item },
                        icon = { Icon(when (item) {
                            "Movies" -> Icons.Default.Movie
                            "TV Shows" -> Icons.Default.Tv
                            "Continue" -> Icons.Default.PlayCircle
                            else -> Icons.Default.Home
                        }, null) }, label = { Text(item) })
                }
            }
        }) { padding ->
        Column(Modifier.fillMaxSize().background(nightGradient).padding(padding)) {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFF73AEFF))
            LazyVerticalGrid(columns = GridCells.Adaptive(138.dp),
                contentPadding = PaddingValues(bottom = 28.dp, start = 14.dp, end = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        if (category == "All" && query.isBlank() && featured != null) {
                            FeaturedBanner(featured, onSelect = { onSelect(featured.id) })
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search your movies and shows") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true, shape = RoundedCornerShape(18.dp))
                        if (message.isNotBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text(message, color = Color(0xFF9EADC6), style = MaterialTheme.typography.bodySmall)
                        }
                        if (category == "All" && query.isBlank() && recent.isNotEmpty()) {
                            Spacer(Modifier.height(22.dp))
                            Text("Continue Watching", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(12.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                rowItems(recent.take(10), key = { it.id }) { item ->
                                    Box(Modifier.width(158.dp)) { PosterTile(item, onClick = { onSelect(item.id) }) }
                                }
                            }
                        }
                        if (category == "All" && query.isBlank() && curated.isNotEmpty()) {
                            Spacer(Modifier.height(24.dp))
                            Text("Handpicked from Your Library", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(12.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                rowItems(curated, key = { it.id }) { item ->
                                    Box(Modifier.width(158.dp)) { PosterTile(item, onClick = { onSelect(item.id) }) }
                                }
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                        Text(when (category) {
                            "Movies" -> "Movies"; "TV Shows" -> "Series & Episodes"
                            "Continue" -> "Pick Up Where You Left Off"; else -> "Explore Your Collection"
                        }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        Text("${filtered.size} videos available from your FTP server",
                            color = Color(0xFF9EADC6), style = MaterialTheme.typography.bodySmall)
                    }
                }
                items(filtered, key = { it.id }) { item -> PosterTile(item, onClick = { onSelect(item.id) }) }
                if (filtered.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(Modifier.fillMaxWidth().padding(38.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.VideoLibrary, null, Modifier.size(56.dp), tint = Color(0xFF73AEFF))
                        Spacer(Modifier.height(12.dp))
                        Text(if (loading) "Scanning your FTP library…" else "Nothing here yet")
                        Spacer(Modifier.height(5.dp))
                        Text("Try a refresh or another search.", color = Color(0xFF9EADC6))
                    }
                }
            }
        }
    }
}

@Composable
private fun FeaturedBanner(item: MediaEntry, onSelect: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(286.dp)
        .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))) {
        if (item.backdrop != null) AsyncImage(model = item.backdrop, contentDescription = null,
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(
            listOf(Color(0xFF1B3764), Color(0xFF101827)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            Color(0x22040812), Color(0x55040812), Color(0xEE080D18)))))
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("FEATURED FROM YOUR LIBRARY", color = Color(0xFF8DD4FF),
                style = MaterialTheme.typography.labelSmall, letterSpacing = 2.sp, fontWeight = FontWeight.ExtraBold)
            Text(item.displayTitle, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            item.description?.let {
                Text(it, maxLines = 2, overflow = TextOverflow.Ellipsis, color = Color(0xFFDDDFE9),
                    style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onSelect, shape = RoundedCornerShape(13.dp)) {
                Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(6.dp))
                Text("View & Play", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PosterTile(item: MediaEntry, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF202C40)), contentAlignment = Alignment.Center) {
            if (item.poster != null) AsyncImage(model = item.poster,
                contentDescription = "${item.displayTitle} poster", modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop)
            else Icon(Icons.Default.Movie, null, modifier = Modifier.size(44.dp), tint = Color(0xFF73AEFF))
            if (item.lastPositionMs > 0L && item.durationMs > 0L) {
                LinearProgressIndicator(progress = { (item.lastPositionMs.toFloat() / item.durationMs).coerceIn(0f, 1f) },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(item.displayTitle, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        item.year?.let { Text(it.toString(), style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF97A9C7)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailsScreen(
    item: MediaEntry, recommendations: List<MediaEntry>, onBack: () -> Unit,
    onPlay: (Boolean) -> Unit, onSelect: (String) -> Unit
) {
    Scaffold(containerColor = Color(0xFF080D18), topBar = {
        TopAppBar(title = { Text("Movie Details", fontWeight = FontWeight.Bold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D18)))
    }) { pad ->
        Column(Modifier.fillMaxSize().background(nightGradient).padding(pad)
            .verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(240.dp)) {
                if (item.backdrop != null) AsyncImage(item.backdrop, null, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop)
                else Box(Modifier.fillMaxSize().background(Color(0xFF202C40)))
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
                    Color.Transparent, Color(0xFF080D18)))))
            }
            Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(item.displayTitle, style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black)
                Text(listOfNotNull(item.year?.toString(), item.episodeCode,
                    item.bytes.takeIf { it > 0 }?.let { "%.1f GB".format(it.toDouble() / 1_073_741_824) })
                    .joinToString("  •  "), color = Color(0xFFAAB7CB))
                if (item.lastPositionMs > 5_000L && item.durationMs > item.lastPositionMs + 10_000L) {
                    Button(onClick = { onPlay(false) }, modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp))
                        Text("Resume Playback", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { onPlay(true) }, modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Replay, null); Spacer(Modifier.width(8.dp))
                        Text("Start from Beginning")
                    }
                } else {
                    Button(onClick = { onPlay(true) }, modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp))
                        Text("Play from Beginning", fontWeight = FontWeight.Bold)
                    }
                }
                if (!item.description.isNullOrBlank()) Text(item.description,
                    style = MaterialTheme.typography.bodyLarge, color = Color(0xFFE0E5F0))
                if (recommendations.isNotEmpty()) {
                    HorizontalDivider(color = Color(0xFF25334A))
                    Text("More Like This", style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                        rowItems(recommendations, key = { it.id }) { suggestion ->
                            Box(Modifier.width(138.dp)) {
                                PosterTile(suggestion, onClick = { onSelect(suggestion.id) })
                            }
                        }
                    }
                }
                HorizontalDivider(color = Color(0xFF25334A))
                Text("FTP source", color = Color(0xFF97A9C7), style = MaterialTheme.typography.labelLarge)
                Text(item.path, color = Color(0xFF71829E), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
