package com.aurora.media.offload

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.TimeUnit

object OffloadScheduler {
    const val NOW = "aurora_phone_offload_now"
    const val DAILY = "aurora_phone_offload_daily"
    private val network = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun moveNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<OffloadWorker>().setConstraints(network).build()
        WorkManager.getInstance(context).enqueueUniqueWork(NOW, ExistingWorkPolicy.KEEP, request)
    }

    fun configureDaily(context: Context, enabled: Boolean) {
        val work = WorkManager.getInstance(context)
        if (enabled) {
            val request = PeriodicWorkRequestBuilder<OffloadWorker>(24, TimeUnit.HOURS)
                .setConstraints(network).build()
            work.enqueueUniquePeriodicWork(DAILY, ExistingPeriodicWorkPolicy.UPDATE, request)
        } else work.cancelUniqueWork(DAILY)
    }
}

class OffloadWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    companion object {
        private const val CHANNEL = "aurora_file_offload"
        private const val NOTIFICATION_ID = 1735
        private val transferLock = Mutex()
    }

    private fun notification(text: String): Notification {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Aurora file transfer", NotificationManager.IMPORTANCE_LOW)
        )
        return NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Aurora Media • Move files to FTP")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override suspend fun doWork(): Result = transferLock.withLock {
        val prefs = OffloadPreferences(applicationContext)
        if (!prefs.allowDeletion || prefs.sourceTree.isBlank()) return@withLock Result.failure(
            workDataOf("summary" to "Select a folder and enable verified deletion first")
        )
        if (!OffloadEngine.isOnWifi(applicationContext)) {
            // Never move files over cellular, even if WorkManager reports CONNECTED.
            return@withLock Result.retry()
        }
        try {
            setForeground(ForegroundInfo(NOTIFICATION_ID, notification("Verifying FTP connection…")))
            val report = OffloadEngine.run(applicationContext, progress = { current, filename ->
                setProgress(workDataOf("summary" to current.display(), "filename" to filename,
                    "moved" to current.moved, "freed" to current.bytesFreed))
            }, stopped = { isStopped })
            val summary = report.display()
            prefs.lastReport = summary
            Result.success(workDataOf("summary" to summary))
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: OffloadEngine.TransferInterrupted) {
            Result.retry()
        } catch (error: Exception) {
            val message = "Move stopped: ${error.message ?: "Unknown error"}. Unverified local files were preserved."
            prefs.lastReport = message
            Result.failure(workDataOf("summary" to message))
        }
    }
}
