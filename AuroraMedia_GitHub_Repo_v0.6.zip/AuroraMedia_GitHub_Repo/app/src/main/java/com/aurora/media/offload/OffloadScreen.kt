package com.aurora.media.offload

import android.Manifest
import android.content.Intent
import android.os.Build
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.WorkInfo
import androidx.work.WorkManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OffloadScreen(onBack: () -> Unit, ftpReady: Boolean) {
    val context = LocalContext.current
    val saved = remember(context) { OffloadPreferences(context) }
    var source by remember { mutableStateOf(saved.sourceTree) }
    var destination by remember { mutableStateOf(saved.destination) }
    var deletionEnabled by remember { mutableStateOf(saved.allowDeletion) }
    var daily by remember { mutableStateOf(saved.automatic) }
    var message by remember { mutableStateOf("") }
    var confirmOneTime by remember { mutableStateOf(false) }
    var confirmAutomatic by remember { mutableStateOf(false) }

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { picked: Uri? ->
        if (picked != null) {
            try {
                context.contentResolver.takePersistableUriPermission(picked,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                saved.sourceTree = picked.toString()
                source = picked.toString()
                message = "Folder permission saved. Contents and subfolders will be moved to FTP."
            } catch (error: Exception) {
                message = "Folder permission couldn't be saved: ${error.message}"
            }
        }
    }
    val askNotification = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { /* optional */ }
    val manager = remember(context) { WorkManager.getInstance(context) }
    val info by remember(manager) { manager.getWorkInfosForUniqueWorkLiveData(OffloadScheduler.NOW) }
        .observeAsState(emptyList())
    val work = info.firstOrNull { it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED }
        ?: info.firstOrNull()
    val inProgress = work?.state == WorkInfo.State.RUNNING || work?.state == WorkInfo.State.ENQUEUED
    val summary = work?.let {
        if (inProgress) it.progress.getString("summary") ?: "Queued or preparing transfer…"
        else it.outputData.getString("summary")
    } ?: saved.lastReport

    BackHandler { onBack() }
    Scaffold(topBar = {
        TopAppBar(title = { Text("Move files to FTP") }, navigationIcon = {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
        })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
            .padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
            Text("Phone → FTP → Free space", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Move files from a selected phone folder to your saved FTP server. " +
                "Only cryptographically verified uploads are deleted from the phone. " +
                "The source folder structure is preserved on FTP.")
            HorizontalDivider()
            Text("1. Source folder on this phone", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.FolderOpen, null)
                Spacer(Modifier.width(8.dp))
                Text(if (source.isBlank()) "Choose a folder" else "Change selected folder")
            }
            Text(if (source.isBlank()) "No phone folder selected" else "Selected: ${Uri.parse(source).lastPathSegment ?: source}",
                style = MaterialTheme.typography.bodySmall)
            Text("Android's folder picker grants access only to the folder you choose. Some protected system folders can't be selected.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            HorizontalDivider()
            Text("2. Destination on your FTP server", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(destination, onValueChange = { destination = it },
                label = { Text("FTP destination directory") }, singleLine = true,
                modifier = Modifier.fillMaxWidth(), supportingText = { Text("Example: /usb1_1/PhoneArchive") })
            HorizontalDivider()
            Text("3. Free phone storage", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = deletionEnabled, onCheckedChange = {
                    deletionEnabled = it
                    saved.allowDeletion = it
                    if (!it) {
                        daily = false; saved.automatic = false
                        OffloadScheduler.configureDaily(context, false)
                    }
                })
                Spacer(Modifier.width(8.dp))
                Text("Delete each local file ONLY after successful FTP upload and SHA-256 verification",
                    modifier = Modifier.weight(1f))
            }
            Text("Files are never deleted when an upload fails, is interrupted, or can't be verified. " +
                "The app does not delete or overwrite existing FTP files. Empty phone folders are kept.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = {
                try {
                    saved.destination = OffloadEngine.cleanDestination(destination)
                    if (deletionEnabled) confirmOneTime = true else message = "Enable verified local deletion first"
                } catch (error: Exception) { message = error.message.orEmpty() }
            }, enabled = ftpReady && source.isNotBlank() && deletionEnabled && !inProgress,
                modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(9.dp)); Text("Move now & free space")
            }
            HorizontalDivider()
            Text("4. Automatic offloading", style = MaterialTheme.typography.titleMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = daily, onCheckedChange = { enabled ->
                    if (enabled) confirmAutomatic = true else {
                        daily = false; saved.automatic = false
                        OffloadScheduler.configureDaily(context, false)
                    }
                }, enabled = ftpReady && source.isNotBlank() && deletionEnabled)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Daily automatic move (Wi-Fi only)")
                    Text("Android may delay background runs to save battery.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text("Files moved: " + (summary ?: saved.lastReport), style = MaterialTheme.typography.bodySmall)
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
            if (inProgress) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text(work?.progress?.getString("filename") ?: "Waiting for Wi-Fi…", style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { manager.cancelUniqueWork(OffloadScheduler.NOW) }) { Text("Cancel queued/manual transfer") }
            }
            Text("FTP sends passwords and files without encryption. Use trusted home Wi-Fi or a private VPN. " +
                "Keep another backup of important files until the move has been tested.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }

    if (confirmOneTime) AlertDialog(onDismissRequest = { confirmOneTime = false },
        title = { Text("Move files and delete originals?") },
        text = { Text("Aurora will copy every file from the selected folder to $destination. " +
            "After comparing SHA-256 hashes of the original and FTP copy, it will delete the local file. " +
            "An interrupted or unverified file remains on your phone. Continue?") },
        confirmButton = { TextButton(onClick = {
            confirmOneTime = false
            if (Build.VERSION.SDK_INT >= 33) askNotification.launch(Manifest.permission.POST_NOTIFICATIONS)
            OffloadScheduler.moveNow(context)
            message = "Move queued. Keep your phone on Wi-Fi."
        }) { Text("Move & delete verified") } },
        dismissButton = { TextButton(onClick = { confirmOneTime = false }) { Text("Cancel") } })

    if (confirmAutomatic) AlertDialog(onDismissRequest = { confirmAutomatic = false },
        title = { Text("Enable automatic local deletion?") },
        text = { Text("Every day, while connected to Wi-Fi, the app will move new files in this folder to FTP " +
            "and delete each local original once the destination is verified. This may run when the app is closed. " +
            "Only enable this after testing a manual move.") },
        confirmButton = { TextButton(onClick = {
            confirmAutomatic = false
            try {
                saved.destination = OffloadEngine.cleanDestination(destination)
                saved.automatic = true; daily = true
                OffloadScheduler.configureDaily(context, true)
                message = "Automatic daily offloading enabled"
            } catch (error: Exception) { message = error.message.orEmpty() }
        }) { Text("Enable auto-move") } },
        dismissButton = { TextButton(onClick = { confirmAutomatic = false }) { Text("Cancel") } })
}
