import com.aurora.media.player.VideoBounds
import com.aurora.media.player.VideoScaling

fun main() {
    require(VideoScaling.compute(2400,1080,16f/9f,false) == VideoBounds(1920,1080))
    require(VideoScaling.compute(2400,1080,16f/9f,true) == VideoBounds(2400,1350))
    require(VideoScaling.compute(1080,2400,16f/9f,false) == VideoBounds(1080,608))
    require(VideoScaling.compute(480,270,16f/9f,false) == VideoBounds(480,270))
    require(VideoScaling.compute(2400,1080,4f/3f,false) == VideoBounds(1440,1080))
    require(VideoScaling.compute(2400,1080,4f/3f,true) == VideoBounds(2400,1800))
    println("PASS: Fit/Fill source-aspect geometry, crop and PiP/fullscreen resizing")
}
