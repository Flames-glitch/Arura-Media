import com.aurora.media.metadata.RatingValue
import com.aurora.media.metadata.compareTmdbRatings

fun main() {
    val values = listOf(
        RatingValue(null, 0), RatingValue(8.0, 5),
        RatingValue(9.0, 100), RatingValue(8.0, 350),
        RatingValue(0.0, 0), RatingValue(11.0, 1)
    ).sortedWith(::compareTmdbRatings)
    check(values.map { it.average } == listOf(9.0, 8.0, 8.0, null, 0.0, 11.0))
    check(values[1].votes == 350)
    println("PASS: Highest-rated first; votes break ties; missing/invalid ratings last")
}
