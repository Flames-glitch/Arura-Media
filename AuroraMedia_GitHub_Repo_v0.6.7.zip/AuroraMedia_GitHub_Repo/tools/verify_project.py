"""Aurora Media static checks; no Android SDK required. Not a substitute for Gradle compile/device testing."""
from pathlib import Path
from xml.etree import ElementTree
import re

root = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/aurora/media/MainActivity.kt',
    'app/src/main/java/com/aurora/media/player/VlcSession.kt',
    'app/src/main/java/com/aurora/media/player/PlayerScreen.kt',
    'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt',
    'app/src/main/java/com/aurora/media/metadata/TmdbService.kt',
]
for f in required:
    if not (root / f).is_file():
        raise SystemExit(f'Missing essential source file: {f}')
manifest = ElementTree.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
android = '{http://schemas.android.com/apk/res/android}'
permissions = [x.attrib.get(android + 'name') for x in manifest.findall('uses-permission')]
if 'android.permission.INTERNET' not in permissions:
    raise SystemExit('INTERNET permission missing')
app = manifest.find('application')
if app is None or not app.attrib.get(android+'label') == 'Aurora Media':
    raise SystemExit('Aurora Media app label missing')
source_dir = root / 'app/src/main/java'
source = '\n'.join(f.read_text() for f in source_dir.rglob('*.kt'))
if 'Media.Slave.Type.Subtitle' in source:
    raise SystemExit('Unsupported Media.Slave.Type.Subtitle reference')
if re.search(r'fun\s+setSpeed\s*\(', source):
    raise SystemExit('Potential Kotlin property setter clash: setSpeed')
if 'session::setSpeed' in source:
    raise SystemExit('Stale playback speed method reference')
if 'session::updateSpeed' not in source:
    raise SystemExit('Missing playback speed UI callback')
if 'fun updateSpeed(value: Float)' not in source:
    raise SystemExit('Missing playback speed method')
ftp = (root / 'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt').read_text()
if 'FTP.BINARY_FILE_TYPE' not in ftp or 'enterLocalPassiveMode()' not in ftp:
    raise SystemExit('FTP binary/passive mode missing')
if 'ftp://' not in ftp:
    raise SystemExit('FTP stream URL missing')
if 'sftp://' in source.lower():
    raise SystemExit('SFTP included unexpectedly')
build = (root / 'app/build.gradle.kts').read_text()
if 'applicationId = "com.aurora.media"' not in build:
    raise SystemExit('Wrong application ID')
if 'compileSdk = 35' not in build:
    raise SystemExit('Android SDK 35 mismatch')
if 'org.videolan.android:libvlc-all:3.5.1' not in build:
    raise SystemExit('Expected VLC dependency missing')
print('PASS: source structure, XML, FTP-only configuration, LibVLC references, Gradle constants')
print(f'Source files: {len(list(source_dir.rglob("*.kt")))} Kotlin files')

# V0.6.2 regression gates: offloader deliberately removed; FTP playback untouched.
ui = (root / 'app/src/main/java/com/aurora/media/ui/AuroraApp.kt').read_text()
vm = (root / 'app/src/main/java/com/aurora/media/ui/AuroraViewModel.kt').read_text()
player = (root / 'app/src/main/java/com/aurora/media/player/PlayerScreen.kt').read_text()
session = (root / 'app/src/main/java/com/aurora/media/player/VlcSession.kt').read_text()
activity = (root / 'app/src/main/java/com/aurora/media/MainActivity.kt').read_text()
cleaner = (root / 'app/src/main/java/com/aurora/media/ftp/FilenameCleaner.kt').read_text()
properties = (root / 'gradle.properties').read_text()
app_source = (root / 'app/src/main/java/com/aurora/media/AuroraApplication.kt').read_text()
legacy_worker = (root / 'app/src/main/java/com/aurora/media/offload/OffloadWorker.kt').read_text()
rotation = (root / 'app/src/main/java/com/aurora/media/ui/SpotlightRotation.kt').read_text()
manifest_text = (root / 'app/src/main/AndroidManifest.xml').read_text()
regressions = {
    "AndroidX enabled": "android.useAndroidX=true" in properties,
    "Old malformed remote constant absent": "KEYCODE_HEADSETPHOOK" not in source,
    "Previous speed setter clash absent": "fun setSpeed(" not in source,
    "Previous LibVLC subtitle enum absent": "Media.Slave.Type.Subtitle" not in source,
    "Original FTP stream retained": "ftp://" in ftp and "FtpScanner.mediaUrl" in session,
    "Start from Beginning retained": "Start from Beginning" in ui and "fromBeginning" in vm,
    "Playback suggestions retained": "What to watch next" in player and "recommendationsFor" in vm,
    "Screen awake during playback": "FLAG_KEEP_SCREEN_ON" in player,
    "PiP dismissal pauses playback without resetting position": "onPictureInPictureModeChanged" in activity and "pauseForBackground(autoResume = !lastPiPExitPending)" in activity,
    "Delayed buffering spinner": "bufferingCheck" in session and "> 3000L" in session,
    "Filename watermark cleanup": "websitePrefix" in cleaner and "solar" in cleaner,
    "Cached movie title refresh": "cached.title == current.title" in vm,
    "Featured carousel has timer": "delay(8_000L)" in ui,
    "Featured carousel traverses list": "nextSpotlightIndex" in ui and "previousSpotlightIndex" in ui,
    "Featured uses actual FTP entries": "val movies = entries.filterNot" in ui,
    "Single-item rotation safe": "if (count <= 1) 0" in rotation,
    "FTP upload button removed": "CloudUpload" not in ui and "onOffload" not in ui,
    "FTP upload screen removed": "Screen.Offload" not in source,
    "FTP upload engine removed": not (root / 'app/src/main/java/com/aurora/media/offload/OffloadEngine.kt').exists(),
    "Old queued moves cancelled": "cancelUniqueWork(\"aurora_phone_offload_now\")" in app_source and "cancelUniqueWork(\"aurora_phone_offload_daily\")" in app_source,
    "Old jobs cannot run uploads": "override suspend fun doWork(): Result = Result.failure()" in legacy_worker,
    "Foreground upload service not requested": "FOREGROUND_SERVICE_DATA_SYNC" not in manifest_text,
    "App version code incremented": "versionCode = 16" in build and 'versionName = "0.6.7"' in build,
}
for label, ok in regressions.items():
    if not ok: raise SystemExit("Regression detected: " + label)
print(f"PASS: {len(regressions)} V0.6.2 rotation/player/safe-retirement regression checks")

# V0.6.3 preflight: preset FTP connection, editable overrides, India-specific TMDb discovery.
settings = (root / 'app/src/main/java/com/aurora/media/data/SecureSettings.kt').read_text()
metadata = (root / 'app/src/main/java/com/aurora/media/metadata/TmdbService.kt').read_text()
models = (root / 'app/src/main/java/com/aurora/media/data/Models.kt').read_text()
checks = {
    "FTP host prefilled": 'preferences.getString("host", "192.168.1.254")' in settings,
    "FTP username prefilled": 'preferences.getString("username", "userAdmin")' in settings,
    "FTP password first-run preset": 'preferences.contains("password")' in settings and 'else "tsbb@123"' in settings,
    "FTP directory first-run preset": 'preferences.getString("directory", "/usb1_1/movies")' in settings,
    "FTP fields editable": all(f'{{ {field} = it }}' in ui for field in ["host", "username", "password", "directory"]),
    "Encrypted later-saved FTP password": '.putString("password", encrypt(settings.password))' in settings,
    "Existing settings prioritized": 'preferences.contains("password")' in settings and 'preferences.getString("host"' in settings,
    "TMDb default credential for upcoming films": 'tmdbToken = decrypt' in settings and '.ifBlank {' in settings,
    "TMDb theatre discover endpoint": 'discover/movie' in metadata,
    "India theatre region": 'upcomingTheatrical("IN")' in vm and 'with_release_type=2%7C3' in metadata,
    "Upcoming tab": '"Upcoming"' in ui and 'UpcomingTheatresSection' in ui,
    "Upcoming items not FTP playable": 'data class UpcomingMovie' in models and 'Coming to theatres • Not in your FTP library' in ui,
    "Upcoming refresh and error handling": 'onRefresh = { onLoadUpcoming(true) }' in ui and 'upcomingError' in vm,
}
for label, ok in checks.items():
    if not ok: raise SystemExit("V0.6.3 regression detected: " + label)
print(f'PASS: {len(checks)} V0.6.3 FTP preset and theatres checks')

# V0.6.3 premium-player and trailer regression gates
trailer = (root / 'app/src/main/java/com/aurora/media/metadata/TrailerSelection.kt').read_text()
new_checks = {
    'Real TMDb trailer video endpoint': '/videos?language=en-US' in metadata,
    'YouTube trailer validated before URL creation': 'selectBestYouTubeKey(candidates)' in metadata and '[A-Za-z0-9_-]{11}' in trailer,
    'YouTube search when video metadata absent': 'youtube.com/results?search_query=' in ui,
    'Trailer fetched off UI thread': 'withContext(Dispatchers.IO)' in ui,
    'Upcoming tab retains theatre movies': 'UpcomingTheatresSection' in ui and 'UpcomingMovie' in ui,
    'Trailer does not add FTP entries': 'UpcomingMovie' in ui and 'onSelect = { selectedUpcoming = it }' in ui,
    'Swipe seeking': 'SwipeMode.SEEK' in player and 'session.seek(gestureSeek)' in player,
    'Left brightness gesture': 'SwipeMode.BRIGHTNESS' in player and 'params.screenBrightness = level' in player,
    'Right volume gesture': 'SwipeMode.VOLUME' in player and 'setStreamVolume' in player,
    'VLC-style compact controls': 'Icons.Default.Replay10' in player and 'Icons.Default.Forward10' in player,
    'Combined audio and subtitle picker': '"tracks" -> AlertDialog' in player and 'trackTab' in player,
    'PiP retained': 'enterPlayerPiP' in player and 'pauseForBackground' in activity,
    'No cast control in player': 'Cast' not in player and 'cast' not in player.lower(),
    'Player uses transparent gradient overlays': 'Brush.verticalGradient' in player,
    'Player controls auto-hide': 'delay(5_000L)' in player,
    'App version incremented for home redesign': 'versionName = "0.6.7"' in build,
    'Video surface rebound on AndroidView update': 'session.attach(it, parent)' in player,
    'Background playback pauses not stops': 'pauseForBackground' in activity and 'playerSession?.stopPlayback()' not in activity,
    'Center play pause control uses screen center': 'Modifier.align(Alignment.Center)' in player,
    'Retain video position on return': 'resumeAfterBackground' in activity and 'resumeAfterSuspension' in session,

}
for label, ok in new_checks.items():
    if not ok: raise SystemExit('Premium player/trailer regression detected: ' + label)
print(f'PASS: {len(new_checks)} premium UI, gesture, PiP, trailer and player checks')

# V0.6.4 rating-based recommendations and pagination dots.
rating_source = (root / 'app/src/main/java/com/aurora/media/metadata/RatingOrder.kt').read_text()
rating_checks = {
    "TMDb rating persisted": 'tmdbRatingFetched' in models and 'put("tmdbRating"' in models,
    "TMDb rating collected": 'vote_average' in metadata and 'vote_count' in metadata,
    "Cached matches backfilled": '!it.tmdbRatingFetched' in vm,
    "Recommendations rank by rating": 'compareTmdbRatings' in vm,
    "Homepage featured sorted by rating": 'compareTmdbRatings' in ui,
    "Unrated movies placed last": 'if (left == null) return 1' in rating_source,
    "Carousel uses dots": 'repeat(count) { position ->' in ui and 'Text("${index + 1} / $count"' not in ui,
}
for label, ok in rating_checks.items():
    if not ok: raise SystemExit("Rating update regression detected: " + label)
print(f"PASS: {len(rating_checks)} rating and carousel-dot regression checks")

# V0.6.6 HOME DISCOVERY REGRESSION GATES
app_layout = (root / 'app/src/main/java/com/aurora/media/ui/AuroraApp.kt').read_text()
layout_checks = {
    "Only four bottom navigation destinations": 'listOf("All", "Movies", "TV Shows", "Upcoming")' in app_layout,
    "Continue navigation destination removed": '"Continue" -> Icons.Default.PlayCircle' not in app_layout,
    "Continue Watching remains on Home": 'if (recent.isNotEmpty())' in app_layout and 'Text("Continue Watching"' in app_layout,
    "Home has recommended FTP movies": 'Text("Suggested Movies"' in app_layout and 'rowItems(suggestedMovies' in app_layout,
    "Picked for You moved to Movies": 'if (category == "Movies")' in app_layout and 'Text("Picked for You"' in app_layout,
    "Explore Collection moved to Movies": 'Text("Explore Your Collection"' in app_layout,
    "Full collection grid hidden from Home": 'if (category == "Movies" || category == "TV Shows") {' in app_layout,
    "Upcoming separately accessible": 'if (category == "Upcoming")' in app_layout,
    "No theatre promo on Home": 'Text("Coming to Theatres"' not in app_layout,
    "Search only in library tabs": 'Search and full browsing belong to Movies and TV Shows, not Home.' in app_layout,
    "App package unchanged": 'applicationId = "com.aurora.media"' in build,
    "Android version increased": 'versionCode = 16' in build and 'versionName = "0.6.7"' in build,
}
for label, ok in layout_checks.items():
    if not ok: raise SystemExit('Home layout regression detected: ' + label)
print(f'PASS: {len(layout_checks)} V0.6.6 Home/Movies navigation and layout checks')

# V0.6.6 geometry and PiP regression checks.
scaling = (root / 'app/src/main/java/com/aurora/media/player/VideoScaling.kt').read_text()
scaling_test = (root / 'app/src/test/java/com/aurora/media/player/VideoScalingTest.kt').read_text()
video_checks = {
    'Current viewport width/height in pixels': 'updateVideoWindow(right - left, bottom - top)' in player,
    'No SurfaceHolder buffer-driven sizing': 'session.updateVideoWindow(width, height)' not in player,
    'LibVLC source aspect callback': 'OnNewVideoLayoutListener' in session and 'visibleWidth' in session and 'sarNum' in session,
    'Video surface is clipped and centered': 'clipChildren = true' in player and 'Gravity.CENTER' in player,
    'Fit/Fill computed preserving source ratio': 'VideoScaling.compute(' in session and 'zoomToFill' in scaling,
    'No aspect-ratio stretching': 'player.aspectRatio = null' in session and '"${videoWindowWidth}:${videoWindowHeight}"' not in session,
    'Gesture double-tap toggles Fit/Fill': 'onDoubleTap' in player and 'session.toggleAspect()' in player,
    'Pinch controls Fit/Fill': 'calculateZoom()' in player and 'cumulativeZoom' in player,
    'Existing volume gesture retained': 'SwipeMode.VOLUME' in player and 'setStreamVolume' in player,
    'Existing brightness gesture retained': 'SwipeMode.BRIGHTNESS' in player and 'params.screenBrightness = level' in player,
    'Existing seek gesture retained': 'SwipeMode.SEEK' in player and 'session.seek(gestureSeek)' in player,
    'Fullscreen restores surface without restarting media': 'restoreVideoOutput()' in session and 'if (started || closed || needsVideoRebind) return' in session,
    'No media restarted on PiP resize': 'private fun layoutVideoSurface()' in session and 'player.play()' not in session.split('private fun layoutVideoSurface()')[1].split('fun updateVideoWindow')[0],
    'Hardware and software decoder choices': 'media.setHWDecoderEnabled(DecoderChoice.enableHardware(decoderMode), false)' in session,
    '4K video scaling tests': 'sixteenByNineOnWidePhone' in scaling_test and 'portraitAndPipResize' in scaling_test,
    'Java 17 action is not deprecated v4': 'actions/setup-java@v5' in (root / '.github/workflows/build-apk.yml').read_text(),
    'Build version incremented': 'versionCode = 16' in build and 'versionName = "0.6.7"' in build,
}
for label, ok in video_checks.items():
    if not ok: raise SystemExit('V0.6.6 regression detected: ' + label)
print(f'PASS: {len(video_checks)} V0.6.6 PiP/4K/gesture/video-scaling checks')

# V0.6.7: explicit FFmpeg software decoder mode and safe switch behavior.
decoder = (root / 'app/src/main/java/com/aurora/media/player/DecoderChoice.kt').read_text()
decoder_checks = {
    "Decoder mode persists locally": 'putString("decoder_mode", selected)' in session,
    "FFmpeg software mode disables HW decoding": 'media.setHWDecoderEnabled(DecoderChoice.enableHardware(decoderMode), false)' in session and 'mode) != SOFTWARE' in decoder,
    "Decoder switch checkpoints current time": 'pendingDecoderSeekMs = resumePosition' in session,
    "Decoder waits for seekability": 'player.isSeekable && durationMs > 0L' in session,
    "Decode error can retry in software": 'Retry with software decoder' in player,
    "Player settings expose decoder choice": '"decoder" -> OptionDialog' in player,
    "Existing PiP lifecycle unchanged": 'resumeAfterBackground' in activity,
    "Version updated": 'versionCode = 16' in build and 'versionName = "0.6.7"' in build,
}
for label, ok in decoder_checks.items():
    if not ok: raise SystemExit('Decoder regression detected: ' + label)
print(f'PASS: {len(decoder_checks)} v0.6.7 decoder and position regression checks')
