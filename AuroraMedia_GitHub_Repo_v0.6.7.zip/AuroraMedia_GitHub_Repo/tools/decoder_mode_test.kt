import com.aurora.media.player.DecoderChoice

fun main() {
    check(DecoderChoice.normalize(null) == "Auto")
    check(DecoderChoice.normalize("strange") == "Auto")
    check(DecoderChoice.normalize("Software") == "Software")
    check(DecoderChoice.enableHardware("Auto"))
    check(!DecoderChoice.enableHardware("Software"))
    check(DecoderChoice.display("Software") == "Software (FFmpeg)")
    println("PASS: explicit software decoder choice and safe defaults")
}
