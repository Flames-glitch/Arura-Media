package com.aurora.media.player

/** Safe user preference: LibVLC ships its own software decoder; no external codec APKs. */
internal object DecoderChoice {
    const val AUTO = "Auto"
    const val SOFTWARE = "Software"

    fun normalize(value: String?): String =
        if (value == SOFTWARE) SOFTWARE else AUTO

    fun enableHardware(mode: String): Boolean = normalize(mode) != SOFTWARE

    fun display(mode: String): String =
        if (normalize(mode) == SOFTWARE) "Software (FFmpeg)" else "Auto (hardware preferred)"
}
