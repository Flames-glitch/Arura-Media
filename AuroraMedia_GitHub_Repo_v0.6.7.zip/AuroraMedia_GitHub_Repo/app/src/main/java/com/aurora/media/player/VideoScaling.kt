package com.aurora.media.player

import kotlin.math.roundToInt

/** Exact pixel bounds for a source-aspect-preserving Android video surface. */
data class VideoBounds(val width: Int, val height: Int)

object VideoScaling {
    fun compute(
        viewportWidth: Int,
        viewportHeight: Int,
        sourceAspectRatio: Float,
        zoomToFill: Boolean
    ): VideoBounds {
        require(viewportWidth > 0 && viewportHeight > 0)
        val w = viewportWidth.toFloat()
        val h = viewportHeight.toFloat()
        val ratio = sourceAspectRatio.takeIf { it.isFinite() && it > 0f } ?: w / h
        val viewportRatio = w / h
        return if ((!zoomToFill && ratio >= viewportRatio) || (zoomToFill && ratio < viewportRatio)) {
            VideoBounds(viewportWidth, (w / ratio).roundToInt().coerceAtLeast(1))
        } else {
            VideoBounds((h * ratio).roundToInt().coerceAtLeast(1), viewportHeight)
        }
    }
}
