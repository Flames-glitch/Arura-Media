package com.aurora.media.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.aurora.media.R
import com.aurora.media.data.FtpSettings
import com.aurora.media.data.MediaEntry
import com.aurora.media.data.UpcomingMovie
import com.aurora.media.player.PlayerScreen
import java.util.Locale
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import com.aurora.media.metadata.TmdbService
import com.aurora.media.metadata.RatingValue
import com.aurora.media.metadata.compareTmdbRatings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URLEncoder

private val auroraColors = darkColorScheme(
    primary = Color(0xFF73AEFF),
    secondary = Color(0xFFC5D7F8),
    background = Color(0xFF080D18),
    surface = Color(0xFF101827),
    surfaceVariant = Color(0xFF202C40),
    onBackground = Color(0xFFF4F7FF),
    onSurface = Color(0xFFF4F7FF)
)
private val nightGradient = Brush.verticalGradient(
    listOf(Color(0xFF07101F), Color(0xFF0B1321), Color(0xFF080D18))
)

@Composable
fun AuroraApp(viewModel: AuroraViewModel) {
    val state = viewModel.state
    MaterialTheme(colorScheme = auroraColors) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (val screen = state.screen) {
                Screen.Setup -> SetupScreen(
                    initial = state.settings, busy = state.busy, message = state.message,
                    canExit = state.settings.ready,
                    onBack = { viewModel.navigate(Screen.Library) },
                    onConnect = viewModel::saveSetup
                )
                Screen.Library -> LibraryScreen(
                    entries = state.entries, message = state.message,
                    loading = state.isScanning, onRescan = viewModel::refresh,
                    onSettings = { viewModel.navigate(Screen.Setup) },
                    onSelect = viewModel::select,
                    upcoming = state.upcoming, upcomingLoading = state.upcomingLoading,
                    upcomingError = state.upcomingError, onLoadUpcoming = viewModel::loadUpcoming,
                    tmdbToken = state.settings.tmdbToken
                )
                is Screen.Details -> {
                    BackHandler { viewModel.navigate(Screen.Library) }
                    val entry = state.entries.firstOrNull { it.id == screen.id }
                    if (entry == null) LaunchedEffect(screen.id) { viewModel.navigate(Screen.Library) }
                    else DetailsScreen(entry, recommendations = viewModel.recommendationsFor(entry.id),
                        onBack = { viewModel.navigate(Screen.Library) },
                        onPlay = { fromBeginning -> viewModel.play(entry.id, fromBeginning) },
                        onSelect = viewModel::select)
                }
                is Screen.Player -> {
                    BackHandler { viewModel.exitPlayer() }
                    val entry = state.entries.firstOrNull { it.id == screen.id }
                    if (entry == null) LaunchedEffect(screen.id) { viewModel.navigate(Screen.Library) }
                    else PlayerScreen(entry = entry, settings = state.settings,
                        fromBeginning = screen.fromBeginning,
                        suggestions = viewModel.recommendationsFor(entry.id, 6),
                        onPlayNext = { nextId -> viewModel.play(nextId, fromBeginning = true) },
                        onBack = viewModel::exitPlayer,
                        onLibrary = { viewModel.navigate(Screen.Library) },
                        onPositionChange = { time, duration -> viewModel.updateProgress(entry.id, time, duration) })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SetupScreen(
    initial: FtpSettings, busy: Boolean, message: String, canExit: Boolean,
    onBack: () -> Unit, onConnect: (FtpSettings) -> Unit
) {
    var host by remember(initial) { mutableStateOf(initial.host) }
    var port by remember(initial) { mutableStateOf(initial.port.toString()) }
    var username by remember(initial) { mutableStateOf(initial.username) }
    var password by remember(initial) { mutableStateOf(initial.password) }
    var directory by remember(initial) { mutableStateOf(initial.directory) }
    var token by remember(initial) { mutableStateOf(initial.tmdbToken) }

    Scaffold(topBar = {
        TopAppBar(title = { Text(if (canExit) "FTP Settings" else "Connect your media library") },
            navigationIcon = { if (canExit) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } })
    }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().imePadding()
                .verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            Icon(Icons.Default.VideoLibrary, null, modifier = Modifier.size(55.dp), tint = MaterialTheme.colorScheme.primary)
            Text("One-time FTP configuration", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Enter your FTP server details. They are saved on this device, and the app reconnects automatically.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(host, { host = it }, label = { Text("FTP server IP or hostname") },
                placeholder = { Text("192.168.1.254") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, label = { Text("FTP port") },
                modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(username, { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(password, { password = it }, label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(directory, { directory = it }, label = { Text("Media folder") },
                placeholder = { Text("/Movies") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            HorizontalDivider()
            Text("Movie posters and information", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(token, { token = it }, label = { Text("TMDb API key or Read Access Token (optional)") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
            Text("For automatic posters, add your TMDb v3 API key or API Read Access Token from themoviedb.org. Without it, videos remain browsable by filename. This product uses the TMDb API but is not endorsed or certified by TMDb.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
            Button(onClick = {
                onConnect(FtpSettings(host.trim(), port.toIntOrNull() ?: 21, username.trim(), password, directory.trim(), token.trim()))
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else Icon(Icons.Default.Cable, null)
                Spacer(Modifier.width(8.dp))
                Text(if (canExit) "Save and reconnect" else "Connect and build library")
            }
            Text("FTP is unencrypted. Use only on a trusted local network or through a private VPN.",
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LibraryScreen(
    entries: List<MediaEntry>, message: String, loading: Boolean,
    onRescan: () -> Unit, onSettings: () -> Unit, onSelect: (String) -> Unit,
    upcoming: List<UpcomingMovie>, upcomingLoading: Boolean,
    upcomingError: String, onLoadUpcoming: (Boolean) -> Unit, tmdbToken: String
) {
    var query by remember { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("All") }
    var selectedUpcoming by remember { mutableStateOf<UpcomingMovie?>(null) }
    var trailerUrl by remember { mutableStateOf<String?>(null) }
    var trailerLoading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    LaunchedEffect(selectedUpcoming?.id, tmdbToken) {
        val selected = selectedUpcoming
        trailerUrl = null
        trailerLoading = selected != null
        if (selected != null && tmdbToken.isNotBlank()) {
            trailerUrl = withContext(Dispatchers.IO) {
                runCatching { TmdbService(tmdbToken).trailerUrl(selected.id) }.getOrNull()
            }
        }
        trailerLoading = false
    }
    // Home is a discovery screen, not a duplicate of the full FTP movie grid.
    // Continue Watching is a Home section, not a separate bottom-navigation tab.
    val types = listOf("All", "Movies", "TV Shows", "Upcoming")
    LaunchedEffect(category) {
        if (category !in types) category = "All" // migrate older saved "Continue" tab
        if (category == "Upcoming") onLoadUpcoming(false)
    }
    val filtered = remember(entries, query, category) {
        entries.filter { item ->
            ((category == "Movies" && !item.isEpisode) ||
                (category == "TV Shows" && item.isEpisode)) &&
                (query.isBlank() || item.displayTitle.contains(query, ignoreCase = true))
        }.sortedWith(compareBy<MediaEntry> { it.displayTitle.lowercase(Locale.ROOT) }
            .thenBy { it.episodeCode.orEmpty() })
    }
    // Spotlight rotates through *local FTP library entries*. Earlier builds always
    // picked the first title and could never change the featured movie.
    val featuredCandidates = remember(entries) {
        val movies = entries.filterNot { it.isEpisode }
        val withArt = movies.filter { !it.backdrop.isNullOrBlank() || !it.poster.isNullOrBlank() }
        // Rate-ranked spotlight candidates; prefer artwork when scores tie.
        movies.sortedWith { a, b ->
            val rated = compareTmdbRatings(
                RatingValue(a.tmdbRating, a.tmdbVoteCount),
                RatingValue(b.tmdbRating, b.tmdbVoteCount))
            if (rated != 0) rated
            else compareValues(b in withArt, a in withArt)
        }.take(12)
    }
    var featuredIndex by rememberSaveable { mutableIntStateOf(0) }
    var featuredManualRevision by remember { mutableIntStateOf(0) }
    // Reset when the FTP library is replaced, but not when TMDb enriches its images.
    LaunchedEffect(featuredCandidates.map { it.id }) { featuredIndex = 0 }
    LaunchedEffect(featuredCandidates.map { it.id }, category, featuredManualRevision) {
        if (featuredCandidates.size > 1 && category == "All") {
            while (true) {
                kotlinx.coroutines.delay(8_000L)
                featuredIndex = nextSpotlightIndex(featuredIndex, featuredCandidates.size)
            }
        }
    }
    val featured = featuredCandidates.getOrNull(featuredIndex.coerceIn(0, (featuredCandidates.size - 1).coerceAtLeast(0)))
    val recent = remember(entries) { entries.filter { it.lastPositionMs > 5_000 && it.durationMs > it.lastPositionMs + 10_000 } }
    val curated = remember(entries) {
        entries.filterNot { it.isEpisode }
            .sortedWith { a, b -> compareTmdbRatings(
                RatingValue(a.tmdbRating, a.tmdbVoteCount),
                RatingValue(b.tmdbRating, b.tmdbVoteCount)) }
            .take(12)
    }
    // Recommendations show only actual movies present on the FTP server.
    // Unrated titles are retained as fallbacks, after movies with TMDb ratings.
    val suggestedMovies = remember(curated) { curated.take(10) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(title = {
                // Use the *actual adaptive launcher icon foreground*, not a generic play symbol.
                // The launcher uses the same foreground over #0C101A (see mipmap-anydpi-v26).
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0C101A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.aurora_icon_foreground),
                            contentDescription = "Aurora Media logo",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(Modifier.width(6.dp))
                    Text("AURORA", color = Color(0xFFF9FBFF),
                        fontFamily = FontFamily.SansSerif, fontSize = 19.sp,
                        fontWeight = FontWeight.Black, letterSpacing = 0.sp,
                        maxLines = 1, softWrap = false)
                    Text(" MEDIA", color = Color(0xFF73AEFF),
                        fontFamily = FontFamily.SansSerif, fontSize = 19.sp,
                        fontWeight = FontWeight.Black, letterSpacing = 0.sp,
                        maxLines = 1, softWrap = false)
                }
            }, actions = {
                IconButton(onClick = onRescan, enabled = !loading) { Icon(Icons.Default.Refresh, "Scan FTP") }
                IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "FTP and TMDb") }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D18)))
        }, bottomBar = {
            NavigationBar(containerColor = Color(0xFF101827), tonalElevation = 0.dp) {
                types.forEach { item ->
                    NavigationBarItem(selected = category == item, onClick = { category = item },
                        icon = { Icon(when (item) {
                            "Movies" -> Icons.Default.Movie
                            "TV Shows" -> Icons.Default.Tv
                            "Upcoming" -> Icons.Default.Theaters
                            else -> Icons.Default.Home
                        }, null) }, label = { Text(if (item == "All") "Home" else item) })
                }
            }
        }) { padding ->
        Column(Modifier.fillMaxSize().background(nightGradient).padding(padding)) {
            if (loading && category != "Upcoming") LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFF73AEFF))
            if (category == "Upcoming") {
                UpcomingTheatresSection(upcoming = upcoming, loading = upcomingLoading,
                    error = upcomingError, onRefresh = { onLoadUpcoming(true) },
                    onSelect = { selectedUpcoming = it })
            } else LazyVerticalGrid(columns = GridCells.Adaptive(138.dp),
                contentPadding = PaddingValues(bottom = 28.dp, start = 14.dp, end = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        if (category == "All") {
                            if (featured != null) {
                                FeaturedBanner(
                                    item = featured,
                                    index = featuredIndex.coerceIn(0, featuredCandidates.lastIndex.coerceAtLeast(0)),
                                    count = featuredCandidates.size,
                                    onPrevious = {
                                        featuredIndex = previousSpotlightIndex(featuredIndex, featuredCandidates.size)
                                        featuredManualRevision++
                                    },
                                    onNext = {
                                        featuredIndex = nextSpotlightIndex(featuredIndex, featuredCandidates.size)
                                        featuredManualRevision++
                                    },
                                    onSelect = { onSelect(featured.id) }
                                )
                            }
                            // Keep actionable FTP/TMDb errors visible, but never expose routine scan counters.
                            if (message.startsWith("FTP unavailable:") ||
                                message.startsWith("Poster lookup failed:")) {
                                Spacer(Modifier.height(8.dp))
                                Text(message, color = Color(0xFFFFB4A9),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                            if (recent.isNotEmpty()) {
                                Spacer(Modifier.height(22.dp))
                                Text("Continue Watching", style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(12.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    rowItems(recent.take(10), key = { it.id }) { item ->
                                        Box(Modifier.width(158.dp)) {
                                            PosterTile(item, onClick = { onSelect(item.id) })
                                        }
                                    }
                                }
                            }
                            if (suggestedMovies.isNotEmpty()) {
                                Spacer(Modifier.height(24.dp))
                                Text("Suggested Movies", style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold)
                                Spacer(Modifier.height(12.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    rowItems(suggestedMovies, key = { it.id }) { item ->
                                        Box(Modifier.width(158.dp)) {
                                            PosterTile(item, onClick = { onSelect(item.id) })
                                        }
                                    }
                                }
                            }
                            if (featured == null && recent.isEmpty()) {
                                Spacer(Modifier.height(24.dp))
                                Text("Your recommendations will appear when movies are found on FTP.",
                                    color = Color(0xFF9EADC6),
                                    style = MaterialTheme.typography.bodyMedium)
                            }
                        } else {
                            // Search and full browsing belong to Movies and TV Shows, not Home.
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Search your movies and shows") },
                                leadingIcon = { Icon(Icons.Default.Search, null) },
                                singleLine = true, shape = RoundedCornerShape(18.dp))
                            if (category == "Movies") {
                                if (curated.isNotEmpty()) {
                                    Spacer(Modifier.height(24.dp))
                                    Text("Picked for You", style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.ExtraBold)
                                    Spacer(Modifier.height(12.dp))
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        rowItems(curated, key = { it.id }) { item ->
                                            Box(Modifier.width(158.dp)) {
                                                PosterTile(item, onClick = { onSelect(item.id) })
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(24.dp))
                                Text("Explore Your Collection", style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold)
                                Text("${filtered.size} movies available on FTP",
                                    color = Color(0xFF9EADC6), style = MaterialTheme.typography.bodySmall)
                            } else {
                                Spacer(Modifier.height(24.dp))
                                Text("Series & Episodes", style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold)
                                Text("${filtered.size} episodes available on FTP",
                                    color = Color(0xFF9EADC6), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                // Never render the entire FTP library grid on Home.
                if (category == "Movies" || category == "TV Shows") {
                    items(filtered, key = { it.id }) { item ->
                        PosterTile(item, onClick = { onSelect(item.id) })
                    }
                    if (filtered.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
                        Column(Modifier.fillMaxWidth().padding(38.dp),
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.VideoLibrary, null, Modifier.size(56.dp), tint = Color(0xFF73AEFF))
                            Spacer(Modifier.height(12.dp))
                            Text(if (loading) "Scanning your FTP library…" else "Nothing here yet")
                            Spacer(Modifier.height(5.dp))
                            Text("Try a refresh or another search.", color = Color(0xFF9EADC6))
                        }
                    }
                }
            }
        }
    }
    selectedUpcoming?.let { selected ->
        AlertDialog(
            onDismissRequest = { selectedUpcoming = null },
            title = { Text(selected.title) },
            text = {
                Column(Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    selected.poster?.let { poster ->
                        AsyncImage(model = poster, contentDescription = null,
                            modifier = Modifier.fillMaxWidth().height(220.dp),
                            contentScale = ContentScale.Fit)
                    }
                    Text("Theatrical release: ${selected.releaseDate} (India)",
                        color = MaterialTheme.colorScheme.primary)
                    Text(selected.description.ifBlank { "No synopsis is available from TMDb yet." })
                    Text("Coming to theatres • Not in your FTP library",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val url = trailerUrl ?: "https://www.youtube.com/results?search_query=" +
                        URLEncoder.encode("${selected.title} ${selected.releaseDate.take(4)} official trailer", "UTF-8")
                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                }, enabled = !trailerLoading) {
                    Icon(Icons.Default.PlayCircle, null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (trailerLoading) "Finding trailer…" else if (trailerUrl != null)
                        "Watch Trailer" else "Search YouTube")
                }
                TextButton(onClick = { selectedUpcoming = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun UpcomingTheatresSection(
    upcoming: List<UpcomingMovie>, loading: Boolean, error: String,
    onRefresh: () -> Unit, onSelect: (UpcomingMovie) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Upcoming in Theatres", style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold)
                Text("India · Release dates supplied by TMDb",
                    color = Color(0xFF9EADC6), style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onRefresh, enabled = !loading) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh upcoming movies")
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = Color(0xFFFFC1B5),
            modifier = Modifier.padding(vertical = 16.dp))
        if (!loading && error.isBlank() && upcoming.isEmpty()) {
            Text("No forthcoming releases found. Try refreshing later.")
        }
        LazyVerticalGrid(columns = GridCells.Adaptive(138.dp),
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 28.dp)) {
            items(upcoming, key = { it.id }) { movie ->
                Column(Modifier.fillMaxWidth().clickable { onSelect(movie) }) {
                    Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)
                        .clip(RoundedCornerShape(14.dp)).background(Color(0xFF202C40)),
                        contentAlignment = Alignment.Center) {
                        if (movie.poster != null) AsyncImage(model = movie.poster,
                            contentDescription = "${movie.title} theatrical poster",
                            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        else Icon(Icons.Default.Movie, contentDescription = null,
                            modifier = Modifier.size(44.dp))
                    }
                    Spacer(Modifier.height(7.dp))
                    Text(movie.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    Text("Release ${movie.releaseDate}", color = Color(0xFF8DD4FF),
                        style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun FeaturedBanner(
    item: MediaEntry, index: Int, count: Int,
    onPrevious: () -> Unit, onNext: () -> Unit, onSelect: () -> Unit
) {
    Box(Modifier.fillMaxWidth().height(300.dp)
        .clip(RoundedCornerShape(26.dp))) {
        val artwork = item.backdrop?.takeIf { it.isNotBlank() }
            ?: item.poster?.takeIf { it.isNotBlank() }
        if (artwork != null) AsyncImage(model = artwork, contentDescription = null,
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(
            listOf(Color(0xFF1B3764), Color(0xFF101827)))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            Color(0x33040812), Color(0x66040812), Color(0xF7080D18)))))
        Column(Modifier.align(Alignment.BottomStart).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(item.displayTitle, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            item.description?.let {
                Text(it, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    color = Color(0xFFDDDFE9), style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Button(onClick = onSelect, shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(6.dp))
                    Text("View Movie", fontWeight = FontWeight.Bold)
                }
                if (count > 1) {
                    IconButton(onClick = onPrevious) {
                        Icon(Icons.Default.ChevronLeft, "Previous featured movie", tint = Color.White)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        repeat(count) { position ->
                            Box(Modifier.size(if (position == index) 7.dp else 5.dp)
                                .clip(RoundedCornerShape(50))
                                .background(if (position == index) Color(0xFF73AEFF)
                                    else Color(0x99FFFFFF)))
                        }
                    }
                    IconButton(onClick = onNext) {
                        Icon(Icons.Default.ChevronRight, "Next featured movie", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun PosterTile(item: MediaEntry, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF202C40)), contentAlignment = Alignment.Center) {
            if (item.poster != null) AsyncImage(model = item.poster,
                contentDescription = "${item.displayTitle} poster", modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop)
            else Icon(Icons.Default.Movie, null, modifier = Modifier.size(44.dp), tint = Color(0xFF73AEFF))
            if (item.lastPositionMs > 0L && item.durationMs > 0L) {
                LinearProgressIndicator(progress = { (item.lastPositionMs.toFloat() / item.durationMs).coerceIn(0f, 1f) },
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(item.displayTitle, maxLines = 2, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            item.year?.let { Text(it.toString(), style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF97A9C7)) }
            item.tmdbRating?.let { score ->
                Text("★ %.1f".format(Locale.US, score),
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFFFD06B))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailsScreen(
    item: MediaEntry, recommendations: List<MediaEntry>, onBack: () -> Unit,
    onPlay: (Boolean) -> Unit, onSelect: (String) -> Unit
) {
    Scaffold(containerColor = Color(0xFF080D18), topBar = {
        TopAppBar(title = { Text("Movie Details", fontWeight = FontWeight.Bold) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF080D18)))
    }) { pad ->
        Column(Modifier.fillMaxSize().background(nightGradient).padding(pad)
            .verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().height(240.dp)) {
                if (item.backdrop != null) AsyncImage(item.backdrop, null, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop)
                else Box(Modifier.fillMaxSize().background(Color(0xFF202C40)))
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
                    Color.Transparent, Color(0xFF080D18)))))
            }
            Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(item.displayTitle, style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black)
                Text(listOfNotNull(item.year?.toString(), item.episodeCode,
                    item.bytes.takeIf { it > 0 }?.let { "%.1f GB".format(it.toDouble() / 1_073_741_824) })
                    .joinToString("  •  "), color = Color(0xFFAAB7CB))
                if (item.lastPositionMs > 5_000L && item.durationMs > item.lastPositionMs + 10_000L) {
                    Button(onClick = { onPlay(false) }, modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp))
                        Text("Resume Playback", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { onPlay(true) }, modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Replay, null); Spacer(Modifier.width(8.dp))
                        Text("Start from Beginning")
                    }
                } else {
                    Button(onClick = { onPlay(true) }, modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp))
                        Text("Play from Beginning", fontWeight = FontWeight.Bold)
                    }
                }
                if (!item.description.isNullOrBlank()) Text(item.description,
                    style = MaterialTheme.typography.bodyLarge, color = Color(0xFFE0E5F0))
                if (recommendations.isNotEmpty()) {
                    HorizontalDivider(color = Color(0xFF25334A))
                    Text("More Like This", style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                        rowItems(recommendations, key = { it.id }) { suggestion ->
                            Box(Modifier.width(138.dp)) {
                                PosterTile(suggestion, onClick = { onSelect(suggestion.id) })
                            }
                        }
                    }
                }
                HorizontalDivider(color = Color(0xFF25334A))
                Text("FTP source", color = Color(0xFF97A9C7), style = MaterialTheme.typography.labelLarge)
                Text(item.path, color = Color(0xFF71829E), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
