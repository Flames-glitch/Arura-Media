package com.aurora.media.metadata

/**
 * Descending TMDb rating (0..10), with vote count breaking ties and
 * unrated titles at the end. This is a TMDb score, not an IMDb rating.
 * Pure Kotlin for regression testing without an Android SDK.
 */
data class RatingValue(val average: Double?, val votes: Int = 0)

fun compareTmdbRatings(a: RatingValue, b: RatingValue): Int {
    val left = a.average?.takeIf { it > 0.0 && it <= 10.0 }
    val right = b.average?.takeIf { it > 0.0 && it <= 10.0 }
    if (left == null && right == null) return 0
    if (left == null) return 1
    if (right == null) return -1
    val averageOrder = right.compareTo(left)
    return if (averageOrder != 0) averageOrder else b.votes.compareTo(a.votes)
}
