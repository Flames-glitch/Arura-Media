package com.aurora.media.player

import org.junit.Assert.assertEquals
import org.junit.Test

class VideoScalingTest {
    @Test fun sixteenByNineOnWidePhone() {
        assertEquals(VideoBounds(1920, 1080), VideoScaling.compute(2400, 1080, 16f / 9f, false))
        assertEquals(VideoBounds(2400, 1350), VideoScaling.compute(2400, 1080, 16f / 9f, true))
    }

    @Test fun fourByThreeOnWidePhone() {
        assertEquals(VideoBounds(1440, 1080), VideoScaling.compute(2400, 1080, 4f / 3f, false))
        assertEquals(VideoBounds(2400, 1800), VideoScaling.compute(2400, 1080, 4f / 3f, true))
    }

    @Test fun portraitAndPipResize() {
        assertEquals(VideoBounds(1080, 608), VideoScaling.compute(1080, 2400, 16f / 9f, false))
        assertEquals(VideoBounds(480, 270), VideoScaling.compute(480, 270, 16f / 9f, false))
        assertEquals(VideoBounds(1920, 1080), VideoScaling.compute(2400, 1080, 16f / 9f, false))
    }

    @Test fun invalidAspectDefaultsToViewport() {
        assertEquals(VideoBounds(1000, 500), VideoScaling.compute(1000, 500, Float.NaN, false))
    }
}
