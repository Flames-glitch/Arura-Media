package com.aurora.media.metadata

import org.junit.Assert.*
import org.junit.Test

class RatingOrderTest {
    @Test fun scoreSortAndMissingRatings() {
        val sorted = listOf(RatingValue(null), RatingValue(7.2, 20), RatingValue(9.0, 4))
            .sortedWith(::compareTmdbRatings)
        assertEquals(listOf(9.0, 7.2, null), sorted.map { it.average })
    }

    @Test fun voteCountsBreakEqualRatings() {
        assertTrue(compareTmdbRatings(RatingValue(7.0, 30), RatingValue(7.0, 5)) < 0)
    }
}
