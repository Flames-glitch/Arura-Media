package com.aurora.media.player

import org.junit.Assert.*
import org.junit.Test

class DecoderChoiceTest {
    @Test fun autoByDefault() {
        assertEquals(DecoderChoice.AUTO, DecoderChoice.normalize(null))
        assertTrue(DecoderChoice.enableHardware(DecoderChoice.AUTO))
    }
    @Test fun softwareDisablesHardwareDecoder() {
        assertEquals(DecoderChoice.SOFTWARE, DecoderChoice.normalize("Software"))
        assertFalse(DecoderChoice.enableHardware(DecoderChoice.SOFTWARE))
    }
}
