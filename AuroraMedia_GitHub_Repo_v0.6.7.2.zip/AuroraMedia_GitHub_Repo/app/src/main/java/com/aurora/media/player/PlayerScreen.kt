package com.aurora.media.player

import android.app.Activity
import com.aurora.media.MainActivity
import android.content.pm.ActivityInfo
import android.content.Context
import android.media.AudioManager
import android.provider.Settings
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import android.net.Uri
import android.view.SurfaceView
import android.view.ViewGroup
import android.view.Gravity
import android.widget.FrameLayout
import android.view.WindowManager
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items as rowItems
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt
import androidx.compose.ui.viewinterop.AndroidView
import com.aurora.media.data.FtpSettings
import com.aurora.media.data.MediaEntry
import kotlinx.coroutines.delay
import java.util.concurrent.TimeUnit

private enum class SwipeMode { SEEK, BRIGHTNESS, VOLUME }
private data class GestureIndicator(val mode: SwipeMode, val value: String, val progress: Float)

private fun systemBrightness(context: Context): Float = runCatching {
    Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS).toFloat() / 255f
}.getOrDefault(0.5f).coerceIn(0.05f, 1f)

private fun formatted(ms: Long): String {
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms.coerceAtLeast(0L))
    return "%02d:%02d:%02d".format(seconds / 3600, (seconds / 60) % 60, seconds % 60)
}

@Composable
fun PlayerScreen(
    entry: MediaEntry, settings: FtpSettings, fromBeginning: Boolean = false,
    suggestions: List<MediaEntry> = emptyList(), onPlayNext: (String) -> Unit = {},
    onBack: () -> Unit, onLibrary: () -> Unit = onBack,
    onPositionChange: (Long, Long) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val mainActivity = activity as? MainActivity
    val inPiP = mainActivity?.inPlayerPiP == true
    var controlsVisible by remember(entry.id) { mutableStateOf(true) }
    var finished by remember(entry.id) { mutableStateOf(false) }
    val session = remember(entry.id, settings.host, fromBeginning) {
        val selected = if (fromBeginning) entry.copy(lastPositionMs = 0L) else entry
        VlcSession(context, selected, settings, onPositionChange,
            onFinished = { finished = true; controlsVisible = false })
    }
    var dialog by remember { mutableStateOf("") }
    var trackTab by remember { mutableStateOf("Audio") }
    var controlsRevision by remember { mutableIntStateOf(0) }
    var orientation by remember { mutableStateOf("Landscape") }
    var seekPreview by remember { mutableStateOf<Float?>(null) }
    var notice by remember { mutableStateOf("") }
    val audio = remember(context) { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var indicator by remember { mutableStateOf<GestureIndicator?>(null) }
    var gestureActive by remember { mutableStateOf(false) }
    var multiTouchActive by remember { mutableStateOf(false) }
    var gestureSeek by remember { mutableLongStateOf(0L) }
    val volumeMax = remember(audio) { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    val subtitleChooser = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            notice = if (session.loadExternalSubtitle(uri)) "External subtitle added" else "Unable to open subtitle"
        }
    }

    DisposableEffect(session) {
        mainActivity?.registerPlayer(session)
        val original = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val initialBrightness = activity?.window?.attributes?.screenBrightness ?: -1f
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val insets = activity?.let { WindowCompat.getInsetsController(it.window, it.window.decorView) }
        insets?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            mainActivity?.registerPlayer(null)
            session.close()
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            activity?.requestedOrientation = original
            insets?.show(WindowInsetsCompat.Type.systemBars())
            // App-specific brightness: restore the pre-playback setting.
            activity?.window?.let { window ->
                val params = window.attributes
                params.screenBrightness = initialBrightness
                window.attributes = params
            }
        }
    }
    // Keep the screen awake while FTP video is actively playing. Restore normal
    // device sleep behaviour on pause, completion, navigation, or app close.
    LaunchedEffect(session.isPlaying, session.isBuffering, finished, inPiP) {
        activity?.window?.let { window ->
            if (session.isPlaying && !finished) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
    LaunchedEffect(orientation, inPiP) {
        activity?.requestedOrientation = if (inPiP) ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else when (orientation) {
            "Auto" -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
            "Landscape" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            "Portrait" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            "Locked" -> ActivityInfo.SCREEN_ORIENTATION_LOCKED
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }
    // Restart hide countdown whenever a playback control is used.
    LaunchedEffect(controlsVisible, controlsRevision) {
        if (controlsVisible) { delay(5_000L); controlsVisible = false }
    }
    LaunchedEffect(gestureActive, indicator) {
        if (!gestureActive && indicator != null) {
            delay(1000L)
            indicator = null
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // FrameLayout is the full playback viewport. It clips a centered
        // SurfaceView so Fit letterboxes and Fill crops without stretching.
        // PiP-to-fullscreen measures this container again; never size from the
        // SurfaceHolder buffer (which may still be tiny from PiP).
        AndroidView(
            modifier = Modifier.fillMaxSize()
                .onSizeChanged { size -> session.updateVideoWindow(size.width, size.height) },
            factory = { ctx ->
                FrameLayout(ctx).apply {
                    setBackgroundColor(android.graphics.Color.BLACK)
                    clipChildren = true
                    clipToPadding = true
                    val surface = SurfaceView(ctx)
                    addView(surface, FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        Gravity.CENTER
                    ))
                    surface.holder.addCallback(object : android.view.SurfaceHolder.Callback {
                        override fun surfaceCreated(holder: android.view.SurfaceHolder) {
                            session.onSurfaceCreated(surface)
                        }
                        override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) {
                            // DO NOT setWindowSize from these buffer dimensions.
                            // The FrameLayout onSizeChanged drives playback sizing.
                        }
                        override fun surfaceDestroyed(holder: android.view.SurfaceHolder) {
                            session.requestVideoRebind()
                        }
                    })
                    addOnLayoutChangeListener { _, left, top, right, bottom, _, _, _, _ ->
                        session.updateVideoWindow(right - left, bottom - top)
                    }
                    session.attach(surface, this)
                }
            },
            update = { parent ->
                (parent.getChildAt(0) as? SurfaceView)?.let { session.attach(it, parent) }
                session.updateVideoWindow(parent.width, parent.height)
            }
        )
        // PiP shows only the video surface; gestures and chrome are hidden.
        // Tap to toggle controls; vertical drags change brightness/volume;
        // horizontal drags preview the target time and seek on finger release.
        if (!inPiP) Box(Modifier.fillMaxSize()
            .pointerInput(session, activity, audio) {
                var start = Offset.Zero
                var x = 0f
                var y = 0f
                var mode: SwipeMode? = null
                var initialValue = 0f
                var baseTime = 0L
                var total = 0L
                detectDragGestures(
                    onDragStart = { offset ->
                        start = offset
                        x = 0f
                        y = 0f
                        mode = null
                        baseTime = session.positionMs
                        total = session.durationMs
                        gestureActive = true
                        indicator = null
                    },
                    onDrag = { change, amount ->
                        if (multiTouchActive) return@detectDragGestures
                        change.consume()
                        x += amount.x
                        y += amount.y
                        if (mode == null) {
                            mode = if (abs(x) >= abs(y)) SwipeMode.SEEK
                                   else if (start.x < size.width / 2f) SwipeMode.BRIGHTNESS
                                   else SwipeMode.VOLUME
                            initialValue = when (mode) {
                                SwipeMode.BRIGHTNESS -> {
                                    val current = activity?.window?.attributes?.screenBrightness ?: -1f
                                    if (current < 0f) systemBrightness(context) else current
                                }
                                SwipeMode.VOLUME -> audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / volumeMax
                                else -> 0f
                            }
                        }
                        when (mode) {
                            SwipeMode.SEEK -> {
                                if (total > 0L) {
                                    // Full-screen swipe = 90 seconds, independently of screen resolution.
                                    val delta = (x / size.width.coerceAtLeast(1) * 90_000L).toLong()
                                    gestureSeek = (baseTime + delta).coerceIn(0L, total)
                                    val sign = if (delta >= 0) "+" else "−"
                                    indicator = GestureIndicator(SwipeMode.SEEK,
                                        "$sign${formatted(abs(delta))}  →  ${formatted(gestureSeek)}",
                                        gestureSeek.toFloat() / total)
                                } else {
                                    indicator = GestureIndicator(SwipeMode.SEEK, "Seeking unavailable", 0f)
                                }
                            }
                            SwipeMode.BRIGHTNESS -> {
                                val level = (initialValue - y / size.height.coerceAtLeast(1)).coerceIn(0.05f, 1f)
                                activity?.window?.let { window ->
                                    val params = window.attributes
                                    params.screenBrightness = level
                                    window.attributes = params
                                }
                                indicator = GestureIndicator(SwipeMode.BRIGHTNESS,
                                    "${(level * 100).roundToInt()}%", level)
                            }
                            SwipeMode.VOLUME -> {
                                val level = (initialValue - y / size.height.coerceAtLeast(1)).coerceIn(0f, 1f)
                                val target = (level * volumeMax).roundToInt().coerceIn(0, volumeMax)
                                audio.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
                                indicator = GestureIndicator(SwipeMode.VOLUME,
                                    "${(target * 100f / volumeMax).roundToInt()}%", target.toFloat() / volumeMax)
                            }
                            null -> Unit
                        }
                    },
                    onDragEnd = {
                        if (mode == SwipeMode.SEEK && total > 0L) session.seek(gestureSeek)
                        gestureActive = false
                    },
                    onDragCancel = { gestureActive = false; indicator = null }
                )
            }
            .pointerInput(session) {
                detectTapGestures(
                    onTap = { controlsVisible = !controlsVisible; controlsRevision++ },
                    onDoubleTap = {
                        session.toggleAspect()
                        notice = if (session.aspect == "Fill") "Zoom to Fill" else "Fit • Entire video"
                        controlsRevision++
                    }
                )
            }
            .pointerInput(session) {
                // Two-finger pinch toggles between Fit and Fill. The one-finger
                // drag recognizer above still handles brightness, volume, seek.
                awaitEachGesture {
                    var handledZoom = false
                    var cumulativeZoom = 1f
                    do {
                        val event = awaitPointerEvent()
                        val activePointers = event.changes.count { it.pressed }
                        if (activePointers >= 2) {
                            multiTouchActive = true
                            cumulativeZoom *= event.calculateZoom()
                            if (!handledZoom && cumulativeZoom > 1.12f && session.aspect != "Fill") {
                                session.changeAspect("Fill")
                                notice = "Zoom to Fill"
                                handledZoom = true
                            } else if (!handledZoom && cumulativeZoom < 0.88f && session.aspect != "Fit") {
                                session.changeAspect("Fit")
                                notice = "Fit • Entire video"
                                handledZoom = true
                            }
                            if (handledZoom) event.changes.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                    multiTouchActive = false
                }
            }
        )
        if (!inPiP && !finished && session.isBuffering && session.error.isBlank())
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        if (!inPiP && session.error.isNotBlank()) {
            Column(modifier = Modifier.align(Alignment.Center)
                .background(Color(0xE6000000), RoundedCornerShape(12.dp))
                .padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(session.error, color = Color.White)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { session.selectDecoder(DecoderChoice.SOFTWARE) }) {
                    Text("Retry with software decoder")
                }
            }
        }
        if (controlsVisible && !inPiP && !finished) {
            // Approved compact landscape player layout:
            // title/actions stay at top, while seek bar + time labels + ALL
            // playback buttons remain together in the lower overlay.
            // Avoid a large Play/Pause button floating over the video frame.
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0xDB050912), Color.Transparent)))
                        .padding(start = 10.dp, end = 12.dp, top = 8.dp, bottom = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Return to movie details", tint = Color.White)
                    }
                    Text(entry.displayTitle, Modifier.weight(1f), color = Color.White,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    IconButton(onClick = {
                        if (mainActivity?.enterPlayerPiP() != true)
                            notice = "Picture in picture is unavailable while paused"
                        else controlsVisible = false
                    }) {
                        Icon(Icons.Default.PictureInPictureAlt, "Picture in picture", tint = Color.White)
                    }
                    IconButton(onClick = { dialog = "settings"; controlsRevision++ }) {
                        Icon(Icons.Default.MoreVert, "More playback settings", tint = Color.White)
                    }
                }
                Spacer(Modifier.weight(1f))
                Column(
                    Modifier.fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(
                            Color.Transparent, Color(0xBF060B13), Color(0xE8060B13))))
                        .padding(start = 14.dp, end = 14.dp, top = 15.dp, bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    val duration = session.durationMs.coerceAtLeast(1L)
                    Slider(
                        value = seekPreview ?: (session.positionMs.toFloat() / duration).coerceIn(0f, 1f),
                        onValueChange = { seekPreview = it; controlsRevision++ },
                        onValueChangeFinished = {
                            seekPreview?.let { session.seek((it * duration).toLong()) }
                            seekPreview = null
                            controlsRevision++
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFF8C24),
                            activeTrackColor = Color(0xFFFF8C24),
                            inactiveTrackColor = Color(0x88CBD0DC)
                        ),
                        modifier = Modifier.fillMaxWidth().height(22.dp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatted(session.positionMs), color = Color(0xFFF1F3FA),
                            style = MaterialTheme.typography.labelSmall)
                        Text(formatted(session.durationMs), color = Color(0xFFF1F3FA),
                            style = MaterialTheme.typography.labelSmall)
                    }
                    Spacer(Modifier.height(2.dp))
                    // Five equal-width slots keep the small Play/Pause button
                    // exactly at horizontal screen center, regardless of title
                    // length, PiP visibility or other controls.
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            IconButton(onClick = {
                                trackTab = "Audio"
                                dialog = "tracks"
                                controlsRevision++
                            }, modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Default.Subtitles, "Audio and subtitles", tint = Color.White,
                                    modifier = Modifier.size(26.dp))
                            }
                        }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            IconButton(onClick = { session.skip(-10_000); controlsRevision++ },
                                modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Default.Replay10, "Rewind 10 seconds", tint = Color.White,
                                    modifier = Modifier.size(30.dp))
                            }
                        }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            IconButton(
                                onClick = { session.togglePause(); controlsRevision++ },
                                modifier = Modifier.size(48.dp)
                                    .background(Color(0xB70C111B), RoundedCornerShape(50))
                                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(50))
                            ) {
                                Icon(if (session.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    "Play or pause", tint = Color.White, modifier = Modifier.size(29.dp))
                            }
                        }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            IconButton(onClick = { session.skip(10_000); controlsRevision++ },
                                modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Default.Forward10, "Forward 10 seconds", tint = Color.White,
                                    modifier = Modifier.size(30.dp))
                            }
                        }
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            IconButton(onClick = {
                                session.toggleAspect()
                                notice = if (session.aspect == "Fill") "Zoom to Fill" else "Fit • Entire video"
                                controlsRevision++
                            }, modifier = Modifier.size(44.dp)) {
                                Icon(Icons.Default.Fullscreen, "Toggle Fit and Fill", tint = Color.White,
                                    modifier = Modifier.size(28.dp))
                            }
                        }
                    }
                }
            }
        }
        if (finished && !inPiP) {
            // Recommendations are deliberately limited to files already on this FTP server;
            // tapping a suggestion starts playback without leaving Aurora Media.
            Column(Modifier.fillMaxSize().background(Color(0xED07101C))
                .verticalScroll(androidx.compose.foundation.rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("WATCHED", color = Color(0xFF8DD4FF), fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelSmall)
                Text("What to watch next", color = Color.White,
                    style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Text("More movies and shows from your FTP library", color = Color(0xFFBBC8DC),
                    style = MaterialTheme.typography.bodySmall)
                if (suggestions.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        rowItems(suggestions.take(6), key = { it.id }) { suggestion ->
                            Column(Modifier.width(128.dp).clickable { onPlayNext(suggestion.id) },
                                verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Box(Modifier.fillMaxWidth().height(154.dp)
                                    .background(Color(0xFF1D293E), RoundedCornerShape(12.dp)),
                                    contentAlignment = Alignment.Center) {
                                    if (suggestion.poster != null) {
                                        AsyncImage(model = suggestion.poster,
                                            contentDescription = suggestion.title,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop)
                                    } else Icon(Icons.Default.Movie, null,
                                        tint = Color(0xFF8DD4FF), modifier = Modifier.size(40.dp))
                                }
                                Text(suggestion.displayTitle, maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    color = Color.White, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                } else {
                    Text("No other movies are available in this library yet.", color = Color.White)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onLibrary) { Icon(Icons.Default.Home, null); Spacer(Modifier.width(5.dp)); Text("Library") }
                    OutlinedButton(onClick = onBack) { Text("Movie details") }
                }
            }
        }
        if (!inPiP) indicator?.let { value ->
            Column(
                modifier = Modifier.align(Alignment.Center)
                    .background(Color(0xD9000000), RoundedCornerShape(18.dp))
                    .padding(horizontal = 26.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Icon(when (value.mode) {
                    SwipeMode.BRIGHTNESS -> Icons.Default.WbSunny
                    SwipeMode.VOLUME -> Icons.Default.VolumeUp
                    SwipeMode.SEEK -> Icons.Default.SwapHoriz
                }, contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp))
                Text(value.value, fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { value.progress.coerceIn(0f, 1f) },
                    modifier = Modifier.width(170.dp), color = Color(0xFFA9B9FF))
            }
        }
        if (!inPiP && notice.isNotBlank()) {
            Text(notice, modifier = Modifier.align(Alignment.TopCenter).padding(top = 70.dp)
                .background(Color.DarkGray, RoundedCornerShape(9.dp)).padding(12.dp), color = Color.White)
            LaunchedEffect(notice) { delay(2400); notice = "" }
        }
    }

    if (!inPiP) when (dialog) {
        "aspect" -> OptionDialog("Video scaling • Double-tap or pinch to switch", listOf("Fit", "Fill"),
            onDismiss = { dialog = "" }, onSelect = { session.changeAspect(it); dialog = "" })
        "tracks" -> AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text("Audio & Subtitles") },
            text = {
                Column(Modifier.heightIn(max = 390.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilterChip(selected = trackTab == "Audio", onClick = { trackTab = "Audio" },
                            label = { Text("Audio") })
                        FilterChip(selected = trackTab == "Subtitles", onClick = { trackTab = "Subtitles" },
                            label = { Text("Subtitles") })
                    }
                    Column(Modifier.weight(1f, fill = false).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                        val tracks = if (trackTab == "Audio") session.audioTracks() else session.subtitleTracks()
                        if (tracks.isEmpty()) Text("No selectable ${trackTab.lowercase()} tracks in this file")
                        tracks.forEach { (id, name) ->
                            TextButton(onClick = {
                                if (trackTab == "Audio") session.selectAudio(id) else session.selectSubtitle(id)
                                dialog = ""
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text(name, modifier = Modifier.fillMaxWidth())
                            }
                        }
                        if (trackTab == "Subtitles") {
                            HorizontalDivider()
                            TextButton(onClick = { session.selectSubtitle(-1); dialog = "" }) {
                                Text("Turn subtitles off")
                            }
                            TextButton(onClick = {
                                dialog = ""
                                subtitleChooser.launch(arrayOf("application/x-subrip", "text/plain", "text/vtt", "application/octet-stream"))
                            }) { Text("Load subtitle file (.srt / .vtt)") }
                        }
                        TextButton(onClick = { dialog = "sync" }) { Text("Track synchronization") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Done") } }
        )
        "sync" -> AlertDialog(onDismissRequest = { dialog = "" }, title = { Text("Track synchronization") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Subtitle delay: ${session.subtitleDelayMs} ms")
                Row { TextButton(onClick = { session.shiftSubtitles(-250) }) { Text("−250 ms") }; TextButton(onClick = { session.shiftSubtitles(250) }) { Text("+250 ms") } }
                HorizontalDivider()
                Text("Audio delay: ${session.audioDelayMs} ms")
                Row { TextButton(onClick = { session.shiftAudio(-250) }) { Text("−250 ms") }; TextButton(onClick = { session.shiftAudio(250) }) { Text("+250 ms") } }
            } }, confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Done") } })
        "settings" -> AlertDialog(onDismissRequest = { dialog = "" }, title = { Text("Player settings") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Volume / audio boost: ${session.volume}%")
                Slider(value = session.volume.toFloat(), onValueChange = { session.setVolumePercent(it.toInt()) }, valueRange = 0f..125f)
                if (session.videoWidth > 0 && session.videoHeight > 0) {
                    Text("Source video: ${session.videoWidth} × ${session.videoHeight}")
                }
                TextButton(onClick = { dialog = "decoder" }) {
                    Text("Video decoder: ${DecoderChoice.display(session.decoderMode)}")
                }
                Text("Try Software (FFmpeg) for corrupted, flickering or black frames. " +
                    "Software 4K playback can be slower and use more battery.",
                    style = MaterialTheme.typography.bodySmall)
                Text("Playback speed: ${"%.2f".format(session.speed)}×")
                Slider(value = session.speed, onValueChange = session::updateSpeed, valueRange = 0.5f..2f)
                TextButton(onClick = { dialog = "orientation" }) { Text("Screen orientation: $orientation") }
                TextButton(onClick = { dialog = "aspect" }) { Text("Scaling: ${session.aspect} • double-tap or pinch") }
                TextButton(onClick = { dialog = "equalizer" }) { Text("Equalizer presets") }
                TextButton(onClick = { dialog = "sync" }) { Text("Audio and subtitle synchronization") }
            } }, confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Close") } })
        "decoder" -> OptionDialog("Video decoder", listOf("Auto (hardware preferred)", "Software (FFmpeg)"),
            onDismiss = { dialog = "" }, onSelect = {
                session.selectDecoder(if (it.startsWith("Software")) DecoderChoice.SOFTWARE else DecoderChoice.AUTO)
                notice = "Decoder changed to $it"
                dialog = ""
            })
        "orientation" -> OptionDialog("Screen orientation", listOf("Auto", "Landscape", "Portrait", "Locked"),
            onDismiss = { dialog = "" }, onSelect = { orientation = it; dialog = "" })
        "equalizer" -> OptionDialog("Audio equalizer (device dependent)",
            listOf("Flat", "Classical", "Club", "Dance", "Full bass", "Full treble", "Headphones", "Large Hall", "Live", "Party", "Pop", "Reggae", "Rock", "Ska", "Soft", "Techno"),
            onDismiss = { dialog = "" }, onSelect = {
                val index = listOf("Flat", "Classical", "Club", "Dance", "Full bass", "Full treble", "Headphones", "Large Hall", "Live", "Party", "Pop", "Reggae", "Rock", "Ska", "Soft", "Techno").indexOf(it)
                notice = if (session.equalizerPreset(index)) "$it equalizer enabled" else "Equalizer not supported in this player build"
                dialog = ""
            })
    }
}

@Composable
private fun OptionDialog(title: String, options: List<String>, onDismiss: () -> Unit, onSelect: (String) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { Column(Modifier.heightIn(max = 480.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
            options.forEach { option -> TextButton(onClick = { onSelect(option) }, modifier = Modifier.fillMaxWidth()) { Text(option) } }
        } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun TrackDialog(title: String, tracks: List<Pair<Int, String>>, onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = { Column(Modifier.heightIn(max = 400.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
            if (tracks.isEmpty()) Text("No selectable tracks detected")
            tracks.forEach { (id, name) -> TextButton(onClick = { onSelect(id) }, modifier = Modifier.fillMaxWidth()) { Text(name) } }
        } }, confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } })
}
