# Aurora Media Android V0.6.6 — video surface and 4K playback compatibility

This is a standalone FTP streaming client for Android. The folder offloader is intentionally disabled.

## Player changes

- A single LibVLC session is preserved while entering/exiting Android PiP or switching apps; the video SurfaceView is rebound after surface recreation rather than restarting FTP playback from zero.
- The video is laid out within the measured current viewport (`FrameLayout`), not with the stale `SurfaceHolder` buffer or guessed phone dimensions. The parent clips the video surface when zoomed.
- **Fit (default):** original source proportions, entire frame visible; for 16:9 on a 20:9 landscape screen, black bars appear at the sides.
- **Fill:** zoom until the video covers the entire viewport; crop the excess while preserving the original source aspect ratio (no forced stretch).
- **Double tap:** toggle Fit / Fill. **Two-finger pinch:** pinch outward for Fill, inward for Fit. One-finger left/right swipe continues seeking; vertical left/right continue to set screen brightness/volume.
- Video dimensions are read using LibVLC's video layout callback, including pixel aspect ratio, and reapplied when PiP/fullscreen bounds change.
- LibVLC 3.5.1 retains native decoding and MediaCodec hardware acceleration with software fallback, and an increased 3000 ms network buffer for FTP. H.264/HEVC 4K decoding is available where the Android device codec, processing power, and network throughput support it. 4K/AV1 and other combinations are **not guaranteed** by the app.

## Building

Upload this ZIP to the root of the GitHub repository and retain its top-level `AuroraMedia_GitHub_Repo` directory. The build workflow extracts the newest `AuroraMedia_GitHub_Repo_v*.zip`, runs source checks and JVM tests, then builds `:app:assembleDebug` with Java 17 and Android SDK 35.

**Testing:** PiP expand and dismiss, phone calls/app switching, Fit/Fill double tap and pinch, 16:9/21:9/4:3 content, H.264/HEVC streams up to 4K on your actual phone. Inspect `adb logcat` if a specific file fails or the app crashes. The ZIP is not a prebuilt APK.


## v0.6.7: Optional FFmpeg software video decoding

In Player → More (⋮) → Player settings → Video decoder, select **Software (FFmpeg)** if your phone's hardware decoder shows blocky/corrupted frames. **Auto (hardware preferred)** remains the default. The mode persists locally, and switching codecs attempts to keep the current playback position. LibVLC 3.5.1 already bundles its own software decoding; this does not install MX Player codecs. 4K software decoding may exceed the device's CPU performance, and decoder switching does not itself fix an Android SurfaceView/PiP lifecycle bug.


## Version 0.6.7.2 — approved compact player layout

The Android player now places the seek bar, elapsed/total timestamps, and
five evenly spaced icon controls at the bottom over a transparent gradient.
The Play/Pause control is a compact (48 dp) dark translucent circle,
centered in the bottom row rather than floating over the movie.
The other slots are combined Audio/Subtitles, −10 seconds, +10 seconds,
and Fit/Fill, respectively. The top row keeps Back, movie title, PiP and
settings. No Cast action. Existing brightness, volume, horizontal seek,
double-tap Fit/Fill, pinch, and VLC decoder modes are preserved.
