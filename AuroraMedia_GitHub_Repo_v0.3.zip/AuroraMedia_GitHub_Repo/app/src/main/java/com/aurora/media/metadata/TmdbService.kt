package com.aurora.media.metadata

import com.aurora.media.data.MediaEntry
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** TMDb search: supports v3 API key (32-hex characters) or API Read Access Token (Bearer). */
class TmdbService(private val bearerToken: String) {
    fun enrich(item: MediaEntry): MediaEntry {
        if (bearerToken.isBlank()) return item
        val title = item.seriesName ?: item.title
        val type = if (item.isEpisode) "tv" else "movie"
        val preferred = search(type, title, item.year.takeUnless { item.isEpisode })
        val results = if (preferred.length() == 0 && item.year != null && !item.isEpisode) {
            search(type, title, null)
        } else preferred
        if (results.length() == 0) return item
        val match = (0 until results.length()).map { results.getJSONObject(it) }
            .firstOrNull { it.optString("poster_path").startsWith("/") }
            ?: results.getJSONObject(0)
        val posterPath = match.optString("poster_path").takeIf { it.startsWith('/') }
        val backdropPath = match.optString("backdrop_path").takeIf { it.startsWith('/') }
        return item.copy(
            poster = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" },
            backdrop = backdropPath?.let { "https://image.tmdb.org/t/p/w1280$it" },
            description = match.optString("overview").takeIf { it.isNotBlank() },
            remoteId = match.optInt("id", 0).takeIf { it > 0 },
            mediaType = type
        )
    }

    private fun search(type: String, title: String, year: Int?): org.json.JSONArray {
        val token = bearerToken.trim().removePrefix("Bearer ").trim()
        val isV3Key = token.matches(Regex("[0-9a-fA-F]{32}"))
        val auth = if (isV3Key) "&api_key=$token" else ""
        val encodedTitle = URLEncoder.encode(title, "UTF-8")
        val yearParam = year?.let { "&year=$it" }.orEmpty()
        val endpoint = "https://api.themoviedb.org/3/search/$type?query=$encodedTitle$yearParam&include_adult=false$auth"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 8_000
            if (!isV3Key) setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val status = connection.responseCode
            if (status == 401 || status == 403) error("TMDb authentication failed. Use a valid API Read Access Token or v3 API key.")
            if (status != 200) error("TMDb HTTP $status. Try again later.")
            val response = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            response.optJSONArray("results") ?: org.json.JSONArray()
        } finally {
            connection.disconnect()
        }
    }
}
