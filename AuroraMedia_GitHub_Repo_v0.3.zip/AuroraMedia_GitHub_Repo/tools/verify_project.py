"""Aurora Media static checks; no Android SDK required. Not a substitute for Gradle compile/device testing."""
from pathlib import Path
from xml.etree import ElementTree
import re

root = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/aurora/media/MainActivity.kt',
    'app/src/main/java/com/aurora/media/player/VlcSession.kt',
    'app/src/main/java/com/aurora/media/player/PlayerScreen.kt',
    'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt',
    'app/src/main/java/com/aurora/media/metadata/TmdbService.kt',
]
for f in required:
    if not (root / f).is_file():
        raise SystemExit(f'Missing essential source file: {f}')
manifest = ElementTree.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
android = '{http://schemas.android.com/apk/res/android}'
permissions = [x.attrib.get(android + 'name') for x in manifest.findall('uses-permission')]
if 'android.permission.INTERNET' not in permissions:
    raise SystemExit('INTERNET permission missing')
app = manifest.find('application')
if app is None or not app.attrib.get(android+'label') == 'Aurora Media':
    raise SystemExit('Aurora Media app label missing')
source_dir = root / 'app/src/main/java'
source = '\n'.join(f.read_text() for f in source_dir.rglob('*.kt'))
if 'Media.Slave.Type.Subtitle' in source:
    raise SystemExit('Unsupported Media.Slave.Type.Subtitle reference')
if re.search(r'fun\s+setSpeed\s*\(', source):
    raise SystemExit('Potential Kotlin property setter clash: setSpeed')
if 'session::setSpeed' in source:
    raise SystemExit('Stale playback speed method reference')
if 'session::updateSpeed' not in source:
    raise SystemExit('Missing playback speed UI callback')
if 'fun updateSpeed(value: Float)' not in source:
    raise SystemExit('Missing playback speed method')
ftp = (root / 'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt').read_text()
if 'FTP.BINARY_FILE_TYPE' not in ftp or 'enterLocalPassiveMode()' not in ftp:
    raise SystemExit('FTP binary/passive mode missing')
if 'ftp://' not in ftp:
    raise SystemExit('FTP stream URL missing')
if 'sftp://' in source.lower():
    raise SystemExit('SFTP included unexpectedly')
build = (root / 'app/build.gradle.kts').read_text()
if 'applicationId = "com.aurora.media"' not in build:
    raise SystemExit('Wrong application ID')
if 'compileSdk = 35' not in build:
    raise SystemExit('Android SDK 35 mismatch')
if 'org.videolan.android:libvlc-all:3.5.1' not in build:
    raise SystemExit('Expected VLC dependency missing')
print('PASS: source structure, XML, FTP-only configuration, LibVLC references, Gradle constants')
print(f'Source files: {len(list(source_dir.rglob("*.kt")))} Kotlin files')
