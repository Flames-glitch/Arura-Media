package com.aurora.media

import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aurora.media.player.VlcSession
import com.aurora.media.ui.AuroraApp
import com.aurora.media.ui.AuroraViewModel

/** One foreground player at a time. No background-only audio playback. */
class MainActivity : ComponentActivity() {
    private var playerSession: VlcSession? = null
    var inPlayerPiP by mutableStateOf(false)
        private set

    fun registerPlayer(session: VlcSession?) {
        playerSession = session
    }

    /** Called from the on-screen PiP button and when Home is pressed. */
    fun enterPlayerPiP(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return false
        if (isInPictureInPictureMode) return true
        if (playerSession?.isPlaying != true) return false
        return runCatching {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }.getOrDefault(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val model: AuroraViewModel = viewModel()
            AuroraApp(model)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Home -> PiP when possible. If unavailable onStop pauses the player.
        enterPlayerPiP()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPlayerPiP = isInPictureInPictureMode
    }

    override fun onStop() {
        super.onStop()
        // Prevent invisible FTP video/audio when the activity is fully backgrounded.
        if (!isInPictureInPictureMode) playerSession?.pauseIfPlaying()
    }

    override fun onDestroy() {
        playerSession = null
        super.onDestroy()
    }
}
