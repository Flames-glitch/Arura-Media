"""Aurora Media static checks; no Android SDK required. Not a substitute for Gradle compile/device testing."""
from pathlib import Path
from xml.etree import ElementTree
import re

root = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/aurora/media/MainActivity.kt',
    'app/src/main/java/com/aurora/media/player/VlcSession.kt',
    'app/src/main/java/com/aurora/media/player/PlayerScreen.kt',
    'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt',
    'app/src/main/java/com/aurora/media/metadata/TmdbService.kt',
]
for f in required:
    if not (root / f).is_file():
        raise SystemExit(f'Missing essential source file: {f}')
manifest = ElementTree.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
android = '{http://schemas.android.com/apk/res/android}'
permissions = [x.attrib.get(android + 'name') for x in manifest.findall('uses-permission')]
if 'android.permission.INTERNET' not in permissions:
    raise SystemExit('INTERNET permission missing')
app = manifest.find('application')
if app is None or not app.attrib.get(android+'label') == 'Aurora Media':
    raise SystemExit('Aurora Media app label missing')
source_dir = root / 'app/src/main/java'
source = '\n'.join(f.read_text() for f in source_dir.rglob('*.kt'))
if 'Media.Slave.Type.Subtitle' in source:
    raise SystemExit('Unsupported Media.Slave.Type.Subtitle reference')
if re.search(r'fun\s+setSpeed\s*\(', source):
    raise SystemExit('Potential Kotlin property setter clash: setSpeed')
if 'session::setSpeed' in source:
    raise SystemExit('Stale playback speed method reference')
if 'session::updateSpeed' not in source:
    raise SystemExit('Missing playback speed UI callback')
if 'fun updateSpeed(value: Float)' not in source:
    raise SystemExit('Missing playback speed method')
ftp = (root / 'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt').read_text()
if 'FTP.BINARY_FILE_TYPE' not in ftp or 'enterLocalPassiveMode()' not in ftp:
    raise SystemExit('FTP binary/passive mode missing')
if 'ftp://' not in ftp:
    raise SystemExit('FTP stream URL missing')
if 'sftp://' in source.lower():
    raise SystemExit('SFTP included unexpectedly')
build = (root / 'app/build.gradle.kts').read_text()
if 'applicationId = "com.aurora.media"' not in build:
    raise SystemExit('Wrong application ID')
if 'compileSdk = 35' not in build:
    raise SystemExit('Android SDK 35 mismatch')
if 'org.videolan.android:libvlc-all:3.5.1' not in build:
    raise SystemExit('Expected VLC dependency missing')
print('PASS: source structure, XML, FTP-only configuration, LibVLC references, Gradle constants')
print(f'Source files: {len(list(source_dir.rglob("*.kt")))} Kotlin files')

# V0.6.2 regression gates: offloader deliberately removed; FTP playback untouched.
ui = (root / 'app/src/main/java/com/aurora/media/ui/AuroraApp.kt').read_text()
vm = (root / 'app/src/main/java/com/aurora/media/ui/AuroraViewModel.kt').read_text()
player = (root / 'app/src/main/java/com/aurora/media/player/PlayerScreen.kt').read_text()
session = (root / 'app/src/main/java/com/aurora/media/player/VlcSession.kt').read_text()
activity = (root / 'app/src/main/java/com/aurora/media/MainActivity.kt').read_text()
cleaner = (root / 'app/src/main/java/com/aurora/media/ftp/FilenameCleaner.kt').read_text()
properties = (root / 'gradle.properties').read_text()
app_source = (root / 'app/src/main/java/com/aurora/media/AuroraApplication.kt').read_text()
legacy_worker = (root / 'app/src/main/java/com/aurora/media/offload/OffloadWorker.kt').read_text()
rotation = (root / 'app/src/main/java/com/aurora/media/ui/SpotlightRotation.kt').read_text()
manifest_text = (root / 'app/src/main/AndroidManifest.xml').read_text()
regressions = {
    "AndroidX enabled": "android.useAndroidX=true" in properties,
    "Old malformed remote constant absent": "KEYCODE_HEADSETPHOOK" not in source,
    "Previous speed setter clash absent": "fun setSpeed(" not in source,
    "Previous LibVLC subtitle enum absent": "Media.Slave.Type.Subtitle" not in source,
    "Original FTP stream retained": "ftp://" in ftp and "FtpScanner.mediaUrl" in session,
    "Start from Beginning retained": "Start from Beginning" in ui and "fromBeginning" in vm,
    "Playback suggestions retained": "What to watch next" in player and "recommendationsFor" in vm,
    "Screen awake during playback": "FLAG_KEEP_SCREEN_ON" in player,
    "PiP dismissal pauses playback without resetting position": "onPictureInPictureModeChanged" in activity and "pauseForBackground(autoResume = !lastPiPExitPending)" in activity,
    "Delayed buffering spinner": "bufferingCheck" in session and "> 3000L" in session,
    "Filename watermark cleanup": "websitePrefix" in cleaner and "solar" in cleaner,
    "Cached movie title refresh": "cached.title == current.title" in vm,
    "Featured carousel has timer": "delay(8_000L)" in ui,
    "Featured carousel traverses list": "nextSpotlightIndex" in ui and "previousSpotlightIndex" in ui,
    "Featured uses actual FTP entries": "val movies = entries.filterNot" in ui,
    "Single-item rotation safe": "if (count <= 1) 0" in rotation,
    "FTP upload button removed": "CloudUpload" not in ui and "onOffload" not in ui,
    "FTP upload screen removed": "Screen.Offload" not in source,
    "FTP upload engine removed": not (root / 'app/src/main/java/com/aurora/media/offload/OffloadEngine.kt').exists(),
    "Old queued moves cancelled": "cancelUniqueWork(\"aurora_phone_offload_now\")" in app_source and "cancelUniqueWork(\"aurora_phone_offload_daily\")" in app_source,
    "Old jobs cannot run uploads": "override suspend fun doWork(): Result = Result.failure()" in legacy_worker,
    "Foreground upload service not requested": "FOREGROUND_SERVICE_DATA_SYNC" not in manifest_text,
    "App version code incremented": "versionCode = 12" in build and 'versionName = "0.6.3"' in build,
}
for label, ok in regressions.items():
    if not ok: raise SystemExit("Regression detected: " + label)
print(f"PASS: {len(regressions)} V0.6.2 rotation/player/safe-retirement regression checks")

# V0.6.3 preflight: preset FTP connection, editable overrides, India-specific TMDb discovery.
settings = (root / 'app/src/main/java/com/aurora/media/data/SecureSettings.kt').read_text()
metadata = (root / 'app/src/main/java/com/aurora/media/metadata/TmdbService.kt').read_text()
models = (root / 'app/src/main/java/com/aurora/media/data/Models.kt').read_text()
checks = {
    "FTP host prefilled": 'preferences.getString("host", "192.168.1.254")' in settings,
    "FTP username prefilled": 'preferences.getString("username", "userAdmin")' in settings,
    "FTP password first-run preset": 'preferences.contains("password")' in settings and 'else "tsbb@123"' in settings,
    "FTP directory first-run preset": 'preferences.getString("directory", "/usb1_1/movies")' in settings,
    "FTP fields editable": all(f'{{ {field} = it }}' in ui for field in ["host", "username", "password", "directory"]),
    "Encrypted later-saved FTP password": '.putString("password", encrypt(settings.password))' in settings,
    "Existing settings prioritized": 'preferences.contains("password")' in settings and 'preferences.getString("host"' in settings,
    "TMDb default credential for upcoming films": 'tmdbToken = decrypt' in settings and '.ifBlank {' in settings,
    "TMDb theatre discover endpoint": 'discover/movie' in metadata,
    "India theatre region": 'upcomingTheatrical("IN")' in vm and 'with_release_type=2%7C3' in metadata,
    "Upcoming tab": '"Upcoming"' in ui and 'UpcomingTheatresSection' in ui,
    "Upcoming items not FTP playable": 'data class UpcomingMovie' in models and 'Coming to theatres • Not in your FTP library' in ui,
    "Upcoming refresh and error handling": 'onRefresh = { onLoadUpcoming(true) }' in ui and 'upcomingError' in vm,
}
for label, ok in checks.items():
    if not ok: raise SystemExit("V0.6.3 regression detected: " + label)
print(f'PASS: {len(checks)} V0.6.3 FTP preset and theatres checks')

# V0.6.3 premium-player and trailer regression gates
trailer = (root / 'app/src/main/java/com/aurora/media/metadata/TrailerSelection.kt').read_text()
new_checks = {
    'Real TMDb trailer video endpoint': '/videos?language=en-US' in metadata,
    'YouTube trailer validated before URL creation': 'selectBestYouTubeKey(candidates)' in metadata and '[A-Za-z0-9_-]{11}' in trailer,
    'YouTube search when video metadata absent': 'youtube.com/results?search_query=' in ui,
    'Trailer fetched off UI thread': 'withContext(Dispatchers.IO)' in ui,
    'Home theatre preview': 'Coming to Theatres' in ui and 'upcoming.take(8)' in ui,
    'Trailer does not add FTP entries': 'UpcomingMovie' in ui and 'onSelect = { selectedUpcoming = it }' in ui,
    'Swipe seeking': 'SwipeMode.SEEK' in player and 'session.seek(gestureSeek)' in player,
    'Left brightness gesture': 'SwipeMode.BRIGHTNESS' in player and 'params.screenBrightness = level' in player,
    'Right volume gesture': 'SwipeMode.VOLUME' in player and 'setStreamVolume' in player,
    'VLC-style compact controls': 'Icons.Default.Replay10' in player and 'Icons.Default.Forward10' in player,
    'Combined audio and subtitle picker': '"tracks" -> AlertDialog' in player and 'trackTab' in player,
    'PiP retained': 'enterPlayerPiP' in player and 'pauseForBackground' in activity,
    'No cast control in player': 'Cast' not in player and 'cast' not in player.lower(),
    'Player uses transparent gradient overlays': 'Brush.verticalGradient' in player,
    'Player controls auto-hide': 'delay(5_000L)' in player,
    'App display version remains 0.6.3': 'versionName = "0.6.3"' in build,
    'Video surface rebound on AndroidView update': 'update = { view -> session.attach(view) }' in player,
    'Background playback pauses not stops': 'pauseForBackground' in activity and 'playerSession?.stopPlayback()' not in activity,
    'Center play pause control uses screen center': 'Modifier.align(Alignment.Center)' in player,
    'Retain video position on return': 'resumeAfterBackground' in activity and 'resumeAfterSuspension' in session,

}
for label, ok in new_checks.items():
    if not ok: raise SystemExit('Premium player/trailer regression detected: ' + label)
print(f'PASS: {len(new_checks)} premium UI, gesture, PiP, trailer and player checks')
