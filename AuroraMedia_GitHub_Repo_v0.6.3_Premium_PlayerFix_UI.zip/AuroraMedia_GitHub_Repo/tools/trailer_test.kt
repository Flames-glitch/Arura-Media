import com.aurora.media.metadata.YouTubeVideo
import com.aurora.media.metadata.selectBestYouTubeKey

fun main() {
    val teaser = YouTubeVideo("YouTube", "ABCDEFGHIJK", "Teaser", true, "en")
    val trailer = YouTubeVideo("youtube", "LMNOPQRSTUV", "Trailer", true, "hi")
    val unofficial = YouTubeVideo("YouTube", "WXYZ1234567", "Trailer", false, "en")
    check(selectBestYouTubeKey(listOf(teaser, unofficial, trailer)) == trailer.key)
    check(selectBestYouTubeKey(listOf(teaser)) == teaser.key)
    check(selectBestYouTubeKey(listOf(YouTubeVideo("Vimeo", "ABCDEFGHIJK", "Trailer", true, "en"))) == null)
    check(selectBestYouTubeKey(listOf(YouTubeVideo("YouTube", "invalid!", "Trailer", true, "en"))) == null)
    check(selectBestYouTubeKey(listOf(YouTubeVideo("YouTube", "ABCDEFGHIJK", "Featurette", true, "en"))) == null)
    check(selectBestYouTubeKey(emptyList()) == null)
    println("PASS: TMDb YouTube trailer priority, validated keys, video-site restrictions, fallback")
}
