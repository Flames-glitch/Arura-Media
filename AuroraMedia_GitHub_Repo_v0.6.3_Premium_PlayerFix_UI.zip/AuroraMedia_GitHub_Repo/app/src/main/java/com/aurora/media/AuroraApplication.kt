package com.aurora.media

import android.app.Application
import androidx.work.WorkManager

class AuroraApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Disable all previously scheduled FTP move/upload work on every launch.
        // Cancel is asynchronous; the legacy OffloadWorker stub is deliberately
        // harmless even if an old persisted WorkManager job starts first.
        runCatching {
            WorkManager.getInstance(this).apply {
                cancelUniqueWork("aurora_phone_offload_now")
                cancelUniqueWork("aurora_phone_offload_daily")
            }
        }
    }
}
