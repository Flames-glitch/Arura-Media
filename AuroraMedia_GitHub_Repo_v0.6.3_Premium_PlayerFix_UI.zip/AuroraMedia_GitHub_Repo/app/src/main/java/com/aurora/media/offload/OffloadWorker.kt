package com.aurora.media.offload

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Compatibility-only stub for V0.5/V0.6 WorkManager jobs persisted on upgrades.
 * No uploads and absolutely no file deletion can occur in this version.
 */
class OffloadWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = Result.failure()
}
