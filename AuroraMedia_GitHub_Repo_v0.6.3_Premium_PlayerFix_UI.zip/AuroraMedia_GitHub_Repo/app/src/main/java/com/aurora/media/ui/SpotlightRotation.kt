package com.aurora.media.ui

/** Stable indices for the automatically rotating FTP-library featured carousel. */
internal fun nextSpotlightIndex(index: Int, count: Int): Int =
    if (count <= 1) 0 else ((index.coerceIn(0, count - 1)) + 1) % count

internal fun previousSpotlightIndex(index: Int, count: Int): Int =
    if (count <= 1) 0 else (index.coerceIn(0, count - 1) + count - 1) % count
