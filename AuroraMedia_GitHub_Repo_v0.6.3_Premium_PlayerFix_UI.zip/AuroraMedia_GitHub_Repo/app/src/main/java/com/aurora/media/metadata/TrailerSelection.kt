package com.aurora.media.metadata

/** Keep trailer matching independent of Android so it can be tested before an APK build. */
data class YouTubeVideo(val site: String, val key: String, val type: String,
                        val official: Boolean, val language: String)

fun selectBestYouTubeKey(videos: List<YouTubeVideo>): String? = videos
    .asSequence()
    .filter { it.site.equals("youtube", ignoreCase = true) }
    .filter { it.key.matches(Regex("[A-Za-z0-9_-]{11}")) }
    .filter { it.type.equals("Trailer", ignoreCase = true) || it.type.equals("Teaser", ignoreCase = true) }
    .sortedWith(compareByDescending<YouTubeVideo> { it.type.equals("Trailer", ignoreCase = true) }
        .thenByDescending { it.official }
        .thenByDescending { it.language.equals("en", ignoreCase = true) })
    .firstOrNull()?.key
