package com.aurora.media.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class SpotlightRotationTest {
    @Test fun loopsAcrossEntireLibrary() {
        assertEquals(1, nextSpotlightIndex(0, 4))
        assertEquals(2, nextSpotlightIndex(1, 4))
        assertEquals(3, nextSpotlightIndex(2, 4))
        assertEquals(0, nextSpotlightIndex(3, 4))
    }

    @Test fun manualPreviousAndSmallLibraries() {
        assertEquals(3, previousSpotlightIndex(0, 4))
        assertEquals(1, previousSpotlightIndex(2, 4))
        assertEquals(0, previousSpotlightIndex(0, 1))
        assertEquals(0, nextSpotlightIndex(0, 0))
    }
}
