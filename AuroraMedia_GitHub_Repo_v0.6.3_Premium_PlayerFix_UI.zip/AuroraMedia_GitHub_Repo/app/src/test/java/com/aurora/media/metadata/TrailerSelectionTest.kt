package com.aurora.media.metadata

import org.junit.Assert.*
import org.junit.Test

class TrailerSelectionTest {
    @Test fun selectsOfficialTrailerOverTeaser() {
        val videos = listOf(
            YouTubeVideo("YouTube", "ABC123_DE45", "Teaser", true, "en"),
            YouTubeVideo("YouTube", "XYZ123_DE45", "Trailer", true, "hi")
        )
        assertEquals("XYZ123_DE45", selectBestYouTubeKey(videos))
    }
    @Test fun rejectsInvalidOrUntrustedSources() {
        assertNull(selectBestYouTubeKey(listOf(
            YouTubeVideo("Vimeo", "ABC123_DE45", "Trailer", true, "en"),
            YouTubeVideo("YouTube", "../bad", "Trailer", true, "en")
        )))
    }
}
