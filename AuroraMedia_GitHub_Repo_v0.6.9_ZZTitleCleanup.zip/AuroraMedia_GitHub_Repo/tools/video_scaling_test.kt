import com.aurora.media.player.VideoBounds
import com.aurora.media.player.VideoScaling

fun main() {
    require(VideoScaling.compute(2400,1080,16f/9f,false) == VideoBounds(1920,1080))
    require(VideoScaling.compute(2400,1080,16f/9f,true) == VideoBounds(2400,1350))
    require(VideoScaling.compute(1080,2400,16f/9f,false) == VideoBounds(1080,608))
    require(VideoScaling.compute(480,270,16f/9f,false) == VideoBounds(480,270))
    require(VideoScaling.compute(2400,1080,4f/3f,false) == VideoBounds(1440,1080))
    require(VideoScaling.compute(2400,1080,4f/3f,true) == VideoBounds(2400,1800))
    require(VideoScaling.zoomFactor(2400, 1080, 16f/9f, false) == 1f)
    require(kotlin.math.abs(VideoScaling.zoomFactor(2400, 1080, 16f/9f, true) - 1.25f) < 0.0001f)
    require(VideoScaling.zoomFactor(480, 270, 16f/9f, true) == 1f)
    require(VideoScaling.zoomFactor(2400, 1080, 4f/3f, true) > 1f)
    // A 1920×1080 movie on a 2400×1080 phone fills by 1.25x in VLC.
    require(VideoScaling.vlcScale(2400, 1080, 1920, 1080, 1, 1, false) == 0f)
    require(kotlin.math.abs(VideoScaling.vlcScale(2400, 1080, 1920, 1080, 1, 1, true) - 1.25f) < 0.0001f)
    // After entering PiP, calculations MUST use the new viewport and Fit.
    require(VideoScaling.vlcScale(480, 270, 1920, 1080, 1, 1, false) == 0f)
    require(kotlin.math.abs(VideoScaling.vlcScale(2400, 1080, 1920, 1080, 1, 1, true) - 1.25f) < 0.0001f)
    // Preserve sample aspect ratio on non-square-pixel material.
    require(kotlin.math.abs(VideoScaling.vlcScale(1200, 720, 720, 576, 16, 15, true) - 1.5625f) < 0.0001f)
    require(VideoScaling.vlcScale(2400, 1080, 0, 0, 1, 1, true) == 0f)
    println("PASS: Fit/Fill source-aspect geometry, crop and PiP/fullscreen resizing")
}
