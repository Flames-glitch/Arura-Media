import com.aurora.media.ftp.SeriesGrouping

fun main() {
    val path = "/usb1_1/movies/The Court (2026)/Season 1/S01E29.mkv"
    check(SeriesGrouping.folderYear(path) == 2026)
    val matched = SeriesGrouping.locate("S01E29")!!
    check(SeriesGrouping.label("S01E29", matched, path.substringBeforeLast('/')) == "The Court")
    val withShowName = SeriesGrouping.locate("The Court S01E30")!!
    check(SeriesGrouping.label("The Court S01E30", withShowName, path.substringBeforeLast('/')) == "The Court")
    println("PASS: nested FTP year, filename-only episode, and full series title")
}
