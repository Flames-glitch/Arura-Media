import com.aurora.media.ftp.FilenameCleaner

fun main() {
    val cases = listOf(
      Triple("www.1TamilMV.solar - Drones (2026) Tamil HQ PreDVD - 1080p - x264 - HQ Clean - AAC - 2.8GB.mkv", "Drones", 2026),
      Triple("www.Example.com - A Simple Film (2024) 1080p.mkv", "A Simple Film", 2024),
      Triple("www.1TamilMV.capital - Jailer (2023) Tamil 1080p WEB-DL.mkv", "Jailer", 2023),
      Triple("www.1TamilMV.lease - Kahan Shuru Kahan Khatam (2024) Hindi 720p WEB-DL.mkv", "Kahan Shuru Kahan Khatam", 2024),
      Triple("[www.1TamilMV.lease] - The Court (2026) S01E29 WEB-DL.mkv", "The Court", 2026),
      Triple("1TamilMV.capital - The Paradise (2026) 1080p x264.mkv", "The Paradise", 2026),
      Triple("The.Matrix.1999.BluRay.mkv", "The Matrix", 1999),
      Triple("Interstellar.2014.1080p.BluRay.x264.mkv", "Interstellar", 2014),
      Triple("Breaking.Bad.S02E03.720p.WEB-DL.mkv", "Breaking Bad", null),
      Triple("Great Movie (2023) 2160p HDR.mkv", "Great Movie", 2023),
      Triple("The Dark Knight (2008).mp4", "The Dark Knight", 2008)
    )
    cases.forEach { (file, expectedTitle, expectedYear) ->
      val stem = FilenameCleaner.cleanedStem(file)
      val title = FilenameCleaner.movieTitle(stem, Regex("(?i)S[0-9]{1,2}[._ -]*E[0-9]{1,3}").find(stem)?.range?.first)
      val yr = FilenameCleaner.yearOf(stem)
      check(title == expectedTitle && yr == expectedYear) { "FAIL: $file -> [$title] [$yr] expected [$expectedTitle] [$expectedYear]" }
      println("PASS: $title (${yr ?: "episode"})")
    }
}
