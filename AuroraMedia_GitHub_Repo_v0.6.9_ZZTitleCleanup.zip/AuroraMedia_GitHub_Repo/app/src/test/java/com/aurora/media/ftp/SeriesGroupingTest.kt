package com.aurora.media.ftp

import org.junit.Assert.*
import org.junit.Test

class SeriesGroupingTest {
    @Test fun matchesSeriesAndSeasons() {
        val files = listOf("The Court S01E29", "The.Court.S01E30", "The Court S02E01")
        val series = files.map { stem ->
            val match = SeriesGrouping.locate(stem)!!
            SeriesGrouping.key(SeriesGrouping.label(stem, match, "TV"))
        }
        assertEquals(1, series.distinct().size)
        assertEquals("the court", series.first())
        assertEquals(29, SeriesGrouping.numbers("S01E29")!!.episode)
        assertEquals(2, SeriesGrouping.numbers("S02E01")!!.season)
    }

    @Test fun supportsAlternativeEpisodeNumbers() {
        assertEquals(4, SeriesGrouping.numbers("1x04")!!.episode)
        assertEquals(3, SeriesGrouping.numbers("Season 2 Episode 3")!!.episode)
    }
}
