package com.aurora.media.ftp

import org.junit.Assert.assertEquals
import org.junit.Test

class FilenameCleanerTest {
    @Test fun movieWithWebsitePrefix() {
        val stem = FilenameCleaner.cleanedStem(
            "www.1TamilMV.solar - Drones (2026) Tamil HQ PreDVD - 1080p - x264 - HQ Clean - AAC - 2.8GB.mkv"
        )
        assertEquals("Drones", FilenameCleaner.movieTitle(stem))
        assertEquals(2026, FilenameCleaner.yearOf(stem))
    }

    @Test fun regularMovieRelease() {
        val stem = FilenameCleaner.cleanedStem("Interstellar.2014.1080p.BluRay.x264.mkv")
        assertEquals("Interstellar", FilenameCleaner.movieTitle(stem))
        assertEquals(2014, FilenameCleaner.yearOf(stem))
    }

    @Test fun episodeName() {
        val stem = FilenameCleaner.cleanedStem("Breaking.Bad.S02E03.720p.WEB-DL.mkv")
        val episode = Regex("(?i)S[0-9]{1,2}[. _-]*E[0-9]{1,3}").find(stem)
        assertEquals("Breaking Bad", FilenameCleaner.movieTitle(stem, episode?.range?.first))
    }

    @Test fun bracketedReleaseSite() {
        val stem = FilenameCleaner.cleanedStem("[www.Example.com] - Great Movie (2023) 2160p HDR.mkv")
        assertEquals("Great Movie", FilenameCleaner.movieTitle(stem))
        assertEquals(2023, FilenameCleaner.yearOf(stem))
    }

    @Test fun rotatingWebsiteSuffixesDoNotPolluteTitle() {
        val examples = listOf(
            Triple("www.1TamilMV.capital - Jailer (2023) Tamil WEB-DL 1080p.mkv", "Jailer", 2023),
            Triple("www.1TamilMV.lease - Kahan Shuru Kahan Khatam (2024) Hindi 720p.mkv", "Kahan Shuru Kahan Khatam", 2024),
            Triple("1TamilMV.capital - The Paradise (2026) 1080p.mkv", "The Paradise", 2026),
            Triple("The.Matrix.1999.BluRay.mkv", "The Matrix", 1999)
        )
        examples.forEach { (filename, title, year) ->
            val stem = FilenameCleaner.cleanedStem(filename)
            assertEquals(title, FilenameCleaner.movieTitle(stem))
            assertEquals(year, FilenameCleaner.yearOf(stem))
        }
    }
}
