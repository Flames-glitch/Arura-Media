package com.aurora.media.metadata

import org.junit.Assert.*
import org.junit.Test

class TvMatchTest {
    @Test fun falsePositiveArtworkMustNotBeUsed() {
        assertFalse(TvMatch.exact("The Court", "The People's Court"))
        assertTrue(TvMatch.exact("The Court", "the-court"))
        assertTrue(TvMatch.exact("The Big Bang Theory", "The Big Bang Theory"))
        assertFalse(TvMatch.exact("The Office", "The Office UK Special"))
    }
}
