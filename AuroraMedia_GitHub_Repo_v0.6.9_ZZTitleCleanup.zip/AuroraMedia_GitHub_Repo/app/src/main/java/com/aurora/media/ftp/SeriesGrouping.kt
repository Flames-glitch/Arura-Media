package com.aurora.media.ftp

import java.util.Locale

data class EpisodeNumber(val season: Int, val episode: Int)

/** Normalized identity for files belonging to the same TV series. */
object SeriesGrouping {
    private val episodePattern = Regex("""(?i)S(\d{1,2})[. _-]*E(\d{1,3})""")
    private val alternativePattern = Regex("""(?i)(?<!\d)(\d{1,2})x(\d{1,3})(?!\d)""")
    private val wordsPattern = Regex("""(?i)Season[. _-]*(\d{1,2})[. _-]*Episode[. _-]*(\d{1,3})""")
    fun locate(stem: String): MatchResult? =
        episodePattern.find(stem) ?: alternativePattern.find(stem) ?: wordsPattern.find(stem)

    fun numbers(code: String?): EpisodeNumber? {
        if (code.isNullOrBlank()) return null
        val match = locate(code) ?: return null
        val season = match.groupValues[1].toIntOrNull() ?: return null
        val episode = match.groupValues[2].toIntOrNull() ?: return null
        return EpisodeNumber(season, episode)
    }

    /** Recover a release year from a nested FTP folder such as The Court (2026)/Season 1. */
    fun folderYear(path: String): Int? {
        val folders = path.substringBeforeLast('/', "").split('/').asReversed()
        val year = Regex("""(?<!\d)(?:19|20)\d{2}(?!\d)""")
        return folders.firstNotNullOfOrNull { folder ->
            year.find(folder)?.value?.toIntOrNull()
        }
    }

    fun key(name: String?): String = name.orEmpty()
        .lowercase(Locale.ROOT).replace(Regex("""[^\p{L}\p{N}]+"""), " ")
        .trim().replace(Regex("""\s+"""), " ")

    fun label(stem: String, match: MatchResult, parentPath: String): String {
        val beforeEpisode = stem.take(match.range.first).trim()
        val raw = if (beforeEpisode.isNotBlank()) FilenameCleaner.movieTitle(beforeEpisode) else ""
        if (raw.isNotBlank()) return raw
        // Episode-only filenames such as S01E29.mp4 use the first meaningful
        // ancestor folder, skipping Season 1 and generic FTP storage folders.
        val generic = setOf("movies", "videos", "tv", "shows", "series", "usb1_1")
        val folder = parentPath.split('/').asReversed().firstOrNull { segment ->
            segment.isNotBlank() &&
                !segment.matches(Regex("""(?i)(?:season[._ -]*\d+|s\d{1,2})""")) &&
                segment.lowercase(Locale.ROOT) !in generic &&
                !segment.matches(Regex("""(?:19|20)\d{2}"""))
        } ?: return "Unknown Series"
        return FilenameCleaner.movieTitle(FilenameCleaner.cleanedStem(folder))
            .ifBlank { "Unknown Series" }
    }
}
