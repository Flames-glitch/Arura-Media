package com.aurora.media.ftp

/** Remove release-site watermarks and technical tags without losing a legitimate movie title. */
object FilenameCleaner {
    // Release websites frequently rotate domain endings (.solar, .capital, .lease, ...).
    // Match a leading www-prefixed domain, or a known release-site domain, rather
    // than maintaining an incomplete TLD allowlist. Require a delimiter so regular
    // movie names such as "The.Matrix.1999" are not mistaken for a website.
    private val websitePrefix = Regex(
        """(?i)^\s*[\[(]?\s*(?:(?:https?://)?(?:www\d*\.)[\p{L}\p{N}_-]+(?:\.[\p{L}\p{N}_-]+)+|(?:https?://)?(?:1tamilmv|tamilmv|1tamilblasters|tamilblasters)(?:\.[\p{L}\p{N}_-]+)+)\s*[\])]?(?:\s*[-–—|:]+\s*|[._]+)"""
    )
    private val leadingTags = Regex("""(?i)^\s*[\[(](?:tamilmv|tamilblasters|torrent|yts|yify|rarbg|www\.[^\])]+)[\])]\s*[-–._ ]*""")
    private val technical = Regex("""(?i)\b(2160p|1080p|720p|480p|uhd|hdrip|pre\s*dvdrip|predvd|bluray|blu-ray|brrip|bdrip|dvdrip|webrip|web-dl|hdtv|x264|x265|h264|h265|hevc|aac|dts|hdr10|hdr|remux|proper|repack|extended|multi|hq\s*clean)\b""")
    private val year = Regex("""(?<!\d)(?:19|20)\d{2}(?!\d)""")

    fun cleanedStem(filename: String): String {
        var name = filename.substringAfterLast('/').substringBeforeLast('.', filename.substringAfterLast('/'))
        // Multiple advertisement prefixes sometimes appear before the real title.
        repeat(4) {
            val updated = name.replace(websitePrefix, "").replace(leadingTags, "")
            if (updated == name) return@repeat
            name = updated
        }
        return name.trim(' ', '-', '_', '.')
    }

    fun yearOf(stem: String): Int? = year.find(stem)?.value?.toIntOrNull()

    fun movieTitle(stem: String, episodeOffset: Int? = null): String {
        val cutoff = listOfNotNull(episodeOffset, year.find(stem)?.range?.first, technical.find(stem)?.range?.first)
            .minOrNull() ?: stem.length
        return stem.take(cutoff).replace(Regex("[._]+"), " ")
            .replace(Regex("[\\[\\]()]"), " ")
            .replace(Regex("\\s+"), " ").trim(' ', '-', '_')
            .ifBlank { stem.replace(Regex("[._]+"), " ").trim() }
    }
}
