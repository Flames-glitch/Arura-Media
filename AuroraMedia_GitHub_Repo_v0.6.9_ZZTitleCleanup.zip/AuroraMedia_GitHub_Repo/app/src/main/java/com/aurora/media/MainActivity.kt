package com.aurora.media

import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.Lifecycle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aurora.media.player.VlcSession
import com.aurora.media.ui.AuroraApp
import com.aurora.media.ui.AuroraViewModel

/** One foreground player at a time. No background-only audio playback. */
class MainActivity : ComponentActivity() {
    private var playerSession: VlcSession? = null
    private var lastPiPExitPending = false
    private val mainHandler = Handler(Looper.getMainLooper())
    var inPlayerPiP by mutableStateOf(false)
        private set

    fun registerPlayer(session: VlcSession?) {
        playerSession = session
    }

    /** Called from the on-screen PiP button and when Home is pressed. */
    fun enterPlayerPiP(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return false
        if (isInPictureInPictureMode) return true
        if (playerSession?.isPlaying != true) return false
        return runCatching {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }.getOrDefault(false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val model: AuroraViewModel = viewModel()
            AuroraApp(model)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Home -> PiP when possible. If unavailable onStop stops the player.
        enterPlayerPiP()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val leavingPiP = inPlayerPiP && !isInPictureInPictureMode
        inPlayerPiP = isInPictureInPictureMode
        playerSession?.onPictureInPictureChanged(isInPictureInPictureMode)
        if (leavingPiP) {
            // PiP expansion must NOT create another VLC player or restart playback.
            // On PiP dismissal, onStop pauses audio and checkpoints the position.
            lastPiPExitPending = true
            // Let Android finish resizing the retained surface; don't force
            // detach/attach during PiP expansion unless its holder was lost.
            // Some Android builds dismiss PiP without immediately delivering
            // onStop. If the activity did not resume, mute/stop the floating player.
            mainHandler.postDelayed({
                if (lastPiPExitPending && !isInPictureInPictureMode &&
                    !lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                    playerSession?.pauseForBackground(autoResume = false)
                }
            }, 700L)
        }
    }

    override fun onResume() {
        super.onResume()
        // If the user expanded PiP, playback is already live. If returning from
        // another app/call, restore the original session with its video surface.
        if (!isInPictureInPictureMode) playerSession?.resumeAfterBackground()
        lastPiPExitPending = false
    }

    override fun onStop() {
        // In PiP the activity is stopped but VLC must keep producing picture/audio.
        // Outside PiP pause (never stop) so the same timeline remains seekable.
        if (!isInPictureInPictureMode) {
            playerSession?.pauseForBackground(autoResume = !lastPiPExitPending)
        }
        super.onStop()
    }

    override fun onDestroy() {
        playerSession?.close()
        playerSession = null
        super.onDestroy()
    }
}
