package com.aurora.media.player

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.view.Gravity
import org.videolan.libvlc.interfaces.IVLCVout
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aurora.media.data.FtpSettings
import com.aurora.media.data.MediaEntry
import com.aurora.media.ftp.FtpScanner
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/** Local LibVLC playback. FTP URLs are never sent to TMDb or any online search endpoint. */
class VlcSession(
    context: Context,
    private val entry: MediaEntry,
    private val settings: FtpSettings,
    private val onProgress: (Long, Long) -> Unit,
    private val onFinished: () -> Unit = {}
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val vlc = LibVLC(context.applicationContext, arrayListOf("--network-caching=3000", "--no-video-title-show"))
    private val player = MediaPlayer(vlc)
    // The user can switch to LibVLC's bundled FFmpeg software decoder for
    // blocky/corrupted hardware-decoded video. This preference contains no FTP data.
    private val playerPreferences = appContext.getSharedPreferences("aurora_player_preferences", Context.MODE_PRIVATE)
    var decoderMode by mutableStateOf(DecoderChoice.normalize(playerPreferences.getString("decoder_mode", null)))
        private set
    private var pendingDecoderSeekMs: Long? = null
    private var pauseAfterDecoderSeek = false
    var isPlaying by mutableStateOf(false)
        private set
    var positionMs by mutableStateOf(0L)
        private set
    var durationMs by mutableStateOf(0L)
        private set
    var isBuffering by mutableStateOf(false)
        private set
    var error by mutableStateOf("")
        private set
    /** Only genuine playback failures trigger automatic external handoff. */
    var fatalPlaybackError by mutableStateOf(false)
        private set
    var aspect by mutableStateOf("Fit")
        private set
    var volume by mutableStateOf(100)
        private set
    var audioDelayMs by mutableStateOf(0L)
        private set
    var subtitleDelayMs by mutableStateOf(0L)
        private set
    var speed by mutableStateOf(1f)
        private set

    private var started = false
    // Keep one MediaPlayer while Compose/PiP recreates its SurfaceView.
    private var attachedSurface: SurfaceView? = null
    private var needsVideoRebind = true
    // These are the REAL viewport dimensions. surfaceChanged reports surface/buffer
    // dimensions and must never be used to replace the PiP/fullscreen viewport.
    private var viewport: FrameLayout? = null
    private var videoAspect = 16f / 9f
    private var videoRatioKnown = false
    // Visible (uncropped) source pixels and their sample aspect ratio.
    // These are used to scale the VLC picture, NOT the Android SurfaceView.
    private var visibleVideoWidth = 0
    private var visibleVideoHeight = 0
    private var sampleAspectNum = 1
    private var sampleAspectDen = 1
    private var videoWindowWidth = 0
    private var videoWindowHeight = 0
    // Keep VLC's window size synchronized with the measured FULL viewport.
    // Never feed a cropped video rectangle or an old PiP buffer size to VLC.
    private var lastVoutWindowWidth = -1
    private var lastVoutWindowHeight = -1
    private var pictureInPicture = false
    // Avoid calling libvlc_video_set_scale on every Compose recomposition:
    // repeated identical changes can flush/re-layout its video output.
    private var lastAppliedScale = Float.NaN
    private var sourceAspectInitialized = false
    var videoWidth by mutableStateOf(0)
        private set
    var videoHeight by mutableStateOf(0)
        private set
    private val videoLayoutListener = object : IVLCVout.OnNewVideoLayoutListener {
        override fun onNewVideoLayout(
            vout: IVLCVout?, width: Int, height: Int,
            visibleWidth: Int, visibleHeight: Int, sarNum: Int, sarDen: Int
        ) {
            main.post {
                if (closed || visibleWidth <= 0 || visibleHeight <= 0) return@post
                val safeSarNum = sarNum.coerceAtLeast(1)
                val safeSarDen = sarDen.coerceAtLeast(1)
                videoWidth = visibleWidth
                videoHeight = visibleHeight
                visibleVideoWidth = visibleWidth
                visibleVideoHeight = visibleHeight
                sampleAspectNum = safeSarNum
                sampleAspectDen = safeSarDen
                videoAspect = (visibleWidth.toFloat() * safeSarNum / safeSarDen /
                    visibleHeight).coerceIn(0.25f, 5f)
                videoRatioKnown = true
                layoutVideoSurface()
            }
        }
    }
    private var suspended = false
    private var resumeAfterSuspension = false
    private var restored = false
    private var completed = false
    private var closed = false
    private var lastAdvancedAt = android.os.SystemClock.elapsedRealtime()
    private var lastObservedPosition = -1L
    private var bufferingCheck = 0

    /** Bind to the actual current surface, once the holder is valid. Never reopen
     * the FTP media just because Compose, PiP, or orientation resized the view. */
    fun attach(surface: SurfaceView, parent: FrameLayout) {
        if (closed) return
        if (attachedSurface !== surface) {
            runCatching { player.vlcVout.detachViews() }
            attachedSurface = surface
            needsVideoRebind = true
        }
        viewport = parent
        if (parent.width > 0 && parent.height > 0)
            updateVideoWindow(parent.width, parent.height)
        if (surface.holder.surface.isValid) {
            if (needsVideoRebind) restoreVideoOutput()
            startPlaybackIfNeeded()
        }
    }

    private fun startPlaybackIfNeeded() {
        if (started || closed || needsVideoRebind) return
        started = true
        player.aspectRatio = null
        player.scale = 0f
        player.setEventListener { event ->
            main.post {
                if (closed) return@post
                when (event.type) {
                    MediaPlayer.Event.Playing -> { fatalPlaybackError = false; isPlaying = true; isBuffering = false; lastAdvancedAt = android.os.SystemClock.elapsedRealtime() }
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> { isPlaying = false; isBuffering = false; bufferingCheck++ }
                    MediaPlayer.Event.Buffering -> {
                        if (isPlaying) {
                            val check = ++bufferingCheck
                            main.postDelayed({
                                if (!closed && isPlaying && check == bufferingCheck &&
                                    android.os.SystemClock.elapsedRealtime() - lastAdvancedAt > 3000L) {
                                    isBuffering = true
                                }
                            }, 2800L)
                        } else { isBuffering = false; bufferingCheck++ }
                    }
                    MediaPlayer.Event.TimeChanged, MediaPlayer.Event.LengthChanged, MediaPlayer.Event.PositionChanged -> {
                        if (pendingDecoderSeekMs == null) {
                            positionMs = player.time.coerceAtLeast(0L)
                        }
                        durationMs = player.length.coerceAtLeast(0L)
                        if (kotlin.math.abs(positionMs - lastObservedPosition) >= 250L) {
                            lastObservedPosition = positionMs
                            lastAdvancedAt = android.os.SystemClock.elapsedRealtime()
                            isBuffering = false
                            bufferingCheck++
                        }
                        // Switching decoders reopens the same FTP media on the SAME
                        // VLC session. Wait until seeking becomes available before
                        // restoring the precise timeline. Never write a transient 0
                        // position into the Continue Watching history.
                        val restartPosition = pendingDecoderSeekMs
                        if (restartPosition != null) {
                            if (player.isSeekable && durationMs > 0L) {
                                pendingDecoderSeekMs = null
                                restored = true
                                val seekTarget = restartPosition.coerceIn(0L, (durationMs - 1_000L).coerceAtLeast(0L))
                                if (seekTarget > 0L) player.time = seekTarget
                                positionMs = seekTarget
                                if (pauseAfterDecoderSeek) {
                                    pauseAfterDecoderSeek = false
                                    main.post { if (!closed) runCatching { player.pause() } }
                                }
                            }
                            return@post
                        }
                        if (!restored && entry.lastPositionMs > 5_000L && durationMs > entry.lastPositionMs + 10_000L) {
                            restored = true
                            player.time = entry.lastPositionMs
                        }
                        if (durationMs > 0 && positionMs >= 0) onProgress(positionMs, durationMs)
                    }
                    MediaPlayer.Event.EndReached -> {
                        isPlaying = false; isBuffering = false; completed = true; positionMs = 0L
                        onProgress(0L, durationMs)
                        onFinished()
                    }
                    MediaPlayer.Event.EncounteredError -> {
                        fatalPlaybackError = true
                        error = "Unable to decode or stream this video. Check FTP speed and device codec support."
                        isBuffering = false
                    }
                }
            }
        }
        try {
            val media = Media(vlc, Uri.parse(FtpScanner.mediaUrl(settings, entry.path)))
            // Auto asks LibVLC to use device acceleration where possible.
            // Software disables MediaCodec hardware decoding; bundled FFmpeg
            // handles video in software without MX Player or external .so packs.
            // 4K software decode may be too CPU-intensive on many phones.
            media.setHWDecoderEnabled(DecoderChoice.enableHardware(decoderMode), false)
            player.media = media
            media.release()
            player.play()
        } catch (exception: Exception) {
            fatalPlaybackError = true
            error = "Playback failed: ${exception.message ?: "Unknown error"}"
            isBuffering = false
        }
    }

    /**
     * Keep the Android SurfaceView MATCH_PARENT and let LibVLC control the
     * decoded picture within it. Android View.scaleX/scaleY do not reliably
     * transform SurfaceView's separately composited video layer. That is why
     * the previous Fill button sometimes did nothing, especially after PiP.
     *
     * Fit: VLC automatic Best Fit (scale=0, aspectRatio=null), so the whole
     * original picture is visible, with letterbox/pillarbox bars as needed.
     * Fill: VLC's *uniform* nonzero video scale, calculated from the source's
     * visible pixel dimensions / SAR and the current FULL viewport. This
     * enlarges and center-crops without changing the source aspect ratio.
     *
     * Never pass a cropped picture's dimensions or PiP holder buffer size to
     * the VLC window. Vout setWindowSize only gets the actual FrameLayout.
     */
    private fun layoutVideoSurface() {
        val surface = attachedSurface ?: return
        val width = videoWindowWidth
        val height = videoWindowHeight
        if (closed || width <= 0 || height <= 0) return

        val lp = surface.layoutParams as? FrameLayout.LayoutParams
        if (lp == null || lp.width != ViewGroup.LayoutParams.MATCH_PARENT ||
            lp.height != ViewGroup.LayoutParams.MATCH_PARENT || lp.gravity != Gravity.CENTER) {
            surface.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        }
        // Undo any view transform left from previous versions/compositions.
        if (surface.scaleX != 1f) surface.scaleX = 1f
        if (surface.scaleY != 1f) surface.scaleY = 1f

        if (lastVoutWindowWidth != width || lastVoutWindowHeight != height) {
            runCatching { player.vlcVout.setWindowSize(width, height) }.onSuccess {
                lastVoutWindowWidth = width
                lastVoutWindowHeight = height
            }
        }
        // Resetting to VLC's source aspectRatio is essential; setting it to
        // the phone's display ratio stretches 4:3 and ultrawide movies.
        val newScale = VideoScaling.vlcScale(
            width, height, visibleVideoWidth, visibleVideoHeight,
            sampleAspectNum, sampleAspectDen,
            zoomToFill = aspect == "Fill" && !pictureInPicture && videoRatioKnown
        )
        if (!sourceAspectInitialized || lastAppliedScale != newScale) {
            runCatching {
                if (!sourceAspectInitialized) {
                    player.aspectRatio = null
                    sourceAspectInitialized = true
                }
                player.scale = newScale
                lastAppliedScale = newScale
            }.onFailure { error = "Video scaling error: ${it.message ?: "unknown"}" }
        }
    }

    fun updateVideoWindow(width: Int, height: Int) {
        if (closed || width <= 0 || height <= 0) return
        videoWindowWidth = width
        videoWindowHeight = height
        layoutVideoSurface()
    }

    /** A PiP transition changes the available screen size asynchronously.
     * Recheck after the AndroidView completes layout; don't recreate the media. */
    fun onPictureInPictureChanged(enabled: Boolean) {
        if (closed) return
        pictureInPicture = enabled
        layoutVideoSurface()
        refreshVideoViewport()
        main.postDelayed({ if (!closed) refreshVideoViewport() }, 300L)
    }

    private fun refreshVideoViewport() {
        val parent = viewport ?: return
        parent.post {
            if (!closed && parent === viewport) updateVideoWindow(parent.width, parent.height)
        }
    }

    /** User-invoked recovery if Android's compositor loses the attached layer. */
    fun repairVideoOutput() {
        if (closed) return
        needsVideoRebind = true
        restoreVideoOutput()
        refreshVideoViewport()
    }

    fun onSurfaceCreated(surface: SurfaceView) {
        if (surface !== attachedSurface || closed) return
        // Android may destroy and recreate the same SurfaceHolder during PiP,
        // orientation transitions, or another application's fullscreen UI.
        if (needsVideoRebind) restoreVideoOutput()
        if (!needsVideoRebind) {
            startPlaybackIfNeeded()
            if (suspended) resumeAfterBackground()
        }
    }

    fun requestVideoRebind() { if (!closed) needsVideoRebind = true }

    private fun restoreVideoOutput() {
        val surface = attachedSurface ?: return
        if (closed || !surface.holder.surface.isValid) {
            needsVideoRebind = true
            return
        }
        runCatching {
            player.vlcVout.detachViews()
            player.vlcVout.setVideoView(surface)
            player.vlcVout.attachViews(videoLayoutListener)
            lastVoutWindowWidth = -1
            lastVoutWindowHeight = -1
            lastAppliedScale = Float.NaN
            sourceAspectInitialized = false
            needsVideoRebind = false
            error = ""
            layoutVideoSurface()
        }.onFailure {
            needsVideoRebind = true
            error = "Video display connection failed: ${it.message ?: "retry playback"}"
        }
    }

    /** Another app has taken focus. Pause, don't stop (stop resets the VLC timeline). */
    fun pauseForBackground(autoResume: Boolean) {
        if (closed || !started) return
        val currentlyPlaying = player.isPlaying || isPlaying
        resumeAfterSuspension = autoResume && currentlyPlaying
        suspended = true
        val currentTime = runCatching { player.time }.getOrDefault(positionMs)
        if (currentTime > 0L) positionMs = currentTime
        if (durationMs > 0L) onProgress(positionMs, durationMs)
        if (currentlyPlaying) runCatching { player.pause() }
        isPlaying = false
        isBuffering = false
    }

    /** Return from an interruption, reattaching video BEFORE restoring playback. */
    fun resumeAfterBackground() {
        if (closed || !started) return
        // Rebinding a still-valid SurfaceView on every app switch can itself
        // destroy video output. Rebind only if SurfaceHolder reported a loss
        // or a genuinely different SurfaceView was attached.
        if (attachedSurface?.holder?.surface?.isValid != true) needsVideoRebind = true
        if (needsVideoRebind) restoreVideoOutput()
        refreshVideoViewport()
        // Do not start audio before a valid video surface exists.
        if (needsVideoRebind) return
        if (suspended && resumeAfterSuspension) runCatching { player.play() }
        suspended = false
        resumeAfterSuspension = false
    }

    /** Reopen only when decoder actually changes, preserving stream position.
     * Useful for media that shows corrupted/black hardware-decoded frames.
     * A decoder switch is not a workaround for a destroyed Android SurfaceView.
     */
    fun selectDecoder(mode: String) {
        if (closed) return
        val selected = DecoderChoice.normalize(mode)
        if (selected == decoderMode && error.isBlank()) return
        val previouslyPlaying = runCatching { player.isPlaying }.getOrDefault(isPlaying)
        val resumePosition = runCatching { player.time }.getOrDefault(positionMs)
            .coerceAtLeast(positionMs).coerceAtLeast(0L)
        decoderMode = selected
        playerPreferences.edit().putString("decoder_mode", selected).apply()
        if (!started) return
        val wasPaused = !previouslyPlaying
        pendingDecoderSeekMs = resumePosition
        pauseAfterDecoderSeek = wasPaused
        restored = true
        error = ""
        fatalPlaybackError = false
        isBuffering = false
        bufferingCheck++
        try {
            player.stop()
            lastAppliedScale = Float.NaN
            sourceAspectInitialized = false
            // Reattach video output if Android/PiP dropped the video surface.
            needsVideoRebind = true
            restoreVideoOutput()
            if (needsVideoRebind) {
                pendingDecoderSeekMs = null
                error = "Video surface unavailable. Return to the player and try again."
                return
            }
            val media = Media(vlc, Uri.parse(FtpScanner.mediaUrl(settings, entry.path)))
            try {
                media.setHWDecoderEnabled(DecoderChoice.enableHardware(decoderMode), false)
                player.media = media
            } finally {
                media.release()
            }
            player.play()
        } catch (exception: Exception) {
            pendingDecoderSeekMs = null
            error = "Unable to switch video decoder: ${exception.message ?: "unknown error"}"
        }
    }

    fun togglePause() { if (!closed) { if (player.isPlaying) player.pause() else player.play() } }
    fun pauseIfPlaying() {
        if (!closed && player.isPlaying) player.pause()
    }
    /** Persist exact seek position before another installed app receives the FTP URL. */
    fun checkpointForExternalPlayer() {
        if (closed) return
        positionMs = runCatching { player.time.coerceAtLeast(0L) }.getOrDefault(positionMs)
            .coerceAtLeast(positionMs)
        if (durationMs > 0L) onProgress(positionMs, durationMs)
        pauseForBackground(autoResume = false)
    }

    fun stopPlayback() {
        if (closed) return
        runCatching { player.stop() }
        isPlaying = false
        isBuffering = false
    }
    fun skip(offsetMs: Long) { seek((player.time + offsetMs).coerceIn(0L, player.length.coerceAtLeast(0L))) }
    fun seek(ms: Long) { if (player.isSeekable) player.time = ms.coerceAtLeast(0L) }

    fun changeAspect(mode: String) {
        aspect = if (mode == "Fill") "Fill" else "Fit"
        // Reapply VLC's actual Best Fit vs. uniform Fill scaling immediately.
        // Preserve the selected mode through PiP and fullscreen transitions.
        layoutVideoSurface()
    }

    fun toggleAspect() = changeAspect(if (aspect == "Fit") "Fill" else "Fit")

    fun setVolumePercent(percent: Int) {
        volume = percent.coerceIn(0, 125)
        player.volume = volume
    }

    fun updateSpeed(value: Float) {
        speed = value.coerceIn(0.5f, 2f)
        player.rate = speed
    }

    fun shiftAudio(milliseconds: Long) {
        audioDelayMs = (audioDelayMs + milliseconds).coerceIn(-10_000, 10_000)
        player.setAudioDelay(audioDelayMs * 1000L) // microseconds
    }

    fun shiftSubtitles(milliseconds: Long) {
        subtitleDelayMs = (subtitleDelayMs + milliseconds).coerceIn(-10_000, 10_000)
        player.setSpuDelay(subtitleDelayMs * 1000L) // microseconds
    }

    fun audioTracks(): List<Pair<Int, String>> = runCatching {
        player.audioTracks?.map { it.id to it.name }.orEmpty()
    }.getOrDefault(emptyList())

    fun subtitleTracks(): List<Pair<Int, String>> = runCatching {
        player.spuTracks?.map { it.id to it.name }.orEmpty()
    }.getOrDefault(emptyList())

    fun selectAudio(id: Int) { player.audioTrack = id }
    fun selectSubtitle(id: Int) { player.spuTrack = id }

    fun loadExternalSubtitle(uri: Uri): Boolean = runCatching {
        // The system picker supplies a content:// URI; LibVLC expects a readable
        // local file path, so copy it into this app's private cache first.
        val suffix = when (appContext.contentResolver.getType(uri)) {
            "text/vtt" -> ".vtt"
            else -> ".srt"
        }
        val subtitlesDir = File(appContext.cacheDir, "subtitles").apply { mkdirs() }
        val file = File(subtitlesDir, "imported-${System.currentTimeMillis()}$suffix")
        val input = appContext.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Cannot access subtitle file")
        input.use { source -> file.outputStream().use { source.copyTo(it) } }
        if (file.length() == 0L || file.length() > 10L * 1024 * 1024) {
            file.delete()
            throw IllegalArgumentException("Subtitle file is empty or too large")
        }
        // 0 is libVLC's subtitle slave type (libvlc_media_slave_type_subtitle).
        player.addSlave(0, Uri.fromFile(file), true)
        true
    }.getOrDefault(false)

    /** MediaPlayer.Equalizer ABI varies by LibVLC version; use reflection for optional presets. */
    fun equalizerPreset(index: Int): Boolean = runCatching {
        val equalizerClass = Class.forName("org.videolan.libvlc.MediaPlayer\$Equalizer")
        val method = equalizerClass.getMethod("createFromPreset", Int::class.javaPrimitiveType)
        val equalizer = method.invoke(null, index)
        val apply = player.javaClass.methods.firstOrNull { it.name == "setEqualizer" && it.parameterTypes.size == 1 }
            ?: error("Equalizer unavailable")
        apply.invoke(player, equalizer)
        true
    }.getOrDefault(false)

    fun close() {
        if (closed) return
        closed = true
        if (durationMs > 0L) onProgress(if (completed) 0L else positionMs, durationMs)
        player.setEventListener(null)
        runCatching { player.stop() }
        runCatching { player.vlcVout.detachViews() }
        attachedSurface = null
        viewport = null
        player.release()
        vlc.release()
    }
}
