package com.aurora.media.player

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.aurora.media.data.FtpSettings
import com.aurora.media.data.MediaEntry
import com.aurora.media.ftp.FtpScanner

/**
 * Send a video FTP URI to an installed media player. The URI necessarily
 * contains FTP credentials so it is ONLY handed to the external application,
 * never written into logs or shown in the UI.
 *
 * Do not assume that arbitrary players support FTP or resume-position extras.
 */
object ExternalPlayerLauncher {
    enum class Result { VLC, CHOOSER, NONE }

    fun launch(context: Context, settings: FtpSettings, entry: MediaEntry, preferVlc: Boolean = true): Result {
        val uri = runCatching { Uri.parse(FtpScanner.mediaUrl(settings, entry.path)) }
            .getOrNull() ?: return Result.NONE

        // VLC for Android understands FTP network streams. Try both intent
        // variants because Android video/* URL filters vary by VLC release.
        if (preferVlc) {
            val vlcMimeIntent = makeViewIntent(uri, entry.displayTitle)
                .setPackage("org.videolan.vlc")
            if (tryStart(context, vlcMimeIntent)) return Result.VLC

            val vlcUriIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("org.videolan.vlc")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(Intent.EXTRA_TITLE, entry.displayTitle)
            }
            if (tryStart(context, vlcUriIntent)) return Result.VLC
        }

        // If VLC is absent, let Android offer other video players. Not all
        // third-party apps can open FTP URLs; failures remain recoverable.
        val generic = makeViewIntent(uri, entry.displayTitle)
        val chooser = Intent.createChooser(generic, "Play with another app")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (tryStart(context, chooser)) Result.CHOOSER else Result.NONE
    }

    private fun makeViewIntent(uri: Uri, title: String): Intent =
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "video/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(Intent.EXTRA_TITLE, title)
        }

    private fun tryStart(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent)
        true
    } catch (_: ActivityNotFoundException) {
        false
    } catch (_: SecurityException) {
        false
    } catch (_: IllegalArgumentException) {
        false
    }
}
