package com.aurora.media.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aurora.media.data.FtpSettings
import com.aurora.media.data.LibraryStore
import com.aurora.media.data.MediaEntry
import com.aurora.media.data.UpcomingMovie
import com.aurora.media.data.SecureSettings
import com.aurora.media.ftp.FtpScanner
import com.aurora.media.ftp.SeriesGrouping
import com.aurora.media.metadata.TmdbService
import com.aurora.media.metadata.RatingValue
import com.aurora.media.metadata.compareTmdbRatings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

sealed class Screen {
    data object Setup : Screen()
    data object Library : Screen()
    data class Details(val id: String) : Screen()
    data class Series(val key: String) : Screen()
    data class Player(val id: String, val fromBeginning: Boolean = false) : Screen()
}

data class AuroraState(
    val settings: FtpSettings = FtpSettings(),
    val screen: Screen = Screen.Setup,
    val entries: List<MediaEntry> = emptyList(),
    val busy: Boolean = false,
    val message: String = "",
    val isScanning: Boolean = false,
    val identified: Int = 0,
    val upcoming: List<UpcomingMovie> = emptyList(),
    val upcomingLoading: Boolean = false,
    val upcomingLoaded: Boolean = false,
    val upcomingError: String = "",
    val libraryTab: String = "All",
    val seriesDetailsLoading: Boolean = false
)

class AuroraViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = SecureSettings(application)
    private val library = LibraryStore(application)
    var state by mutableStateOf(AuroraState())
        private set

    init {
        val saved = preferences.load()
        state = state.copy(settings = saved, screen = if (saved.ready) Screen.Library else Screen.Setup)
        viewModelScope.launch {
            state = state.copy(entries = withContext(Dispatchers.IO) { library.read() })
            if (saved.ready) refresh()
        }
    }

    fun saveSetup(settings: FtpSettings) {
        if (settings.host.isBlank() || settings.username.isBlank() || settings.port !in 1..65535) {
            state = state.copy(message = "Enter a valid FTP host, port, and username.")
            return
        }
        viewModelScope.launch {
            state = state.copy(busy = true, message = "Checking FTP connection…")
            try {
                withContext(Dispatchers.IO) { FtpScanner.test(settings) }
                val previous = state.settings
                withContext(Dispatchers.IO) { preferences.save(settings) }
                val locationChanged = previous.host != settings.host || previous.port != settings.port ||
                    previous.directory != settings.directory || previous.username != settings.username
                if (locationChanged) withContext(Dispatchers.IO) { library.write(emptyList()) }
                state = state.copy(
                    settings = settings, entries = if (locationChanged) emptyList() else state.entries,
                    screen = Screen.Library, busy = false, message = "FTP connected. Scanning your library…"
                )
                refresh()
            } catch (error: Exception) {
                state = state.copy(busy = false, message = "Connection failed: ${error.message ?: "Unknown FTP error"}")
            }
        }
    }

    fun refresh() {
        if (state.isScanning || !state.settings.ready) return
        val settings = state.settings
        viewModelScope.launch {
            state = state.copy(isScanning = true, message = "Finding videos on your FTP server…", identified = 0)
            try {
                val scanned = withContext(Dispatchers.IO) { FtpScanner.scan(settings) }
                val previous = state.entries.associateBy { it.path }
                var merged = scanned.map { current ->
                    previous[current.path]?.takeIf { it.fileName == current.fileName && it.bytes == current.bytes }
                        ?.let { cached ->
                            // Always re-parse titles after a parser update; do not retain stale TMDb matches.
                            if (cached.title == current.title && cached.year == current.year &&
                                (!current.isEpisode || cached.metadataMatchVersion >= 3)) {
                                current.copy(poster = cached.poster, backdrop = cached.backdrop,
                                    description = cached.description, remoteId = cached.remoteId,
                                    genreIds = cached.genreIds, mediaType = cached.mediaType,
                                    tmdbRating = cached.tmdbRating,
                                    tmdbVoteCount = cached.tmdbVoteCount,
                                    tmdbRatingFetched = cached.tmdbRatingFetched,
                                    metadataMatchVersion = cached.metadataMatchVersion,
                                    episodeTitle = cached.episodeTitle, episodeStill = cached.episodeStill,
                                    episodeOverview = cached.episodeOverview,
                                    episodeAirDate = cached.episodeAirDate,
                                    episodeMetadataFetched = cached.episodeMetadataFetched,
                                    lastPositionMs = cached.lastPositionMs, durationMs = cached.durationMs)
                            } else {
                                current.copy(lastPositionMs = cached.lastPositionMs, durationMs = cached.durationMs)
                            }
                        } ?: current
                }
                state = state.copy(entries = merged, message = "Found ${merged.size} videos", isScanning = false)
                withContext(Dispatchers.IO) { library.write(merged) }
                if (settings.tmdbToken.isNotBlank()) {
                    val matcher = TmdbService(settings.tmdbToken)
                    var firstMetadataError: String? = null
                    // One TMDb series lookup per show, not one per episode. Only
                    // verified exact-title matches get shared across the season.
                    val movies = merged.filterNot { it.isEpisode }.filter {
                        it.poster.isNullOrBlank() || (it.remoteId != null &&
                            (it.genreIds.isEmpty() || !it.tmdbRatingFetched))
                    }
                    val seriesRepresentatives = merged.filter { it.isEpisode }
                        .groupBy { SeriesGrouping.key(it.seriesName) }.values.mapNotNull { group ->
                            group.firstOrNull { it.metadataMatchVersion < 3 }
                        }
                    for (item in movies + seriesRepresentatives) {
                        val result = withContext(Dispatchers.IO) { runCatching { matcher.enrich(item) } }
                        if (result.isFailure) {
                            firstMetadataError = result.exceptionOrNull()?.message ?: "Unknown metadata error"
                            break
                        }
                        val updated = result.getOrNull() ?: continue
                        if (updated != item) {
                            merged = merged.map { entry ->
                                if (item.isEpisode && entry.isEpisode &&
                                    SeriesGrouping.key(entry.seriesName) == SeriesGrouping.key(item.seriesName)) {
                                    entry.copy(poster = updated.poster, backdrop = updated.backdrop,
                                        description = updated.description, remoteId = updated.remoteId,
                                        genreIds = updated.genreIds, mediaType = "tv",
                                        tmdbRating = updated.tmdbRating,
                                        tmdbVoteCount = updated.tmdbVoteCount,
                                        tmdbRatingFetched = updated.tmdbRatingFetched,
                                        metadataMatchVersion = updated.metadataMatchVersion,
                                        // A changed series TMDb ID invalidates previously cached episode stills.
                                        episodeTitle = if (entry.remoteId == updated.remoteId) entry.episodeTitle else null,
                                        episodeStill = if (entry.remoteId == updated.remoteId) entry.episodeStill else null,
                                        episodeOverview = if (entry.remoteId == updated.remoteId) entry.episodeOverview else null,
                                        episodeAirDate = if (entry.remoteId == updated.remoteId) entry.episodeAirDate else null,
                                        episodeMetadataFetched = entry.remoteId == updated.remoteId && entry.episodeMetadataFetched)
                                } else if (entry.id == item.id) updated else entry
                            }
                            state = state.copy(entries = merged, identified = state.identified +
                                if (updated.poster != null) 1 else 0)
                            withContext(Dispatchers.IO) { library.write(merged) }
                        }
                    }
                    state = state.copy(message = firstMetadataError?.let { "Poster lookup failed: $it" }
                        ?: "Library ready • ${merged.size} videos • ${state.identified} posters matched")
                } else {
                    state = state.copy(message = "Library ready • ${merged.size} videos. Add a TMDb key for posters.")
                }
            } catch (error: Exception) {
                // Keep offline cache visible on FTP failure.
                state = state.copy(isScanning = false, message = "FTP unavailable: ${error.message ?: "Connection error"}. Cached library remains visible.")
            }
        }
    }

    fun loadUpcoming(force: Boolean = false) {
        if (state.upcomingLoading || (state.upcomingLoaded && !force)) return
        val token = state.settings.tmdbToken
        if (token.isBlank()) {
            state = state.copy(upcomingError = "TMDb API key missing. Add it in Settings.")
            return
        }
        viewModelScope.launch {
            state = state.copy(upcomingLoading = true, upcomingError = "")
            try {
                val movies = withContext(Dispatchers.IO) { TmdbService(token).upcomingTheatrical("IN") }
                state = state.copy(upcoming = movies, upcomingLoading = false, upcomingLoaded = true,
                    upcomingError = if (movies.isEmpty()) "No upcoming theatrical releases returned for India." else "")
            } catch (error: Exception) {
                state = state.copy(upcomingLoading = false, upcomingError =
                    "Could not load upcoming films: ${error.message ?: "Network error"}")
            }
        }
    }

    fun navigate(screen: Screen) { state = state.copy(screen = screen, message = "") }
    fun selectLibraryTab(tab: String) {
        state = state.copy(libraryTab = if (tab in listOf("All", "Movies", "TV Shows", "Upcoming")) tab else "All")
    }

    fun openSeries(key: String) {
        selectLibraryTab("TV Shows")
        navigate(Screen.Series(key))
        loadSeriesEpisodeDetails(key)
    }

    private fun loadSeriesEpisodeDetails(key: String) {
        val candidates = state.entries.filter { it.isEpisode && SeriesGrouping.key(it.seriesName) == key }
        val remoteId = candidates.firstOrNull()?.remoteId ?: return
        val token = state.settings.tmdbToken
        if (token.isBlank() || state.seriesDetailsLoading) return
        val seasons = candidates.filterNot { it.episodeMetadataFetched }
            .mapNotNull { SeriesGrouping.numbers(it.episodeCode)?.season }.distinct()
        if (seasons.isEmpty()) return
        viewModelScope.launch {
            state = state.copy(seriesDetailsLoading = true)
            try {
                val matcher = TmdbService(token)
                for (season in seasons) {
                    val episodeMetadata = withContext(Dispatchers.IO) {
                        runCatching { matcher.tvSeasonDetails(remoteId, season) }.getOrNull()
                    } ?: continue
                    val updated = state.entries.map { entry ->
                        val number = SeriesGrouping.numbers(entry.episodeCode)
                        if (!entry.isEpisode || SeriesGrouping.key(entry.seriesName) != key ||
                            number?.season != season) entry else {
                            val detail = episodeMetadata[number.episode]
                            entry.copy(episodeTitle = detail?.name,
                                episodeStill = detail?.still, episodeOverview = detail?.overview,
                                episodeAirDate = detail?.airDate, episodeMetadataFetched = true)
                        }
                    }
                    state = state.copy(entries = updated)
                    withContext(Dispatchers.IO) { library.write(updated) }
                }
            } catch (_: Exception) {
                // Metadata is optional. FTP episodes must remain playable even
                // when TMDb is unavailable or the local metadata cache fails.
            } finally {
                state = state.copy(seriesDetailsLoading = false)
            }
        }
    }
    fun select(id: String) = navigate(Screen.Details(id))
    fun play(id: String, fromBeginning: Boolean = false) {
        // Clearing the progress is intentional and makes Start from Beginning persistent.
        if (fromBeginning) updateProgress(id, 0L, state.entries.firstOrNull { it.id == id }?.durationMs ?: 0L)
        navigate(Screen.Player(id, fromBeginning))
    }

    /** Recommend only FTP titles; movie suggestions are ranked by TMDb rating. */
    fun recommendationsFor(id: String, limit: Int = 8): List<MediaEntry> {
        val selected = state.entries.firstOrNull { it.id == id } ?: return emptyList()
        fun relevance(other: MediaEntry): Int {
            var points = 0
            if (selected.isEpisode && other.isEpisode && selected.seriesName == other.seriesName) {
                points += 200
                if (selected.episodeCode != null && other.episodeCode != null &&
                    other.episodeCode > selected.episodeCode) points += 120
            }
            points += selected.genreIds.intersect(other.genreIds.toSet()).size * 60
            if (other.isEpisode == selected.isEpisode) points += 16
            if (selected.year != null && other.year != null) {
                points += (10 - kotlin.math.abs(selected.year - other.year)).coerceAtLeast(0)
            }
            if (other.poster != null) points += 8
            if (other.lastPositionMs == 0L) points += 5
            return points
        }
        return state.entries.asSequence()
            .filter { it.id != id && (selected.isEpisode || !it.isEpisode) }
            .sortedWith { a, b ->
                // Keep episode sequence recommendations relevant. Movies: highest
                // TMDb average first; votes, similarity and title break ties.
                val rated = if (selected.isEpisode) 0 else compareTmdbRatings(
                    RatingValue(a.tmdbRating, a.tmdbVoteCount),
                    RatingValue(b.tmdbRating, b.tmdbVoteCount)
                )
                if (rated != 0) rated
                else {
                    val relevant = relevance(b).compareTo(relevance(a))
                    if (relevant != 0) relevant
                    else a.displayTitle.compareTo(b.displayTitle, ignoreCase = true)
                }
            }
            .take(limit)
            .toList()
    }

    fun updateProgress(id: String, position: Long, duration: Long) {
        val old = state.entries.firstOrNull { it.id == id } ?: return
        if (kotlin.math.abs(old.lastPositionMs - position) < 5_000L && duration == old.durationMs) return
        val next = state.entries.map { if (it.id == id) it.copy(lastPositionMs = position, durationMs = duration) else it }
        state = state.copy(entries = next)
        viewModelScope.launch(Dispatchers.IO) { library.write(next) }
    }
    fun exitPlayer() {
        val id = (state.screen as? Screen.Player)?.id ?: return
        val entry = state.entries.firstOrNull { it.id == id }
        if (entry?.isEpisode == true) openSeries(SeriesGrouping.key(entry.seriesName))
        else navigate(Screen.Details(id))
    }
}
