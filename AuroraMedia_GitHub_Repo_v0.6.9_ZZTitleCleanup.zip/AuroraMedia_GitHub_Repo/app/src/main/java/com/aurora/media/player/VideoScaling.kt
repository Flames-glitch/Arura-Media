package com.aurora.media.player

import kotlin.math.roundToInt

/** Exact pixel bounds for a source-aspect-preserving Android video surface. */
data class VideoBounds(val width: Int, val height: Int)

object VideoScaling {
    /** LibVLC video scale (0 means automatic Best Fit). LibVLC renders into a
     * full-viewport video surface and clips equally at opposing edges when
     * scaled larger. The sample-aspect ratio keeps non-square-pixel sources
     * proportional. A missing video layout always falls back to Fit. */
    fun vlcScale(
        viewportWidth: Int,
        viewportHeight: Int,
        videoWidth: Int,
        videoHeight: Int,
        sarNum: Int,
        sarDen: Int,
        zoomToFill: Boolean
    ): Float {
        if (!zoomToFill || viewportWidth <= 0 || viewportHeight <= 0 ||
            videoWidth <= 0 || videoHeight <= 0) return 0f
        val pixelAspect = sarNum.coerceAtLeast(1).toFloat() / sarDen.coerceAtLeast(1)
        val displayVideoWidth = videoWidth * pixelAspect
        return maxOf(
            viewportWidth / displayVideoWidth,
            viewportHeight.toFloat() / videoHeight
        ).coerceAtLeast(0.001f)
    }
    /** Uniform visual zoom applied to a full-screen SurfaceView.
     * Fit is ALWAYS 1.0. Fill enlarges the letterboxed output just enough to
     * eliminate bars without altering the media's pixel aspect ratio. */
    fun zoomFactor(
        viewportWidth: Int,
        viewportHeight: Int,
        sourceAspectRatio: Float,
        zoomToFill: Boolean
    ): Float {
        if (!zoomToFill || viewportWidth <= 0 || viewportHeight <= 0) return 1f
        val fit = compute(viewportWidth, viewportHeight, sourceAspectRatio, false)
        return maxOf(
            viewportWidth.toFloat() / fit.width,
            viewportHeight.toFloat() / fit.height
        ).coerceAtLeast(1f)
    }

    fun compute(
        viewportWidth: Int,
        viewportHeight: Int,
        sourceAspectRatio: Float,
        zoomToFill: Boolean
    ): VideoBounds {
        require(viewportWidth > 0 && viewportHeight > 0)
        val w = viewportWidth.toFloat()
        val h = viewportHeight.toFloat()
        val ratio = sourceAspectRatio.takeIf { it.isFinite() && it > 0f } ?: w / h
        val viewportRatio = w / h
        return if ((!zoomToFill && ratio >= viewportRatio) || (zoomToFill && ratio < viewportRatio)) {
            VideoBounds(viewportWidth, (w / ratio).roundToInt().coerceAtLeast(1))
        } else {
            VideoBounds((h * ratio).roundToInt().coerceAtLeast(1), viewportHeight)
        }
    }
}
