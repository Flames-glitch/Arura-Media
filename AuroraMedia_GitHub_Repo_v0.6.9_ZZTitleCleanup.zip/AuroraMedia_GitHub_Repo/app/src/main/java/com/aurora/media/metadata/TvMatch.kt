package com.aurora.media.metadata

import java.text.Normalizer
import java.util.Locale

/** Do not give a show an unrelated poster merely because it is TMDb's top hit. */
object TvMatch {
    fun normalized(name: String): String = Normalizer.normalize(name, Normalizer.Form.NFD)
        .replace(Regex("""\p{M}+"""), "")
        .lowercase(Locale.ROOT)
        .replace('&', ' ')
        .replace(Regex("""[^a-z0-9]+"""), " ")
        .replace(Regex("""\s+"""), " ").trim()

    fun exact(query: String, result: String): Boolean =
        normalized(query).isNotBlank() && normalized(query) == normalized(result)
}
