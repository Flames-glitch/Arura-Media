plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Signing credentials are read only from CI environment variables; never committed.
// Without them, Android Studio can still build locally with its normal debug key.
val auroraSigningFile = System.getenv("AURORA_SIGNING_KEYSTORE")
val auroraSigningPassword = System.getenv("AURORA_SIGNING_PASSWORD")
val usePermanentSigning = !auroraSigningFile.isNullOrBlank() && !auroraSigningPassword.isNullOrBlank()


android {
    namespace = "com.aurora.media"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aurora.media"
        minSdk = 26
        targetSdk = 35
        versionCode = 23
        versionName = "0.6.9"
    }

    signingConfigs {
        if (usePermanentSigning) {
            create("auroraPersistent") {
                storeFile = file(auroraSigningFile!!)
                storePassword = auroraSigningPassword
                keyAlias = "aurora-media"
                keyPassword = auroraSigningPassword
                storeType = "PKCS12"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            if (usePermanentSigning) signingConfig = signingConfigs.getByName("auroraPersistent")
        }
        getByName("release") {
            isMinifyEnabled = false
            if (usePermanentSigning) signingConfig = signingConfigs.getByName("auroraPersistent")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        jniLibs.useLegacyPackaging = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("commons-net:commons-net:3.11.1")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("org.videolan.android:libvlc-all:3.5.1")
    testImplementation("junit:junit:4.13.2")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
