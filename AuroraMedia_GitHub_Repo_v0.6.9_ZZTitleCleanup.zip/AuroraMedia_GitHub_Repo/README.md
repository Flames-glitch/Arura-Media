# Aurora Media Android V0.6.8 — full-viewport rendering recovery

This is a standalone FTP streaming client for Android. The folder offloader is intentionally disabled.

## Player changes

- A single LibVLC session is preserved while entering/exiting Android PiP or switching apps; the video SurfaceView is rebound after surface recreation rather than restarting FTP playback from zero.
- The video is laid out within the measured current viewport (`FrameLayout`), not with the stale `SurfaceHolder` buffer or guessed phone dimensions. The parent clips the video surface when zoomed.
- **Fit (default):** original source proportions, entire frame visible; for 16:9 on a 20:9 landscape screen, black bars appear at the sides.
- **Fill:** zoom until the video covers the entire viewport; crop the excess while preserving the original source aspect ratio (no forced stretch).
- **Double tap:** toggle Fit / Fill. **Two-finger pinch:** pinch outward for Fill, inward for Fit. One-finger left/right swipe continues seeking; vertical left/right continue to set screen brightness/volume.
- Video dimensions are read using LibVLC's video layout callback, including pixel aspect ratio, and reapplied when PiP/fullscreen bounds change.
- LibVLC 3.5.1 retains native decoding and MediaCodec hardware acceleration with software fallback, and an increased 3000 ms network buffer for FTP. H.264/HEVC 4K decoding is available where the Android device codec, processing power, and network throughput support it. 4K/AV1 and other combinations are **not guaranteed** by the app.

## Building

Upload this ZIP to the root of the GitHub repository and retain its top-level `AuroraMedia_GitHub_Repo` directory. The build workflow extracts the newest `AuroraMedia_GitHub_Repo_v*.zip`, runs source checks and JVM tests, then builds `:app:assembleDebug` with Java 17 and Android SDK 35.

**Testing:** PiP expand and dismiss, phone calls/app switching, Fit/Fill double tap and pinch, 16:9/21:9/4:3 content, H.264/HEVC streams up to 4K on your actual phone. Inspect `adb logcat` if a specific file fails or the app crashes. The ZIP is not a prebuilt APK.


## v0.6.7: Optional FFmpeg software video decoding

In Player → More (⋮) → Player settings → Video decoder, select **Software (FFmpeg)** if your phone's hardware decoder shows blocky/corrupted frames. **Auto (hardware preferred)** remains the default. The mode persists locally, and switching codecs attempts to keep the current playback position. LibVLC 3.5.1 already bundles its own software decoding; this does not install MX Player codecs. 4K software decoding may exceed the device's CPU performance, and decoder switching does not itself fix an Android SurfaceView/PiP lifecycle bug.


## Version 0.6.7.2 — approved compact player layout

The Android player now places the seek bar, elapsed/total timestamps, and
five evenly spaced icon controls at the bottom over a transparent gradient.
The Play/Pause control is a compact (48 dp) dark translucent circle,
centered in the bottom row rather than floating over the movie.
The other slots are combined Audio/Subtitles, −10 seconds, +10 seconds,
and Fit/Fill, respectively. The top row keeps Back, movie title, PiP and
settings. No Cast action. Existing brightness, volume, horizontal seek,
double-tap Fit/Fill, pinch, and VLC decoder modes are preserved.


## Version 0.6.8 — PiP tiny frame and missing video recovery

The LibVLC-bound SurfaceView now always occupies the entire playback FrameLayout
instead of shrinking its *physical Android surface* to match the video dimensions.
LibVLC receives the **actual viewport size**, and gets a new size only when the
viewport changes (or the Vout is genuinely rebound). This avoids stale PiP
width/height feedback loops. Best Fit is managed by VLC; Fill uses a uniform
LibVLC nonzero scaling to center-crop without stretching the original source. Entering
PiP temporarily returns to Fit and expanding restores your selected mode.

App switching no longer needlessly detaches/reattaches a valid SurfaceView.
If the OS has actually destroyed the SurfaceHolder, LibVLC rebinds to it.
A manual recovery action is available under **⋮ → Player settings → Repair
black/tiny video**, which rebinds the output without reopening the FTP media.

**Important:** Neither hardware nor FFmpeg software decoding fixes a corrupted
source file, insufficient FTP throughput, or a 10-bit/HDR/Dolby Vision tone-
mapping issue. Compare the exact movie at the exact timestamp in the official
VLC Android app over the same FTP source before blaming the codec. This patch
has not been tested on the user's actual phone and is not a guaranteed fix.


## V0.6.9 — External player fallback

Aurora Media still uses built-in LibVLC by default. On a reported fatal
LibVLC playback error, it attempts to open the same FTP video in the installed
**VLC for Android**. When VLC cannot be launched, Android displays a player
chooser. The player settings menu also has a manual **Open video in VLC / another
player** option for corrupted, dark, audio-only, or tiny video output that
LibVLC does not report as a fatal error. The handoff is attempted only once per
movie session, preventing repeated app-launch loops.

**Privacy:** Opening FTP media externally necessarily sends the FTP URL, which
contains a username and password, to the chosen external player. Install only
media apps you trust. The app does not log the URL. Not all external players
support FTP URLs, and the external player's starting time or quality cannot be
guaranteed. Aurora checkpoints its own playback position for later resumption.


## V0.6.9 — TV series library refinement

- TV Shows now shows **one card per series**, instead of duplicating series posters for each episode.
- Select the series to access **Season 1 / Season 2 / ...** tabs and episodes in episode order.
- Episode rows show an actual TMDb episode still, name, air date and synopsis when available; otherwise a neutral thumbnail and FTP episode number.
- TMDb series search uses strict normalized-title matching: *The Court* must not pick *The People's Court*. Legacy incorrect episode artwork is invalidated when the FTP library is refreshed.
- Movie Home/Upcoming/FTP streaming, external-player fallback, and VLC decoder/gestures remain unchanged.
- The app still identifies as **0.6.9**; Android `versionCode` is incremented for in-place upgrades when the signing certificate matches.
- After installation, use the header refresh icon once to re-evaluate old incorrect series artwork.

Note: An episode or series unavailable in TMDb, or whose title differs substantially from its TMDb name, deliberately shows an appropriate fallback rather than an unrelated poster.
