"""Aurora Media static checks; no Android SDK required. Not a substitute for Gradle compile/device testing."""
from pathlib import Path
from xml.etree import ElementTree
import re

root = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/aurora/media/MainActivity.kt',
    'app/src/main/java/com/aurora/media/player/VlcSession.kt',
    'app/src/main/java/com/aurora/media/player/PlayerScreen.kt',
    'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt',
    'app/src/main/java/com/aurora/media/metadata/TmdbService.kt',
]
for f in required:
    if not (root / f).is_file():
        raise SystemExit(f'Missing essential source file: {f}')
manifest = ElementTree.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
android = '{http://schemas.android.com/apk/res/android}'
permissions = [x.attrib.get(android + 'name') for x in manifest.findall('uses-permission')]
if 'android.permission.INTERNET' not in permissions:
    raise SystemExit('INTERNET permission missing')
app = manifest.find('application')
if app is None or not app.attrib.get(android+'label') == 'Aurora Media':
    raise SystemExit('Aurora Media app label missing')
source_dir = root / 'app/src/main/java'
source = '\n'.join(f.read_text() for f in source_dir.rglob('*.kt'))
if 'Media.Slave.Type.Subtitle' in source:
    raise SystemExit('Unsupported Media.Slave.Type.Subtitle reference')
if re.search(r'fun\s+setSpeed\s*\(', source):
    raise SystemExit('Potential Kotlin property setter clash: setSpeed')
if 'session::setSpeed' in source:
    raise SystemExit('Stale playback speed method reference')
if 'session::updateSpeed' not in source:
    raise SystemExit('Missing playback speed UI callback')
if 'fun updateSpeed(value: Float)' not in source:
    raise SystemExit('Missing playback speed method')
ftp = (root / 'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt').read_text()
if 'FTP.BINARY_FILE_TYPE' not in ftp or 'enterLocalPassiveMode()' not in ftp:
    raise SystemExit('FTP binary/passive mode missing')
if 'ftp://' not in ftp:
    raise SystemExit('FTP stream URL missing')
if 'sftp://' in source.lower():
    raise SystemExit('SFTP included unexpectedly')
build = (root / 'app/build.gradle.kts').read_text()
if 'applicationId = "com.aurora.media"' not in build:
    raise SystemExit('Wrong application ID')
if 'compileSdk = 35' not in build:
    raise SystemExit('Android SDK 35 mismatch')
if 'org.videolan.android:libvlc-all:3.5.1' not in build:
    raise SystemExit('Expected VLC dependency missing')
print('PASS: source structure, XML, FTP-only configuration, LibVLC references, Gradle constants')
print(f'Source files: {len(list(source_dir.rglob("*.kt")))} Kotlin files')

# V0.6.2 regression gates: offloader deliberately removed; FTP playback untouched.
ui = (root / 'app/src/main/java/com/aurora/media/ui/AuroraApp.kt').read_text()
vm = (root / 'app/src/main/java/com/aurora/media/ui/AuroraViewModel.kt').read_text()
player = (root / 'app/src/main/java/com/aurora/media/player/PlayerScreen.kt').read_text()
session = (root / 'app/src/main/java/com/aurora/media/player/VlcSession.kt').read_text()
activity = (root / 'app/src/main/java/com/aurora/media/MainActivity.kt').read_text()
cleaner = (root / 'app/src/main/java/com/aurora/media/ftp/FilenameCleaner.kt').read_text()
properties = (root / 'gradle.properties').read_text()
app_source = (root / 'app/src/main/java/com/aurora/media/AuroraApplication.kt').read_text()
legacy_worker = (root / 'app/src/main/java/com/aurora/media/offload/OffloadWorker.kt').read_text()
rotation = (root / 'app/src/main/java/com/aurora/media/ui/SpotlightRotation.kt').read_text()
manifest_text = (root / 'app/src/main/AndroidManifest.xml').read_text()
regressions = {
    "AndroidX enabled": "android.useAndroidX=true" in properties,
    "Old malformed remote constant absent": "KEYCODE_HEADSETPHOOK" not in source,
    "Previous speed setter clash absent": "fun setSpeed(" not in source,
    "Previous LibVLC subtitle enum absent": "Media.Slave.Type.Subtitle" not in source,
    "Original FTP stream retained": "ftp://" in ftp and "FtpScanner.mediaUrl" in session,
    "Start from Beginning retained": "Start from Beginning" in ui and "fromBeginning" in vm,
    "Playback suggestions retained": "What to watch next" in player and "recommendationsFor" in vm,
    "Screen awake during playback": "FLAG_KEEP_SCREEN_ON" in player,
    "PiP dismissal pauses playback without resetting position": "onPictureInPictureModeChanged" in activity and "pauseForBackground(autoResume = !lastPiPExitPending)" in activity,
    "Delayed buffering spinner": "bufferingCheck" in session and "> 3000L" in session,
    "Filename watermark cleanup": "websitePrefix" in cleaner and "solar" in cleaner,
    "Cached movie title refresh": "cached.title == current.title" in vm,
    "Featured carousel has timer": "delay(8_000L)" in ui,
    "Featured carousel traverses list": "nextSpotlightIndex" in ui and "previousSpotlightIndex" in ui,
    "Featured uses actual FTP entries": "val movies = entries.filterNot" in ui,
    "Single-item rotation safe": "if (count <= 1) 0" in rotation,
    "FTP upload button removed": "CloudUpload" not in ui and "onOffload" not in ui,
    "FTP upload screen removed": "Screen.Offload" not in source,
    "FTP upload engine removed": not (root / 'app/src/main/java/com/aurora/media/offload/OffloadEngine.kt').exists(),
    "Old queued moves cancelled": "cancelUniqueWork(\"aurora_phone_offload_now\")" in app_source and "cancelUniqueWork(\"aurora_phone_offload_daily\")" in app_source,
    "Old jobs cannot run uploads": "override suspend fun doWork(): Result = Result.failure()" in legacy_worker,
    "Foreground upload service not requested": "FOREGROUND_SERVICE_DATA_SYNC" not in manifest_text,
    "App version code incremented": "versionCode = 22" in build and 'versionName = "0.6.9"' in build,
}
for label, ok in regressions.items():
    if not ok: raise SystemExit("Regression detected: " + label)
print(f"PASS: {len(regressions)} V0.6.2 rotation/player/safe-retirement regression checks")

# V0.6.3 preflight: preset FTP connection, editable overrides, India-specific TMDb discovery.
settings = (root / 'app/src/main/java/com/aurora/media/data/SecureSettings.kt').read_text()
metadata = (root / 'app/src/main/java/com/aurora/media/metadata/TmdbService.kt').read_text()
models = (root / 'app/src/main/java/com/aurora/media/data/Models.kt').read_text()
checks = {
    "FTP host prefilled": 'preferences.getString("host", "192.168.1.254")' in settings,
    "FTP username prefilled": 'preferences.getString("username", "userAdmin")' in settings,
    "FTP password first-run preset": 'preferences.contains("password")' in settings and 'else "tsbb@123"' in settings,
    "FTP directory first-run preset": 'preferences.getString("directory", "/usb1_1/movies")' in settings,
    "FTP fields editable": all(f'{{ {field} = it }}' in ui for field in ["host", "username", "password", "directory"]),
    "Encrypted later-saved FTP password": '.putString("password", encrypt(settings.password))' in settings,
    "Existing settings prioritized": 'preferences.contains("password")' in settings and 'preferences.getString("host"' in settings,
    "TMDb default credential for upcoming films": 'tmdbToken = decrypt' in settings and '.ifBlank {' in settings,
    "TMDb theatre discover endpoint": 'discover/movie' in metadata,
    "India theatre region": 'upcomingTheatrical("IN")' in vm and 'with_release_type=2%7C3' in metadata,
    "Upcoming tab": '"Upcoming"' in ui and 'UpcomingTheatresSection' in ui,
    "Upcoming items not FTP playable": 'data class UpcomingMovie' in models and 'Coming to theatres • Not in your FTP library' in ui,
    "Upcoming refresh and error handling": 'onRefresh = { onLoadUpcoming(true) }' in ui and 'upcomingError' in vm,
}
for label, ok in checks.items():
    if not ok: raise SystemExit("V0.6.3 regression detected: " + label)
print(f'PASS: {len(checks)} V0.6.3 FTP preset and theatres checks')

# V0.6.3 premium-player and trailer regression gates
trailer = (root / 'app/src/main/java/com/aurora/media/metadata/TrailerSelection.kt').read_text()
new_checks = {
    'Real TMDb trailer video endpoint': '/videos?language=en-US' in metadata,
    'YouTube trailer validated before URL creation': 'selectBestYouTubeKey(candidates)' in metadata and '[A-Za-z0-9_-]{11}' in trailer,
    'YouTube search when video metadata absent': 'youtube.com/results?search_query=' in ui,
    'Trailer fetched off UI thread': 'withContext(Dispatchers.IO)' in ui,
    'Upcoming tab retains theatre movies': 'UpcomingTheatresSection' in ui and 'UpcomingMovie' in ui,
    'Trailer does not add FTP entries': 'UpcomingMovie' in ui and 'onSelect = { selectedUpcoming = it }' in ui,
    'Swipe seeking': 'SwipeMode.SEEK' in player and 'session.seek(gestureSeek)' in player,
    'Left brightness gesture': 'SwipeMode.BRIGHTNESS' in player and 'params.screenBrightness = level' in player,
    'Right volume gesture': 'SwipeMode.VOLUME' in player and 'setStreamVolume' in player,
    'VLC-style compact controls': 'Icons.Default.Replay10' in player and 'Icons.Default.Forward10' in player,
    'Combined audio and subtitle picker': '"tracks" -> AlertDialog' in player and 'trackTab' in player,
    'PiP retained': 'enterPlayerPiP' in player and 'pauseForBackground' in activity,
    'No cast control in player': 'Cast' not in player and 'cast' not in player.lower(),
    'Player uses transparent gradient overlays': 'Brush.verticalGradient' in player,
    'Player controls auto-hide': 'delay(5_000L)' in player,
    'App version incremented for home redesign': 'versionName = "0.6.9"' in build,
    'Video surface rebound on AndroidView update': 'session.attach(it, parent)' in player,
    'Background playback pauses not stops': 'pauseForBackground' in activity and 'playerSession?.stopPlayback()' not in activity,
    'Small Play/Pause control anchored in bottom row': 'modifier = Modifier.size(48.dp)' in player and 'playback buttons remain together' in player.lower() and 'Box(Modifier.weight(1f), contentAlignment = Alignment.Center)' in player,
    'Retain video position on return': 'resumeAfterBackground' in activity and 'resumeAfterSuspension' in session,

}
for label, ok in new_checks.items():
    if not ok: raise SystemExit('Premium player/trailer regression detected: ' + label)
print(f'PASS: {len(new_checks)} premium UI, gesture, PiP, trailer and player checks')

# V0.6.4 rating-based recommendations and pagination dots.
rating_source = (root / 'app/src/main/java/com/aurora/media/metadata/RatingOrder.kt').read_text()
rating_checks = {
    "TMDb rating persisted": 'tmdbRatingFetched' in models and 'put("tmdbRating"' in models,
    "TMDb rating collected": 'vote_average' in metadata and 'vote_count' in metadata,
    "Cached matches backfilled": '!it.tmdbRatingFetched' in vm,
    "Recommendations rank by rating": 'compareTmdbRatings' in vm,
    "Homepage featured sorted by rating": 'compareTmdbRatings' in ui,
    "Unrated movies placed last": 'if (left == null) return 1' in rating_source,
    "Carousel uses dots": 'repeat(count) { position ->' in ui and 'Text("${index + 1} / $count"' not in ui,
}
for label, ok in rating_checks.items():
    if not ok: raise SystemExit("Rating update regression detected: " + label)
print(f"PASS: {len(rating_checks)} rating and carousel-dot regression checks")

# V0.6.6 HOME DISCOVERY REGRESSION GATES
app_layout = (root / 'app/src/main/java/com/aurora/media/ui/AuroraApp.kt').read_text()
layout_checks = {
    "Only four bottom navigation destinations": 'listOf("All", "Movies", "TV Shows", "Upcoming")' in app_layout,
    "Continue navigation destination removed": '"Continue" -> Icons.Default.PlayCircle' not in app_layout,
    "Continue Watching remains on Home": 'if (recent.isNotEmpty())' in app_layout and 'Text("Continue Watching"' in app_layout,
    "Home has recommended FTP movies": 'Text("Suggested Movies"' in app_layout and 'rowItems(suggestedMovies' in app_layout,
    "Picked for You moved to Movies": 'if (category == "Movies")' in app_layout and 'Text("Picked for You"' in app_layout,
    "Explore Collection moved to Movies": 'Text("Explore Your Collection"' in app_layout,
    "Full collection grid hidden from Home": 'if (category == "Movies" || category == "TV Shows") {' in app_layout,
    "Upcoming separately accessible": 'if (category == "Upcoming")' in app_layout,
    "No theatre promo on Home": 'Text("Coming to Theatres"' not in app_layout,
    "Search only in library tabs": 'Search and full browsing belong to Movies and TV Shows, not Home.' in app_layout,
    "App package unchanged": 'applicationId = "com.aurora.media"' in build,
    "Android version increased": 'versionCode = 22' in build and 'versionName = "0.6.9"' in build,
}
for label, ok in layout_checks.items():
    if not ok: raise SystemExit('Home layout regression detected: ' + label)
print(f'PASS: {len(layout_checks)} V0.6.6 Home/Movies navigation and layout checks')

# V0.6.6 geometry and PiP regression checks.
scaling = (root / 'app/src/main/java/com/aurora/media/player/VideoScaling.kt').read_text()
scaling_test = (root / 'app/src/test/java/com/aurora/media/player/VideoScalingTest.kt').read_text()
video_checks = {
    'Current viewport width/height in pixels': 'updateVideoWindow(right - left, bottom - top)' in player,
    'No SurfaceHolder buffer-driven sizing': 'session.updateVideoWindow(width, height)' not in player,
    'LibVLC source aspect callback': 'OnNewVideoLayoutListener' in session and 'visibleWidth' in session and 'sarNum' in session,
    'Video surface is clipped and centered': 'clipChildren = true' in player and 'Gravity.CENTER' in player,
    'Fit/Fill computed preserving source ratio': 'VideoScaling.vlcScale(' in session and 'zoomToFill' in scaling,
    'No aspect-ratio stretching': 'player.aspectRatio = null' in session and '"${videoWindowWidth}:${videoWindowHeight}"' not in session,
    'Gesture double-tap toggles Fit/Fill': 'onDoubleTap' in player and 'session.toggleAspect()' in player,
    'Pinch controls Fit/Fill': 'calculateZoom()' in player and 'cumulativeZoom' in player,
    'Existing volume gesture retained': 'SwipeMode.VOLUME' in player and 'setStreamVolume' in player,
    'Existing brightness gesture retained': 'SwipeMode.BRIGHTNESS' in player and 'params.screenBrightness = level' in player,
    'Existing seek gesture retained': 'SwipeMode.SEEK' in player and 'session.seek(gestureSeek)' in player,
    'Fullscreen restores surface without restarting media': 'restoreVideoOutput()' in session and 'if (started || closed || needsVideoRebind) return' in session,
    'No media restarted on PiP resize': 'private fun layoutVideoSurface()' in session and 'player.play()' not in session.split('private fun layoutVideoSurface()')[1].split('fun updateVideoWindow')[0],
    'Hardware and software decoder choices': 'media.setHWDecoderEnabled(DecoderChoice.enableHardware(decoderMode), false)' in session,
    '4K video scaling tests': 'sixteenByNineOnWidePhone' in scaling_test and 'portraitAndPipResize' in scaling_test,
    'Java 17 action is not deprecated v4': 'actions/setup-java@v5' in (root / '.github/workflows/build-apk.yml').read_text(),
    'Build version incremented': 'versionCode = 22' in build and 'versionName = "0.6.9"' in build,
}
for label, ok in video_checks.items():
    if not ok: raise SystemExit('V0.6.6 regression detected: ' + label)
print(f'PASS: {len(video_checks)} V0.6.6 PiP/4K/gesture/video-scaling checks')

# V0.6.7: explicit FFmpeg software decoder mode and safe switch behavior.
decoder = (root / 'app/src/main/java/com/aurora/media/player/DecoderChoice.kt').read_text()
decoder_checks = {
    "Decoder mode persists locally": 'putString("decoder_mode", selected)' in session,
    "FFmpeg software mode disables HW decoding": 'media.setHWDecoderEnabled(DecoderChoice.enableHardware(decoderMode), false)' in session and 'mode) != SOFTWARE' in decoder,
    "Decoder switch checkpoints current time": 'pendingDecoderSeekMs = resumePosition' in session,
    "Decoder waits for seekability": 'player.isSeekable && durationMs > 0L' in session,
    "Decode error can retry in software": 'Retry with software decoder' in player,
    "Player settings expose decoder choice": '"decoder" -> OptionDialog' in player,
    "Existing PiP lifecycle unchanged": 'resumeAfterBackground' in activity,
    "Version updated": 'versionCode = 22' in build and 'versionName = "0.6.9"' in build,
}
for label, ok in decoder_checks.items():
    if not ok: raise SystemExit('Decoder regression detected: ' + label)
print(f'PASS: {len(decoder_checks)} v0.6.7 decoder and position regression checks')

# Kotlin compile regression: awaitEachGesture already supplies AwaitPointerEventScope.
# Importing awaitPointerEventScope from pointer package or nesting it again breaks compilation.
if 'import androidx.compose.ui.input.pointer.awaitPointerEventScope' in player:
    raise SystemExit('Invalid awaitPointerEventScope import reintroduced')
if re.search(r'awaitEachGesture\s*\{\s*awaitPointerEventScope\s*\{', player):
    raise SystemExit('Restricted suspension error: nested pointer event scope')
if 'awaitEachGesture {' not in player or 'val activePointers = event.changes.count' not in player:
    raise SystemExit('Two-finger zoom handler missing')
print('PASS: Compose pointer-event scope preflight')

# V0.6.7.2: approved hand-sketched player controls layout.
player_start = player.index('if (controlsVisible && !inPiP && !finished) {')
player_end = player.index('if (finished && !inPiP) {', player_start)
overlay = player[player_start:player_end]
assert 'Spacer(Modifier.weight(1f))' in overlay, 'Player bottom overlay must follow flexible video area'
assert overlay.index('Slider(') < overlay.index('Text(formatted(session.positionMs)') < overlay.index('Row(\n                        modifier = Modifier.fillMaxWidth()'), 'Seek bar and timestamps must appear above bottom control row'
assert overlay.count('Box(Modifier.weight(1f), contentAlignment = Alignment.Center)') == 5, 'Expected five equal-width playback slots'
assert overlay.index('Icons.Default.Replay10') < overlay.index('"Play or pause"') < overlay.index('Icons.Default.Forward10'), 'Play/Pause must be between the two seek buttons'
assert 'Modifier.align(Alignment.Center)\n                    .size(76.dp)' not in overlay, 'Old large central Play/Pause button must be removed'
assert 'Modifier.size(48.dp)' in overlay and 'Color(0xB70C111B)' in overlay, 'Compact translucent dark Play/Pause required'
assert 'Icons.Default.PictureInPictureAlt' in overlay and 'Icons.Default.MoreVert' in overlay, 'Keep top-right PiP and settings'
assert 'session.toggleAspect()' in overlay, 'Fit/Fill button must work'
assert 'Cast' not in overlay and 'cast' not in overlay.lower(), 'Do not add cast button'
print('PASS: 9 approved low progress bar/compact playback controls preflight checks')

# V0.6.8: prevent the bug where SurfaceView keeps tiny PiP geometry.
assert 'ViewGroup.LayoutParams.MATCH_PARENT' in session, 'Full-viewport video SurfaceView is required'
assert 'setWindowSize(width, height)' in session, 'LibVLC must receive full-viewport dimensions'
assert 'setWindowSize(surfaceW, surfaceH)' not in session, 'Never send cropped PiP/video dimensions to Vout'
assert 'surface.layoutParams = params' not in session, 'Do not resize SurfaceView to video rectangle'
assert 'if (suspended) needsVideoRebind = true' not in session, 'Avoid destructive rebind on every background switch'
assert 'fun zoomFactor(' in scaling, 'Aspect-safe Fit/Fill scaling required'
print('PASS: 6 video surface/PiP regression checks for v0.6.8')

# Distinguish the two playback modes at the actual LibVLC level, not with
# unreliable Android SurfaceView scaling.
assert 'player.scale = newScale' in session and 'VideoScaling.vlcScale(' in session
assert 'surface.scaleX = zoom' not in session and 'surface.scaleY = zoom' not in session
assert 'player.aspectRatio = null' in session
assert 'zoomToFill = aspect == "Fill" && !pictureInPicture && videoRatioKnown' in session
print('PASS: 4 LibVLC native Fit/Fill and PiP aspect checks')

assert 'lastAppliedScale != newScale' in session, 'Do not reset VLC video renderer every Compose recomposition'
print('PASS: video scaling calls are cached to avoid redundant vout updates')

# External player fallback regression checks (V0.6.9).
external = (root / 'app/src/main/java/com/aurora/media/player/ExternalPlayerLauncher.kt').read_text()
checks = {
    'VLC is preferred': '.setPackage("org.videolan.vlc")' in external,
    'Fallback chooser exists': 'Intent.createChooser' in external,
    'FTP credentials remain in direct handoff only': 'FtpScanner.mediaUrl(settings, entry.path)' in external,
    'No external URL logging': 'Log.' not in external and 'println(' not in external,
    'One automatic attempt only': 'externalAutoAttempted' in player,
    'Automatic fallback only for fatal errors': 'session.fatalPlaybackError' in player and 'MediaPlayer.Event.EncounteredError' in session,
    'Manual external player override': 'Open in VLC (or another player)' in player,
    'Explicit player chooser': 'launchExternalPlayer(preferVlc = false)' in player,
    'Playback position checkpoint': 'checkpointForExternalPlayer' in session,
    'FTP streaming retained': 'FtpScanner.mediaUrl(settings, entry.path)' in session,
}
for name, valid in checks.items():
    if not valid:
        raise SystemExit(f'FAIL external fallback: {name}')
print(f'PASS: {len(checks)} external-player fallback checks')

# V0.6.9 TV Shows consolidation: one card per show, seasons/episode rows,
# strict TMDb matching, and safe cleanup of previously wrong artwork.
series_helper = (root / 'app/src/main/java/com/aurora/media/ftp/SeriesGrouping.kt').read_text()
series_metadata = (root / 'app/src/main/java/com/aurora/media/metadata/TvMatch.kt').read_text()
tmdb_service = (root / 'app/src/main/java/com/aurora/media/metadata/TmdbService.kt').read_text()
models = (root / 'app/src/main/java/com/aurora/media/data/Models.kt').read_text()
series_checks = {
    'Episode parser groups by series': 'SeriesGrouping.locate(stem)' in ftp and 'SeriesGrouping.key' in ui,
    'TV grid uses one series per card': 'items(series, key = { it.key })' in ui and 'SeriesTile(show' in ui,
    'TV shows have a dedicated detail screen': 'is Screen.Series ->' in ui and 'SeriesDetailsScreen(' in ui,
    'Season tabs are present': 'ScrollableTabRow(' in ui and 'Text("Season $season")' in ui,
    'Episode rows sort by SxxExxx': 'SeriesGrouping.numbers(it.episodeCode)?.episode' in ui,
    'Episode-specific stills displayed': 'episode.episodeStill ?: group.cover.backdrop' in ui,
    'Metadata pulled once per TV season': '/tv/$seriesId/season/$season' in tmdb_service,
    'Reject wrong series metadata': 'TvMatch.exact(title, it.optString("name"))' in tmdb_service,
    'Previously bad posters invalidated': 'cached.metadataMatchVersion >= 3' in vm,
    'Previous watch progress preserved': 'lastPositionMs = cached.lastPositionMs' in vm,
    'External VLC fallback retained': 'open in external player' in player.lower() or 'Open in VLC (or another player)' in player,
    'Version code increased': 'versionCode = 22' in build and 'versionName = "0.6.9"' in build,
    'Java action updated': 'actions/setup-java@v5' in (root / '.github/workflows/build-apk.yml').read_text(),
}
for label, good in series_checks.items():
    if not good:
        raise SystemExit('TV series regression: '+label)
print(f'PASS: {len(series_checks)} series grouping, TMDb art, and episode-list checks')

# Folder-aware, year-specific TV artwork; refuse mismatched same-title TV results.
series_source = (root / 'app/src/main/java/com/aurora/media/ftp/SeriesGrouping.kt').read_text()
scanner_source = (root / 'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt').read_text()
viewmodel_source = (root / 'app/src/main/java/com/aurora/media/ui/AuroraViewModel.kt').read_text()
assert 'fun folderYear(path: String)' in series_source
assert 'SeriesGrouping.folderYear(path)' in scanner_source
assert 'first_air_date_year' in metadata
assert 'optString("first_air_date")' in metadata
assert 'cached.metadataMatchVersion >= 3' in viewmodel_source
assert 'episodeMetadataFetched = entry.remoteId == updated.remoteId' in viewmodel_source
print('PASS: nested-folder year, exact-year TMDb TV lookup, stale poster/episode cache invalidation')
