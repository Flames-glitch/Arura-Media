"""Aurora Media static checks; no Android SDK required. Not a substitute for Gradle compile/device testing."""
from pathlib import Path
from xml.etree import ElementTree
import re

root = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle.kts', 'build.gradle.kts', 'app/build.gradle.kts',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/aurora/media/MainActivity.kt',
    'app/src/main/java/com/aurora/media/player/VlcSession.kt',
    'app/src/main/java/com/aurora/media/player/PlayerScreen.kt',
    'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt',
    'app/src/main/java/com/aurora/media/metadata/TmdbService.kt',
]
for f in required:
    if not (root / f).is_file():
        raise SystemExit(f'Missing essential source file: {f}')
manifest = ElementTree.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
android = '{http://schemas.android.com/apk/res/android}'
permissions = [x.attrib.get(android + 'name') for x in manifest.findall('uses-permission')]
if 'android.permission.INTERNET' not in permissions:
    raise SystemExit('INTERNET permission missing')
app = manifest.find('application')
if app is None or not app.attrib.get(android+'label') == 'Aurora Media':
    raise SystemExit('Aurora Media app label missing')
source_dir = root / 'app/src/main/java'
source = '\n'.join(f.read_text() for f in source_dir.rglob('*.kt'))
if 'Media.Slave.Type.Subtitle' in source:
    raise SystemExit('Unsupported Media.Slave.Type.Subtitle reference')
if re.search(r'fun\s+setSpeed\s*\(', source):
    raise SystemExit('Potential Kotlin property setter clash: setSpeed')
if 'session::setSpeed' in source:
    raise SystemExit('Stale playback speed method reference')
if 'session::updateSpeed' not in source:
    raise SystemExit('Missing playback speed UI callback')
if 'fun updateSpeed(value: Float)' not in source:
    raise SystemExit('Missing playback speed method')
ftp = (root / 'app/src/main/java/com/aurora/media/ftp/FtpScanner.kt').read_text()
if 'FTP.BINARY_FILE_TYPE' not in ftp or 'enterLocalPassiveMode()' not in ftp:
    raise SystemExit('FTP binary/passive mode missing')
if 'ftp://' not in ftp:
    raise SystemExit('FTP stream URL missing')
if 'sftp://' in source.lower():
    raise SystemExit('SFTP included unexpectedly')
build = (root / 'app/build.gradle.kts').read_text()
if 'applicationId = "com.aurora.media"' not in build:
    raise SystemExit('Wrong application ID')
if 'compileSdk = 35' not in build:
    raise SystemExit('Android SDK 35 mismatch')
if 'org.videolan.android:libvlc-all:3.5.1' not in build:
    raise SystemExit('Expected VLC dependency missing')
print('PASS: source structure, XML, FTP-only configuration, LibVLC references, Gradle constants')
print(f'Source files: {len(list(source_dir.rglob("*.kt")))} Kotlin files')

# Offload-specific safety guarantees checked statically; runtime tests remain essential.
offload = root / 'app/src/main/java/com/aurora/media/offload'
for name in ['OffloadEngine.kt', 'OffloadWorker.kt', 'OffloadScreen.kt']:
    if not (offload / name).is_file():
        raise SystemExit('Missing offload file: ' + name)
engine = (offload / 'OffloadEngine.kt').read_text()
for guard in ['retrieveFileStream', 'SHA-256', 'file.delete()', 'allowDeletion', 'rename(tempPath, finalPath)', 'take(8)']:
    if guard not in engine:
        raise SystemExit('Missing upload safety guard: ' + guard)
ui = (offload / 'OffloadScreen.kt').read_text()
for must in ['OpenDocumentTree', 'takePersistableUriPermission', 'confirmOneTime', 'confirmAutomatic']:
    if must not in ui:
        raise SystemExit('Missing offload consent or folder selection: ' + must)
print('PASS: verified-delete guards, folder picker, automatic opt-in, and offload source files')

# V0.6 regression gates: previously observed Android build/runtime faults.
ui = (root / 'app/src/main/java/com/aurora/media/ui/AuroraApp.kt').read_text()
vm = (root / 'app/src/main/java/com/aurora/media/ui/AuroraViewModel.kt').read_text()
player = (root / 'app/src/main/java/com/aurora/media/player/PlayerScreen.kt').read_text()
session = (root / 'app/src/main/java/com/aurora/media/player/VlcSession.kt').read_text()
activity = (root / 'app/src/main/java/com/aurora/media/MainActivity.kt').read_text()
cleaner = (root / 'app/src/main/java/com/aurora/media/ftp/FilenameCleaner.kt').read_text()
properties = (root / 'gradle.properties').read_text()
regressions = {
    "AndroidX disabled (previous Gradle failure)": "android.useAndroidX=true" in properties,
    "Old malformed remote control constant": "KEYCODE_HEADSETPHOOK" not in source,
    "Playback start-over option": "Start from Beginning" in ui and "fromBeginning" in vm,
    "Next video recommendations": "What to watch next" in player and "recommendationsFor" in vm,
    "Screen awake flag": "FLAG_KEEP_SCREEN_ON" in player,
    "PiP close/stop lifecycle": "onPictureInPictureModeChanged" in activity and "stopPlayback()" in activity,
    "Buffering debounce": "bufferingCheck" in session and "lastAdvancedAt" in session,
    "Filename watermarks": "websitePrefix" in cleaner and "solar" in cleaner,
    "Cache title refresh": "cached.title == current.title" in vm,
    "Previous LibVLC enum regression": "Media.Slave.Type.Subtitle" not in source,
    "Previous speed setter regression": "fun setSpeed(" not in source,
    "VLC FTP stream support": "org.videolan.android:libvlc-all:3.5.1" in build,
    "Storage offloader retained": (offload / "OffloadEngine.kt").is_file(),
    "Version bumped": "versionCode = 7" in build and 'versionName = "0.6.1"' in build,
}
for label, ok in regressions.items():
    if not ok: raise SystemExit("Regression detected: " + label)
print(f"PASS: {len(regressions)} V0.6 playback, FTP, metadata, UX and build-regression checks")

# V0.6.1: transfer notification and retry/deletion safety checks
worker = (offload / "OffloadWorker.kt").read_text()
engine = (offload / "OffloadEngine.kt").read_text()
ui = (offload / "OffloadScreen.kt").read_text()
extra_checks = {
    "FTP upload notifications show percentage": "setProgress(100" in worker and "progressBytes" in worker,
    "Notification channel created": "NotificationChannel" in worker,
    "Android 13 notification permission prompt": "askNotification.launch" in ui,
    "Foreground service type dataSync": "FOREGROUND_SERVICE_TYPE_DATA_SYNC" in worker,
    "App verifies before deleting": "digestRemote(ftp, tempPath" in engine and "file.delete()" in engine,
    "No accidental transfer restart after cancellation": "Result.failure" in worker and "TransferInterrupted" in worker,
    "Safe error summary retained": "prefs.lastReport" in worker,
    "Old crash-loop jobs cancelled once on upgrade": "v061_safety_reset" in (root / "app/src/main/java/com/aurora/media/AuroraApplication.kt").read_text(),
    "Progress counts uploaded bytes": "onRead(bytes)" in engine and "progressBytes(relative, bytes" in engine,
}
for label, ok in extra_checks.items():
    if not ok: raise SystemExit("V0.6.1 regression failure: " + label)
print(f"PASS: {len(extra_checks)} V0.6.1 notification and transfer-safety checks")
