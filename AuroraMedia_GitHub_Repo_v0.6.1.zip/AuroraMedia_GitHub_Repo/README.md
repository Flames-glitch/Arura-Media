# Aurora Media for Android — V0.5.0 Phone Storage Offloading

Standalone Android FTP video player and phone-to-FTP file offloader; separate from the Fire TV edition.

## New: Move phone folder to FTP to reclaim local storage

Open the cloud-upload icon in the media library, then:

1. Select one phone folder using Android's system folder picker. The application stores the SAF read/write permission.
2. Choose an FTP destination, e.g. `/usb1_1/PhoneArchive` (separate from the movie library at `/usb1_1/movies`). FTP credentials are reused from your saved Aurora Media connection.
3. Explicitly enable **Delete each local original after verification**.
4. Confirm **Move now & free space**. Test with a small nonessential folder first.
5. Optionally enable daily automatic moves on Wi-Fi only, after validating manual results.

**Transfer safety:** Preserve relative subfolders; upload to a temporary `.aurora-*.part` file; verify size and SHA-256 digest by reading the FTP copy back; rename into the final remote filename; verify the local file again; only then delete the original through Android's folder permission. Existing remote filenames are never silently overwritten. If a same-name remote file already has the exact same SHA-256 content, the original may be safely removed; otherwise it is skipped. If a copy can't be verified, is interrupted, or FTP is unreachable, its local original remains. Empty local folders are retained. The app does **not** delete any remote files.

**Important caveats:** FTP is unencrypted, so operate on trusted home Wi-Fi or a private VPN. Remote verification doubles network reading and can be slow for very large movies. A successful hash comparison does not replace independent long-term backups, especially on consumer USB storage. An Android/FTP server may refuse folder access, listing, temporary file renaming, file deletion, or background foreground-service permissions. Scheduled runs are best-effort, not exact-time; only Wi-Fi is used. Android's picker restricts certain roots/folders. This feature does not provide two-way sync.

**First run caution:** The versionCode is 5, so the update can install over V0.4 only if the APK signatures match. A temporary GitHub debug signing key may change between runs. Uninstalling the older app deletes its saved FTP settings.

## GitHub ZIP workflow

Upload `AuroraMedia_GitHub_Repo_v0.5.zip` to the root of `Flames-glitch/Arura-Media` (do not unpack on your phone). Ensure `.github/workflows/build-apk.yml` uses the supplied **no-secrets test build workflow**; source ZIPs don't automatically replace the workflow in GitHub's repo root. GitHub Actions will extract `AuroraMedia_GitHub_Repo` from the ZIP, compile Android debug APK, and publish an artifact.

**Verification status:** Source syntax/structure, ZIP integrity, and manifest XML were checked locally. Full Gradle compilation and on-device FTP move/deletion safety require GitHub Actions and a test Android device.

---

# Aurora Media — Standalone Android FTP Movie Library

Aurora Media is **a completely independent Android application**; it does not share code, package names or build outputs with AuroraTV IPTV. FTP only; no SFTP dependency or support.

## What V0.1 includes

- Android app with dark Material 3 screens and one-time FTP connection setup.
- Plain FTP, passive mode, binary transfer; choose server, port, user, password and media path.
- FTP folder recursion and filename-based movie/TV episode recognition.
- Optional **TMDb API Read Access Token** for poster/backdrop/synopsis matching. Empty token = filename-only library. Cached metadata and scanning results remain visible if FTP is temporarily unreachable.
- Movie poster grid, Movies / TV Shows / Continue Watching filters, title search, details screen.
- Native LibVLC playback (not an external VLC intent) for supported files over FTP.
- Player controls: play/pause, ±10s seeking, scrub bar, resume, audio/subtitle track selection, aspect ratio, speed, volume up to a requested 125%, audio/subtitle delay ±250 ms adjustments, orientation auto/landscape/portrait/locked, external subtitle import, equalizer presets when supported by the bundled LibVLC ABI.
- Locally cached library; Android Keystore encryption for saved FTP password and TMDb token.
- GitHub Actions debug APK build.

## Build a debug APK using GitHub (no local SDK required)

1. Create a **new** repository for Aurora Media (do not upload into the AuroraTV repository).
2. Upload **the contents of this folder** to the repository root (including `.github/`).
3. Go to **Actions → Build Aurora Media APK → Run workflow**. Alternatively push to `main` or `master`.
4. Open the successful run and download the **AuroraMedia-debug-APK** artifact.
5. Install its `app-debug.apk` on Android (Android may require you to permit installing downloaded APKs).

The workflow provisions JDK 17, Android SDK 35, Gradle 8.9 and builds `:app:assembleDebug`. This archive intentionally does not include an unverified Gradle wrapper JAR. The GitHub workflow uses the official Gradle setup action instead, so no `gradlew` is required. In Android Studio, use Gradle 8.9 and JDK 17.

**Verification status:** The source tree was generated in an offline environment without an Android SDK or dependency repositories, so a successful APK compilation has *not* been verified here. The GitHub workflow is the first real end-to-end build test. If GitHub reports a compiler error, provide the Actions build log for fixes.

## First-launch connection

- Host: e.g. `192.168.1.254` (example only; enter your real address).
- Port: `21` unless your FTP server uses another port.
- Username, password: your FTP server account.
- Media directory: `/` or `/Movies`, depending on your server root.
- TMDb: create an API Read Access Token at [TMDb](https://www.themoviedb.org/settings/api); paste it in the app. Do **not** place the token into source code or GitHub Secrets for this client-side use case.

After a successful FTP connection, the app saves credentials and discovers supported video files. The first metadata enrichment requires internet access. If automatic identification is wrong, V0.1 has no manual match editor; that is planned for a future version.

## Network security

**Plain FTP is unencrypted.** Login credentials and content may be exposed on an untrusted network. The on-device Keystore protects saved credentials at rest, but **does not encrypt FTP traffic**. Use this app only on trusted local Wi-Fi or over an already established private VPN. Do not port-forward FTP/21 from your router to the public internet.

The app communicates with TMDb via HTTPS and never transmits FTP usernames, passwords, video URLs, folder paths or file content to TMDb.

## Feature scope and limitations

- **LibVLC offers broad format support, not an absolute guarantee of every codec/container.** Hardware decoding support varies by SoC, Android version and codec; software fallback can be expensive.
- **FTP seeking** depends on the server supporting REST/restart and LibVLC's FTP demuxer. Some server/file combinations may not seek properly; test using your actual server.
- Audio boost above 100% and equalizer availability depend on the specific LibVLC build and audio path; boosted audio may clip.
- TMDb filename matching is best effort; releases, remakes and multi-file titles can be misidentified. IMDb or Google image scraping is intentionally not used.
- The player supports *external subtitle selection*, but **in-app online subtitle search/download is not yet implemented**. That requires a supported subtitle provider and API authentication. Fine control over subtitle appearance, gesture-based brightness/volume, custom equalizer bands, robust fill/crop scaling, and a full TV season grouping UI remain future work.
- Cached images depend on Coil's disk cache. Videos are streamed and not stored locally.
- The scanner caps recursion depth at 20 and video count at 8,000 per refresh.
- Desktop, iOS, Android TV remote/D-pad optimizations and Chromecast are not included in this phone-first V0.1.

## Tech stack

Kotlin 2.0.21; Compose Material 3; Android Gradle Plugin 8.7.3; Commons Net FTPClient 3.11.1; LibVLC `libvlc-all` 3.5.1; Coil 2.7.0; Android Keystore / AES-GCM; TMDb REST/HTTPS; Gradle 8.9; Android min SDK 26, target SDK 35.

TMDb artwork and data remain © their respective owners. The application is not endorsed or certified by TMDb. For distributable applications, comply with TMDb branding, attribution and API terms. VLC/LibVLC is subject to its respective open-source licensing obligations: verify LGPL/GPL redistribution requirements before releasing this app publicly.

## Project identity

| Property | Value |
|---|---|
| Display name | Aurora Media |
| Android ID | `com.aurora.media` |
| Repository ZIP top folder | `AuroraMedia_GitHub_Repo` |
| IPTV dependency | None |
| Network file protocol | FTP only |


## V0.2 source fixes

- Corrected Kotlin JVM signature clash between the `speed` property and a custom setter.
- Corrected LibVLC's subtitle-slave type constant.
- Imported subtitles selected via Android's file picker into app-private cache so LibVLC can read local paths.
- Closed FTP sessions if authentication or binary-mode setup fails.
- Corrected finished-video resume state and ignored queued LibVLC callbacks after player release.
- Kept FTP-only operation and standalone application ID `com.aurora.media`.

**Verification scope:** the source and archive have been statically checked, but this package still requires an actual GitHub Actions Android compilation and testing against your FTP server and Android device.

## V0.3: gesture player and metadata diagnostics

- In landscape playback, swipe up/down on left half for **window brightness**, right half for **Android media volume**; an icon + percentage + progress bar is displayed.
- Swipe horizontally for **video seeking**. A preview shows the offset/target time, and the seek request occurs when you lift your finger (reduces FTP requests). Dragging a full screen width represents up to 90 seconds; the seek is clamped to available duration.
- Tap video to toggle overlay controls. Screen bars hide during playback. Brightness restores on exit. Hardware buttons still work.
- Video output window size is synchronized to Compose layout bounds to help avoid off-center rendering. Verify on a real Android device.
- TMDb supports either a 32-hex-character **v3 API key** or an **API Read Access Token** (Bearer), and failures appear on the library screen instead of failing silently. Posters still depend on TMDb title matches and network access.
- New branded launcher icon is included.

This project was statically checked; no Android SDK or internet was available for a full Gradle build here. Build and test via GitHub Actions before relying on it.


## V0.4 — picture-in-picture, Fit and permanent signing

- **Home button:** While the video is playing, try entering Android picture-in-picture (PiP). PiP must be allowed by Android for Aurora Media and supported by the device. Player chrome and swipe gestures are suppressed inside the compact window. An on-screen PiP button is also provided.
- **Background playback:** If PiP is unavailable or not entered, leaving the app pauses playback instead of continuing invisibly. Back from the player ends the VLC session.
- **Fit:** Reset LibVLC scale to zero (automatic fit) and clear forced aspect ratio. Fit is intended to letterbox rather than crop. Fill uses the display aspect ratio; validate on your phone, especially with non-16:9 videos.
- **Signing:** The root GitHub Actions workflow expects `AURORA_KEYSTORE_B64` and `AURORA_KEYSTORE_PASSWORD` repository secrets. Keep the PKCS12 keystore private and offline-backed-up. Alias must be `aurora-media` and key password must match store password. APK is signed with that *same* key on each CI run, and its public certificate SHA-256 digest appears in build logs. Debug build remains debuggable; it is for testing rather than Play Store distribution.
- **Signing migration:** V0.3 used a temporary GitHub runner debug certificate. Unless its original private key was saved, V0.4 signed with your permanent certificate **cannot install over V0.3**; one more uninstall/reinstall is necessary. Android will delete old V0.3 app settings because `allowBackup=false`. From the first permanent-key installation onward, updates with the same application ID, key and increasing versionCode can install in place without clearing data.

### Create the keystore on Android with Termux

Install OpenJDK if necessary using `pkg install openjdk-17`. Run:

```sh
keytool -genkeypair -storetype PKCS12 -keystore "$HOME/aurora-media-signing.p12" \
  -alias aurora-media -keyalg RSA -keysize 3072 -validity 10000 \
  -dname 'CN=Aurora Media, O=Aurora Media, C=IN'
```

Choose a strong password interactively (store and key password must match). Encode the keystore as one long line:

```sh
base64 -w 0 "$HOME/aurora-media-signing.p12"
```

Create repository Actions secrets `AURORA_KEYSTORE_B64` (the entire base64 string) and `AURORA_KEYSTORE_PASSWORD` (your password). Do not upload the `.p12` to the GitHub repository or send it to anyone. Back up the private keystore and password securely; losing either prevents installing subsequent updates over the permanently signed version.

### Mobile ZIP build

Upload `AuroraMedia_GitHub_Repo_v0.4.zip` unchanged to the repository root. In `.github/workflows/build-apk.yml` at repository root (NOT only inside the ZIP), paste `AuroraMedia_Persistent_Signing_Build_v0.4.yml`. Committing the workflow triggers a build, or use Actions > Run workflow. The archive contains the standalone Android project in the `AuroraMedia_GitHub_Repo/` folder. No SFTP/IPTV code is involved.

**Verification status:** Source/static checks were performed here; Android Gradle compilation and on-device PiP/fit behavior still require GitHub and device testing.


## Aurora Media v0.6 — streaming playback and discovery refresh

- Player keeps the screen on while playing and releases its keep-awake flag on pause/exit.
- Playback stops when the player is closed, the app stops, or floating PiP is dismissed; expanding PiP back to the player does not intentionally stop playback.
- VLC buffering overlay is shown only after a sustained playback stall, not from every transient Buffering callback.
- Filename watermarks such as `www.1TamilMV.solar -` are stripped *before* TMDb lookup; previously cached titles are re-parsed on rescans.
- The details screen provides **Resume Playback** and **Start from Beginning**.
- A cinematic home screen and details page use real FTP/TMDb artwork.
- Playback completion presents suggested next videos from the **local FTP library**, with genre/year similarity and same-series preference. No outside streaming service is accessed for playback.
- Existing manual/scheduled **Move to FTP & Free Space** feature is retained without changes to its deletion safety controls.
- `tools/verify_project.py` performs static regression checks and the workflow runs JUnit `FilenameCleanerTest` before assembling the debug APK.

Run the CI workflow from the **root** of the GitHub repo where `AuroraMedia_GitHub_Repo_v0.6.zip` is uploaded. Do not extract the ZIP. The project inside the ZIP is `AuroraMedia_GitHub_Repo/`. To use updated unit-test gating, replace `.github/workflows/build-apk.yml` in the GitHub repository with the separately supplied workflow file.

**Limitations:** A source ZIP is not a compiled APK; actual Android compilation and tests require an Android SDK (available on the GitHub Actions runner). Test PiP and keep-awake on a real Android device. Debug-signature identity can change between CI runs. Never enable automatic offloading of irreplaceable content without checking the copies on FTP.


## V0.6.1 Android transfer stability patch

- Fixes the missing ongoing notification progress: while moving a file, Android's notification shade shows the current filename and an upload percentage. A summary notification is posted upon successful completion.
- Requires notification permission on Android 13+ before starting a foreground move; if foreground service initialization is blocked, no files are moved.
- A manual cancellation or a missing Wi-Fi connection now stops the job rather than automatically retrying and unexpectedly moving files later.
- Keeps V0.6 FTP verification-before-local-deletion, streaming playback, PiP, library, TMDb and premium interface features.
- IMPORTANT: These are defensive fixes, not a confirmed resolution of a device-specific crash without Android logcat. Test using disposable source files first.
