package com.aurora.media.offload

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.aurora.media.data.SecureSettings
import com.aurora.media.ftp.FtpScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.net.ftp.FTPClient
import java.io.FilterInputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.Locale

/** A SAF tree grant and user opt-in are prerequisites for any source-file deletion. */
class OffloadPreferences(context: Context) {
    private val preferences = context.getSharedPreferences("aurora_offload_v1", Context.MODE_PRIVATE)
    var sourceTree: String
        get() = preferences.getString("source", "").orEmpty()
        set(value) = preferences.edit().putString("source", value).apply()
    var destination: String
        get() = preferences.getString("destination", "/usb1_1/PhoneArchive") ?: "/usb1_1/PhoneArchive"
        set(value) = preferences.edit().putString("destination", value).apply()
    var allowDeletion: Boolean
        get() = preferences.getBoolean("allow_deletion", false)
        set(value) = preferences.edit().putBoolean("allow_deletion", value).apply()
    var automatic: Boolean
        get() = preferences.getBoolean("automatic", false)
        set(value) = preferences.edit().putBoolean("automatic", value).apply()
    var lastReport: String
        get() = preferences.getString("last_report", "No files moved yet").orEmpty()
        set(value) = preferences.edit().putString("last_report", value).apply()
}

object OffloadEngine {
    data class Report(var moved: Int = 0, var skipped: Int = 0, var failed: Int = 0, var bytesFreed: Long = 0L, var firstError: String = "") {
        fun display(): String = "Moved $moved file(s), freed ${"%.1f".format(Locale.ROOT, bytesFreed / 1048576.0)} MiB; " +
            "skipped $skipped, failed $failed" + if (firstError.isBlank()) "" else ". First issue: $firstError"
    }

    class TransferInterrupted : Exception("Transfer cancelled")

    /** Only a plain FTP path. Keep it outside the media library by default. */
    fun cleanDestination(raw: String): String {
        val path = raw.trim().trimEnd('/')
        require(path.startsWith('/') && path.length > 1) { "Destination must be an absolute FTP folder (not /)" }
        val components = path.split('/').drop(1)
        require(components.all { it.isNotBlank() && it != "." && it != ".." &&
            it.none { character -> character.code < 32 || character == '\\' } }) { "Invalid destination folder" }
        return path
    }

    private fun safeName(name: String): String {
        require(name.isNotEmpty() && name != "." && name != ".." &&
            name.none { it == '/' || it == '\\' || it.code < 32 }) { "Unsafe filename" }
        return name
    }

    fun isOnWifi(context: Context): Boolean {
        val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivity.activeNetwork ?: return false
        return connectivity.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    }

    private fun folder(ftp: FTPClient, absolute: String) {
        var current = ""
        for (piece in absolute.trim('/').split('/')) {
            current += "/" + piece
            if (!ftp.changeWorkingDirectory(current)) {
                if (!ftp.makeDirectory(current) || !ftp.changeWorkingDirectory(current)) {
                    error("Unable to create FTP folder $current")
                }
            }
        }
    }

    private fun onServer(ftp: FTPClient, parent: String, name: String): Long? =
        ftp.listFiles(parent).firstOrNull { it.isFile && it.name == name }?.size

    private class Counted(input: InputStream, private val stopped: () -> Boolean,
        private val onRead: (Long) -> Unit) : FilterInputStream(input) {
        var bytes: Long = 0
            private set
        override fun read(): Int {
            if (stopped()) throw TransferInterrupted()
            val value = super.read()
            if (value >= 0) { bytes++; onRead(bytes) }
            return value
        }
        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            // Don't use FilterInputStream.read(buffer,offset,length), which may call read()
            // and double-count if overridden.
            if (stopped()) throw TransferInterrupted()
            val read = `in`.read(buffer, offset, length)
            if (read > 0) { bytes += read; onRead(bytes) }
            return read
        }
    }

    private fun hex(digest: MessageDigest): String = digest.digest().joinToString("") { "%02x".format(it) }

    private fun digestLocal(context: Context, file: DocumentFile, checkStopped: () -> Boolean): Pair<Long, String> {
        val sha = MessageDigest.getInstance("SHA-256")
        var count = 0L
        context.contentResolver.openInputStream(file.uri)?.use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                if (checkStopped()) throw TransferInterrupted()
                val n = stream.read(buffer)
                if (n < 0) break
                if (n > 0) { sha.update(buffer, 0, n); count += n }
            }
        } ?: error("Can't read local file")
        return count to hex(sha)
    }

    private fun digestRemote(ftp: FTPClient, remotePath: String, checkStopped: () -> Boolean): Pair<Long, String> {
        val sha = MessageDigest.getInstance("SHA-256")
        val stream = ftp.retrieveFileStream(remotePath) ?: error("Server cannot read back $remotePath for verification")
        var count = 0L
        var complete = false
        try {
            stream.use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    if (checkStopped()) throw TransferInterrupted()
                    val n = input.read(buffer)
                    if (n < 0) break
                    if (n > 0) { sha.update(buffer, 0, n); count += n }
                }
            }
            complete = ftp.completePendingCommand()
        } finally {
            // A failed or interrupted stream must never lead to deletion.
            if (!complete) runCatching { ftp.disconnect() }
        }
        if (!complete) error("FTP verification transfer did not complete")
        return count to hex(sha)
    }

    private fun idFor(relative: String): String = MessageDigest.getInstance("SHA-256")
        .digest(relative.toByteArray(Charsets.UTF_8)).take(8).joinToString("") { "%02x".format(it) }

    /** Existing same-name destinations are read and hashed; never replaced implicitly. */
    private fun moveOne(
        context: Context, ftp: FTPClient, parent: String, file: DocumentFile, relative: String,
        checkStopped: () -> Boolean, progressBytes: (String, Long, Long) -> Unit
    ): Long? {
        val name = safeName(file.name ?: error("Unnamed document"))
        val finalPath = "$parent/$name"
        val initialLength = file.length()
        val initialModified = file.lastModified()
        val existing = onServer(ftp, parent, name)
        if (existing != null) {
            if (initialLength > 0 && existing != initialLength) return null
            // Previous run may have uploaded successfully but stopped before local deletion.
            val local = digestLocal(context, file, checkStopped)
            if (digestRemote(ftp, finalPath, checkStopped) != local) return null
            if (file.length() != initialLength || (initialModified > 0 && file.lastModified() != initialModified)) {
                error("Source changed while verifying")
            }
            if (checkStopped()) throw TransferInterrupted()
            if (!OffloadPreferences(context).allowDeletion) error("Verified but move permission revoked; source preserved")
            if (!file.delete()) error("Uploaded file verified, but Android refused local deletion")
            return local.first
        }

        val tempName = ".aurora-${idFor(relative)}.part"
        val tempPath = "$parent/$tempName"
        // A partial upload from a crash can be discarded, but a finished destination cannot.
        if (onServer(ftp, parent, tempName) != null) {
            if (!ftp.deleteFile(tempPath)) error("Cannot clean up incomplete server upload $tempName")
        }
        val sha = MessageDigest.getInstance("SHA-256")
        var written = 0L
        var published = false
        try {
            val input = context.contentResolver.openInputStream(file.uri) ?: error("Cannot open selected local file")
            input.use { source ->
                val counting = Counted(source, checkStopped) { bytes ->
                    progressBytes(relative, bytes, initialLength)
                }
                // Commons Net streams bytes without loading the file into app memory.
                val hashing = java.security.DigestInputStream(counting, sha)
                if (!ftp.storeFile(tempPath, hashing)) error("FTP rejected upload $name: ${ftp.replyString}")
                written = counting.bytes
            }
            if (written != initialLength && initialLength > 0) error("Local file changed size while uploading")
            progressBytes("$relative · verifying copy", 0L, 0L)
            if (onServer(ftp, parent, tempName) != written) error("FTP upload size mismatch")
            val expected = written to hex(sha)
            if (digestRemote(ftp, tempPath, checkStopped) != expected) error("FTP SHA-256 verification failed")
            if (checkStopped()) throw TransferInterrupted()
            if (onServer(ftp, parent, name) != null) error("Destination appeared during upload; leaving source untouched")
            if (!ftp.rename(tempPath, finalPath)) error("Could not finalize remote upload")
            published = true
            if (onServer(ftp, parent, name) != written) error("Final remote size mismatch")
            // Re-read local file to guard against changes during the network upload.
            if (digestLocal(context, file, checkStopped) != expected ||
                (initialModified > 0 && file.lastModified() != initialModified)) error("Local file changed; will not delete")
            if (checkStopped()) throw TransferInterrupted()
            if (!OffloadPreferences(context).allowDeletion) error("Verified but move permission revoked; source preserved")
            if (!file.delete()) error("Verified FTP file saved, but Android denied local deletion")
            return written
        } finally {
            if (!published && ftp.isConnected) runCatching { ftp.deleteFile(tempPath) }
        }
    }

    /** Runs on a worker thread. Deletion needs a deliberately enabled user preference. */
    suspend fun run(context: Context, progress: suspend (Report, String) -> Unit, stopped: () -> Boolean,
                    progressBytes: (String, Long, Long) -> Unit = { _, _, _ -> }): Report =
        withContext(Dispatchers.IO) {
            val config = OffloadPreferences(context)
            if (!config.allowDeletion) error("Move-and-delete permission is not enabled")
            val sourceText = config.sourceTree
            require(sourceText.isNotBlank()) { "Choose a local source folder first" }
            val destination = cleanDestination(config.destination)
            val granted = context.contentResolver.persistedUriPermissions.any { it.uri.toString() == sourceText &&
                it.isReadPermission && it.isWritePermission }
            require(granted) { "Selected folder grant was lost; select the folder again" }
            val tree = DocumentFile.fromTreeUri(context, Uri.parse(sourceText)) ?: error("Local folder is unavailable")
            require(tree.isDirectory && tree.canRead() && tree.canWrite()) { "Selected folder is not writable" }
            val settings = SecureSettings(context).load()
            require(settings.ready) { "Configure the FTP connection in Aurora Media first" }
            val report = Report()
            var visited = 0
            FtpScanner.withConnection(settings) { ftp ->
                folder(ftp, destination)
                suspend fun walk(node: DocumentFile, parent: String, relative: String, depth: Int) {
                    if (stopped()) throw TransferInterrupted()
                    if (depth > 24) error("Folder nesting is too deep")
                    folder(ftp, parent)
                    for (child in node.listFiles()) {
                        if (stopped()) throw TransferInterrupted()
                        if (++visited > 50_000) error("Too many files in selected folder")
                        val name = child.name ?: continue
                        val safe = try { safeName(name) } catch (_: IllegalArgumentException) {
                            report.skipped++; continue
                        }
                        val childRelative = if (relative.isBlank()) safe else "$relative/$safe"
                        if (child.isDirectory) {
                            walk(child, "$parent/$safe", childRelative, depth + 1)
                        } else if (child.isFile) {
                            try {
                                val freed = moveOne(context, ftp, parent, child, childRelative, stopped, progressBytes)
                                if (freed != null) { report.moved++; report.bytesFreed += freed }
                                else report.skipped++
                            } catch (stop: TransferInterrupted) {
                                throw stop
                            } catch (error: Exception) {
                                report.failed++
                                if (report.firstError.isBlank()) report.firstError = error.message ?: "Transfer error"
                                if (!ftp.isConnected) throw error
                            }
                            progress(report, childRelative)
                        }
                    }
                }
                walk(tree, destination, "", 0)
            }
            report
        }
}
