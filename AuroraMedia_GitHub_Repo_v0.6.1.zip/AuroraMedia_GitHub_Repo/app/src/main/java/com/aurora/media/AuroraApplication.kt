package com.aurora.media

import android.app.Application
import androidx.work.WorkManager
import com.aurora.media.offload.OffloadPreferences
import com.aurora.media.offload.OffloadScheduler

class AuroraApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // One-time migration: orphaned V0.6 foreground moves can be automatically
        // restarted by WorkManager after a crash. Stop these OLD requests before
        // the user starts a fresh, visible V0.6.1 move. Folder permissions, FTP
        // credentials and user-selected paths are preserved.
        val marker = getSharedPreferences("aurora_offload_migration", MODE_PRIVATE)
        if (!marker.getBoolean("v061_safety_reset", false)) {
            runCatching {
                val work = WorkManager.getInstance(this)
                work.cancelUniqueWork(OffloadScheduler.NOW)
                work.cancelUniqueWork(OffloadScheduler.DAILY)
                OffloadPreferences(this).apply {
                    automatic = false
                    lastReport = "Old V0.6 queued moves were stopped for safety. Check your FTP files, then use Move Now. Automatic moves are off."
                }
            }.onSuccess {
                marker.edit().putBoolean("v061_safety_reset", true).apply()
            }
        }
    }
}
