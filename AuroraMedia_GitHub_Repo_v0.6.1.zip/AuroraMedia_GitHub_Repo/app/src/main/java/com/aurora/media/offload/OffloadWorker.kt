package com.aurora.media.offload

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.aurora.media.MainActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale
import java.util.concurrent.TimeUnit

object OffloadScheduler {
    const val NOW = "aurora_phone_offload_now"
    const val DAILY = "aurora_phone_offload_daily"
    private val network = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    fun moveNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<OffloadWorker>().setConstraints(network).build()
        WorkManager.getInstance(context).enqueueUniqueWork(NOW, ExistingWorkPolicy.KEEP, request)
    }

    fun configureDaily(context: Context, enabled: Boolean) {
        val work = WorkManager.getInstance(context)
        if (enabled) {
            val request = PeriodicWorkRequestBuilder<OffloadWorker>(24, TimeUnit.HOURS)
                .setConstraints(network).build()
            work.enqueueUniquePeriodicWork(DAILY, ExistingPeriodicWorkPolicy.UPDATE, request)
        } else work.cancelUniqueWork(DAILY)
    }
}

/** Foreground work keeps the transfer visible and cancellable from Android's running-app UI.
 * Transfers NEVER continue after a foreground-notification startup failure.
 */
class OffloadWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    companion object {
        private const val CHANNEL = "aurora_file_offload"
        private const val NOTIFICATION_ID = 1735
        private const val FINISHED_ID = 1736
        private val transferLock = Mutex()
    }

    private val manager by lazy {
        applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }
    private var lastNotifyAt = 0L

    private fun notificationPermissionGranted(): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
            applicationContext, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(
                CHANNEL, "Aurora file transfers", NotificationManager.IMPORTANCE_LOW
            ))
        }
    }

    private fun notification(text: String, percent: Int? = null, finished: Boolean = false): Notification {
        createChannel()
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            applicationContext, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle(if (finished) "Aurora Media • Transfer finished" else "Aurora Media • Moving to FTP")
            .setContentText(text)
            .setContentIntent(pending)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setOnlyAlertOnce(true)
            .setOngoing(!finished)
            .setAutoCancel(finished)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (!finished) {
            if (percent == null) builder.setProgress(0, 0, true)
            else builder.setProgress(100, percent.coerceIn(0, 100), false)
        }
        return builder.build()
    }

    private fun updateNotification(text: String, percent: Int? = null, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastNotifyAt < 900L) return
        lastNotifyAt = now
        // Notification failures must not crash the app or affect verified file safety.
        runCatching { manager.notify(NOTIFICATION_ID, notification(text, percent)) }
    }

    private suspend fun enterForeground(): Boolean {
        if (!notificationPermissionGranted() || !manager.areNotificationsEnabled()) return false
        return try {
            val initial = notification("Connecting to FTP…")
            if (Build.VERSION.SDK_INT >= 26 &&
                manager.getNotificationChannel(CHANNEL)?.importance == NotificationManager.IMPORTANCE_NONE
            ) return false
            val info = if (Build.VERSION.SDK_INT >= 29) {
                ForegroundInfo(NOTIFICATION_ID, initial, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                ForegroundInfo(NOTIFICATION_ID, initial)
            }
            setForeground(info)
            lastNotifyAt = SystemClock.elapsedRealtime()
            true
        } catch (_: SecurityException) {
            false
        } catch (_: IllegalStateException) {
            // Modern Android can reject background starts for restricted foreground services.
            false
        } catch (_: RuntimeException) {
            false
        }
    }

    override suspend fun doWork(): Result = transferLock.withLock {
        val prefs = OffloadPreferences(applicationContext)
        if (!prefs.allowDeletion || prefs.sourceTree.isBlank()) return@withLock Result.failure(
            workDataOf("summary" to "Choose a phone folder and enable verified deletion first")
        )
        if (!OffloadEngine.isOnWifi(applicationContext)) {
            val message = "Move not started: connect to Wi-Fi and try again. Local files were preserved."
            prefs.lastReport = message
            return@withLock Result.failure(workDataOf("summary" to message))
        }

        if (!enterForeground()) {
            // Do not move/delete files without an active foreground transfer notification.
            val error = "Transfer not started: enable Aurora Media notifications and foreground service access, then retry."
            prefs.lastReport = error
            return@withLock Result.failure(workDataOf("summary" to error))
        }

        return@withLock try {
            prefs.lastReport = "Starting FTP transfer…"
            val report = OffloadEngine.run(
                applicationContext,
                progress = { current, filename ->
                    setProgress(workDataOf(
                        "summary" to current.display(), "filename" to filename,
                        "moved" to current.moved, "freed" to current.bytesFreed
                    ))
                    prefs.lastReport = current.display()
                    updateNotification("${current.moved} moved • ${current.failed} failed • $filename", force = true)
                },
                stopped = { isStopped },
                progressBytes = { filename, uploaded, total ->
                    val amount = String.format(Locale.ROOT, "%.1f MiB", uploaded / 1048576.0)
                    val percent = if (total > 0L) ((uploaded.toDouble() / total) * 100.0).toInt().coerceIn(0, 100) else null
                    updateNotification("Uploading $filename • $amount", percent)
                }
            )
            val summary = report.display()
            prefs.lastReport = summary
            if (notificationPermissionGranted()) runCatching {
                manager.notify(FINISHED_ID, notification(summary, finished = true))
            }
            Result.success(workDataOf("summary" to summary))
        } catch (cancel: CancellationException) {
            throw cancel
        } catch (_: OffloadEngine.TransferInterrupted) {
            // User-requested cancellation must not cause a retry and restart the move unexpectedly.
            val message = "Move stopped. Files without a verified FTP copy remain on your phone."
            prefs.lastReport = message
            Result.failure(workDataOf("summary" to message))
        } catch (error: Exception) {
            val message = "Move stopped: ${error.message ?: "Unknown error"}. Unverified local files were preserved."
            prefs.lastReport = message
            Result.failure(workDataOf("summary" to message))
        }
    }
}
