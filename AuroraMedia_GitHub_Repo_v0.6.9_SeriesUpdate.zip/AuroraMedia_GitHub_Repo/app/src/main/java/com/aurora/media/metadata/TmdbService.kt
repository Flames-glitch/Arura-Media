package com.aurora.media.metadata

import com.aurora.media.data.MediaEntry
import com.aurora.media.data.UpcomingMovie
import java.time.LocalDate
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import com.aurora.media.metadata.selectBestYouTubeKey

/** TMDb search: supports v3 API key (32-hex characters) or API Read Access Token (Bearer). */
class TmdbService(private val bearerToken: String) {
    fun enrich(item: MediaEntry): MediaEntry {
        if (bearerToken.isBlank()) return item
        val title = item.seriesName ?: item.title
        val type = if (item.isEpisode) "tv" else "movie"
        val preferred = search(type, title, item.year.takeUnless { item.isEpisode })
        val results = if (preferred.length() == 0 && item.year != null && !item.isEpisode) {
            search(type, title, null)
        } else preferred
        if (results.length() == 0) return if (item.isEpisode) item.copy(
            poster = null, backdrop = null, description = null, remoteId = null,
            tmdbRating = null, tmdbVoteCount = 0, tmdbRatingFetched = true,
            metadataMatchVersion = 2) else item
        val matches = (0 until results.length()).map { results.getJSONObject(it) }
        val match = if (item.isEpisode) {
            matches.firstOrNull { TvMatch.exact(title, it.optString("name")) }
                ?: return item.copy(poster = null, backdrop = null, description = null,
                    remoteId = null, tmdbRating = null, tmdbVoteCount = 0,
                    tmdbRatingFetched = true, metadataMatchVersion = 2)
        } else matches.firstOrNull { it.optString("poster_path").startsWith("/") }
            ?: results.getJSONObject(0)
        val posterPath = match.optString("poster_path").takeIf { it.startsWith('/') }
        val backdropPath = match.optString("backdrop_path").takeIf { it.startsWith('/') }
        return item.copy(
            poster = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" },
            backdrop = backdropPath?.let { "https://image.tmdb.org/t/p/w1280$it" },
            description = match.optString("overview").takeIf { it.isNotBlank() },
            remoteId = match.optInt("id", 0).takeIf { it > 0 },
            mediaType = type,
            genreIds = match.optJSONArray("genre_ids")?.let { genres ->
                (0 until genres.length()).map { genres.optInt(it) }.filter { it > 0 }
            }.orEmpty(),
            // TMDb search results include vote_average and vote_count. Zero votes
            // or zero average are treated as unrated, not as a 0/10 review.
            tmdbRating = match.optDouble("vote_average", 0.0).takeIf { it > 0.0 && it <= 10.0 },
            tmdbVoteCount = match.optInt("vote_count", 0).coerceAtLeast(0),
            tmdbRatingFetched = true,
            metadataMatchVersion = if (item.isEpisode) 2 else item.metadataMatchVersion
        )
    }

    /** One API request supplies episode stills and names for an entire season. */
    fun tvSeasonDetails(seriesId: Int, season: Int): Map<Int, EpisodeArtwork> {
        if (seriesId <= 0 || season < 0 || bearerToken.isBlank()) return emptyMap()
        val data = getJson("https://api.themoviedb.org/3/tv/$seriesId/season/$season?language=en-US")
        val episodes = data.optJSONArray("episodes") ?: return emptyMap()
        return (0 until episodes.length()).mapNotNull { i ->
            val episode = episodes.optJSONObject(i) ?: return@mapNotNull null
            val number = episode.optInt("episode_number", -1)
            if (number < 0) return@mapNotNull null
            val still = episode.optString("still_path").takeIf { it.startsWith("/") }
            number to EpisodeArtwork(
                name = episode.optString("name").takeIf { it.isNotBlank() },
                overview = episode.optString("overview").takeIf { it.isNotBlank() },
                still = still?.let { "https://image.tmdb.org/t/p/w500$it" },
                airDate = episode.optString("air_date").takeIf { it.isNotBlank() }
            )
        }.toMap()
    }

    /** Discover Indian theatrical releases in the next six months (TMDb release types 2/3). */
    fun upcomingTheatrical(region: String = "IN"): List<UpcomingMovie> {
        if (bearerToken.isBlank()) return emptyList()
        val today = LocalDate.now()
        val end = today.plusMonths(6)
        val regionCode = if (region.matches(Regex("[A-Z]{2}"))) region else "IN"
        val parameters = listOf(
            "region=$regionCode",
            "language=en-IN",
            "sort_by=primary_release_date.asc",
            "include_adult=false",
            "with_release_type=2%7C3", // limited theatrical or theatrical
            "release_date.gte=$today",
            "release_date.lte=$end"
        ).joinToString("&")
        val found = mutableListOf<UpcomingMovie>()
        for (page in 1..2) {
            val response = getJson("https://api.themoviedb.org/3/discover/movie?$parameters&page=$page")
            val results = response.optJSONArray("results") ?: break
            for (i in 0 until results.length()) {
                val movie = results.optJSONObject(i) ?: continue
                val id = movie.optInt("id")
                val name = movie.optString("title").trim()
                val date = movie.optString("release_date")
                if (id <= 0 || name.isBlank()) continue
                val parsedDate = runCatching { LocalDate.parse(date) }.getOrNull() ?: continue
                if (parsedDate.isBefore(today) || parsedDate.isAfter(end)) continue
                val poster = movie.optString("poster_path").takeIf { it.startsWith("/") }
                val backdrop = movie.optString("backdrop_path").takeIf { it.startsWith("/") }
                found += UpcomingMovie(
                    id = id, title = name, releaseDate = date,
                    description = movie.optString("overview"),
                    poster = poster?.let { "https://image.tmdb.org/t/p/w500$it" },
                    backdrop = backdrop?.let { "https://image.tmdb.org/t/p/w1280$it" }
                )
            }
            if (results.length() == 0) break
        }
        return found.distinctBy { it.id }.sortedWith(compareBy<UpcomingMovie> { it.releaseDate }.thenBy { it.title })
    }

    /** Uses TMDb video metadata; no YouTube API key or unofficial scraping required. */
    fun trailerUrl(movieId: Int): String? {
        if (movieId <= 0 || bearerToken.isBlank()) return null
        val data = getJson("https://api.themoviedb.org/3/movie/$movieId/videos?language=en-US&include_video_language=en,null,hi,ta,te,ml")
        val results = data.optJSONArray("results") ?: return null
        val candidates = (0 until results.length()).mapNotNull { index ->
            val item = results.optJSONObject(index) ?: return@mapNotNull null
            YouTubeVideo(
                site = item.optString("site"), key = item.optString("key"),
                type = item.optString("type"), official = item.optBoolean("official"),
                language = item.optString("iso_639_1")
            )
        }
        return selectBestYouTubeKey(candidates)?.let { "https://www.youtube.com/watch?v=$it" }
    }

    private fun getJson(url: String): JSONObject {
        val token = bearerToken.trim().removePrefix("Bearer ").trim()
        val isV3Key = token.matches(Regex("[0-9a-fA-F]{32}"))
        val endpoint = if (isV3Key) "$url&api_key=$token" else url
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 8_000
            if (!isV3Key) setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val status = connection.responseCode
            if (status == 401 || status == 403) error("TMDb authentication failed. Check your API key in Settings.")
            if (status != 200) error("TMDb HTTP $status. Try again later.")
            JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }

    private fun search(type: String, title: String, year: Int?): org.json.JSONArray {
        val token = bearerToken.trim().removePrefix("Bearer ").trim()
        val isV3Key = token.matches(Regex("[0-9a-fA-F]{32}"))
        val auth = if (isV3Key) "&api_key=$token" else ""
        val encodedTitle = URLEncoder.encode(title, "UTF-8")
        val yearParam = year?.let { "&year=$it" }.orEmpty()
        val endpoint = "https://api.themoviedb.org/3/search/$type?query=$encodedTitle$yearParam&include_adult=false$auth"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 8_000
            if (!isV3Key) setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val status = connection.responseCode
            if (status == 401 || status == 403) error("TMDb authentication failed. Use a valid API Read Access Token or v3 API key.")
            if (status != 200) error("TMDb HTTP $status. Try again later.")
            val response = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            response.optJSONArray("results") ?: org.json.JSONArray()
        } finally {
            connection.disconnect()
        }
    }
}

/** Metadata used to render a streaming-style episode list. */
data class EpisodeArtwork(
    val name: String?, val overview: String?, val still: String?, val airDate: String?
)
