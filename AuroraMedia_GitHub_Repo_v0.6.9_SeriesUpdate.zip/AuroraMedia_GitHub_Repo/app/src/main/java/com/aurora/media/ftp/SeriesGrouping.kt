package com.aurora.media.ftp

import java.util.Locale

data class EpisodeNumber(val season: Int, val episode: Int)

/** Normalized identity for files belonging to the same TV series. */
object SeriesGrouping {
    private val episodePattern = Regex("""(?i)S(\d{1,2})[. _-]*E(\d{1,3})""")
    private val alternativePattern = Regex("""(?i)(?<!\d)(\d{1,2})x(\d{1,3})(?!\d)""")
    private val wordsPattern = Regex("""(?i)Season[. _-]*(\d{1,2})[. _-]*Episode[. _-]*(\d{1,3})""")
    fun locate(stem: String): MatchResult? =
        episodePattern.find(stem) ?: alternativePattern.find(stem) ?: wordsPattern.find(stem)

    fun numbers(code: String?): EpisodeNumber? {
        if (code.isNullOrBlank()) return null
        val match = locate(code) ?: return null
        val season = match.groupValues[1].toIntOrNull() ?: return null
        val episode = match.groupValues[2].toIntOrNull() ?: return null
        return EpisodeNumber(season, episode)
    }

    fun key(name: String?): String = name.orEmpty()
        .lowercase(Locale.ROOT).replace(Regex("""[^\p{L}\p{N}]+"""), " ")
        .trim().replace(Regex("""\s+"""), " ")

    fun label(stem: String, match: MatchResult, parentFolder: String): String {
        val raw = FilenameCleaner.movieTitle(stem, match.range.first)
        if (raw.isNotBlank()) return raw
        return parentFolder.replace(Regex("""(?i)^(?:season[._ -]*\d+|s\d{1,2})$"""), "")
            .replace(Regex("""[._]+"""), " ").trim().ifBlank { "Unknown Series" }
    }
}
