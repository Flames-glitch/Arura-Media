package com.aurora.media.ftp

import com.aurora.media.data.FtpSettings
import com.aurora.media.data.MediaEntry
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import java.net.URI
import java.net.URLEncoder
import java.util.Locale

object FtpScanner {
    private val extensions = setOf("mp4", "mkv", "avi", "mov", "m4v", "wmv", "flv", "webm", "ts", "m2ts", "mpg", "mpeg", "3gp", "vob", "ogv")

    private fun normalizedPath(path: String): String = "/" + path.trim().trim('/').takeIf { it.isNotBlank() }.orEmpty()

    fun connect(settings: FtpSettings): FTPClient {
        val ftp = FTPClient()
        ftp.connectTimeout = 10_000
        ftp.defaultTimeout = 10_000
        ftp.setDataTimeout(java.time.Duration.ofSeconds(20))
        ftp.controlEncoding = "UTF-8"
        try {
            ftp.connect(settings.host.trim(), settings.port)
            if (!ftp.login(settings.username, settings.password)) {
                error("FTP login was rejected. Check the username and password.")
            }
            ftp.enterLocalPassiveMode()
            if (!ftp.setFileType(FTP.BINARY_FILE_TYPE)) {
                error("FTP binary transfer mode unavailable")
            }
            return ftp
        } catch (e: Exception) {
            if (ftp.isConnected) runCatching { ftp.disconnect() }
            throw e
        }
    }

    inline fun <T> withConnection(settings: FtpSettings, task: (FTPClient) -> T): T {
        val ftp = connect(settings)
        return try { task(ftp) } finally {
            runCatching { ftp.logout() }
            runCatching { ftp.disconnect() }
        }
    }

    fun test(settings: FtpSettings) = withConnection(settings) { ftp ->
        val directory = normalizedPath(settings.directory)
        if (!ftp.changeWorkingDirectory(directory)) error("FTP folder '$directory' does not exist or is inaccessible")
    }

    fun scan(settings: FtpSettings, maxFiles: Int = 8_000, maxDepth: Int = 20): List<MediaEntry> =
        withConnection(settings) { ftp ->
            val results = mutableListOf<MediaEntry>()
            val start = normalizedPath(settings.directory)
            if (!ftp.changeWorkingDirectory(start)) error("FTP directory '$start' cannot be accessed")

            fun walk(path: String, depth: Int) {
                if (depth > maxDepth || results.size >= maxFiles) return
                val entries: Array<FTPFile> = ftp.listFiles(path) ?: emptyArray()
                for (file in entries) {
                    if (results.size >= maxFiles) break
                    if (file.name == "." || file.name == ".." || file.name.contains('/')) continue
                    // Avoid symlink traversal, which can otherwise create directory cycles.
                    if (file.isSymbolicLink) continue
                    val fullPath = "${path.trimEnd('/')}/${file.name}"
                    if (file.isDirectory) walk(fullPath, depth + 1)
                    else if (file.isFile && file.name.substringAfterLast('.', "").lowercase(Locale.ROOT) in extensions) {
                        results += FilenameParser.parse(fullPath, file.size)
                    }
                }
            }
            walk(start, 0)
            results
        }

    /** Credentials remain on-device; this URL is handed only to local LibVLC, never metadata APIs. */
    fun mediaUrl(settings: FtpSettings, filePath: String): String {
        fun encoded(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
        val authority = "${encoded(settings.username)}:${encoded(settings.password)}@${settings.host}:${settings.port}"
        val path = filePath.split('/').joinToString("/") { encoded(it) }
        return URI.create("ftp://$authority$path").toASCIIString()
    }
}

object FilenameParser {

    fun parse(path: String, bytes: Long): MediaEntry {
        val filename = path.substringAfterLast('/')
        val stem = FilenameCleaner.cleanedStem(filename)
        val match = SeriesGrouping.locate(stem)
        val parent = path.substringBeforeLast('/').substringAfterLast('/')
        val title = if (match != null) SeriesGrouping.label(stem, match, parent)
            else FilenameCleaner.movieTitle(stem)
        val code = match?.let { "S${it.groupValues[1].padStart(2, '0')}E${it.groupValues[2].padStart(2, '0')}" }
        return MediaEntry(
            path = path, fileName = filename, title = title,
            year = FilenameCleaner.yearOf(stem),
            isEpisode = match != null, seriesName = if (match != null) title else null,
            episodeCode = code, bytes = bytes,
            mediaType = if (match != null) "tv" else "movie"
        )
    }
}
